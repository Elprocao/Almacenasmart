package com.alacenasmart.app.data.remote

import android.graphics.Bitmap
import android.util.Base64
import com.alacenasmart.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit

data class DetectedProduct(
    val id: String = UUID.randomUUID().toString(),
    val productName: String,
    val category: String,
    val quantity: Int = 1,
    val shelfLifeDays: Int = 7,
    val caloriesKcal: Int = 0,
    val proteinGrams: Float = 0f,
    val carbsGrams: Float = 0f,
    val fatGrams: Float = 0f,
    val sugarGrams: Float = 0f,
    val saltGrams: Float = 0f
)

// Legacy alias for compatibility
data class VisualProductIdentification(
    val productName: String,
    val category: String,
    val typicalShelfLifeDays: Int = 7
)

object GeminiVisionService {

    private const val MODEL = "gemini-2.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        val scaled = if (width > 1024 || height > 1024) {
            val ratio = width.toFloat() / height.toFloat()
            val newWidth = if (ratio >= 1f) 1024 else (1024 * ratio).toInt()
            val newHeight = if (ratio >= 1f) (1024 / ratio).toInt() else 1024
            Bitmap.createScaledBitmap(this, newWidth, newHeight, true)
        } else {
            this
        }
        scaled.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun detectMultipleProductsFromBitmap(bitmap: Bitmap): Result<List<DetectedProduct>> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("Se requiere configurar la clave de API de Gemini en Ajustes.")
            )
        }

        try {
            val base64Image = bitmap.toBase64()

            val systemPrompt = """
                Eres el sistema de reconocimiento visual de alimentos y nutrición de AlacenaSmart.
                Examina minuciosamente la imagen capturada.
                Detecta TODOS los alimentos o productos alimenticios visibles (pueden ser varios productos distintos, o varias unidades del mismo alimento si se muestran 2, 3 o más).
                Para cada producto detectado, identifica:
                - productName: Nombre común y claro en español (ej: "Manzana", "Leche entera", "Plátano", "Huevo", "Pechuga de pollo", "Tomate").
                - category: Una de estas opciones exactas: "Frutas y verduras", "Lácteos", "Carnes", "Despensa", "Congelados", "Bebidas", "Varios".
                - quantity: Cantidad contada en la foto (ej: si se observan 2 o 3 manzanas o plátanos, pon 2 o 3; si es un envase o producto único, pon 1). Mínimo 1.
                - shelfLifeDays: Días estimados recomendados de caducidad.
                - caloriesKcal: Calorías estimadas (kcal) por 100g o ración típica.
                - proteinGrams: Proteínas en gramos (float).
                - carbsGrams: Hidratos de carbono en gramos (float).
                - fatGrams: Grasas totales en gramos (float).
                - sugarGrams: Azúcares en gramos (float).
                - saltGrams: Sal en gramos (float).

                Responde ÚNICAMENTE con un objeto JSON con este formato exacto:
                {
                  "products": [
                    {
                      "productName": "Nombre",
                      "category": "Frutas y verduras",
                      "quantity": 2,
                      "shelfLifeDays": 7,
                      "caloriesKcal": 52,
                      "proteinGrams": 0.3,
                      "carbsGrams": 14.0,
                      "fatGrams": 0.2,
                      "sugarGrams": 10.0,
                      "saltGrams": 0.01
                    }
                  ]
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject().apply {
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().apply {
                        put("text", "Detecta todos los productos alimenticios visibles, sus cantidades contadas y su información nutricional completa.")
                    })
                    partsArray.put(JSONObject().apply {
                        val inlineDataObj = JSONObject().apply {
                            put("mimeType", "image/jpeg")
                            put("data", base64Image)
                        }
                        put("inlineData", inlineDataObj)
                    })
                    put("parts", partsArray)
                }
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                val sysInstruction = JSONObject().apply {
                    val parts = JSONArray()
                    parts.put(JSONObject().apply { put("text", systemPrompt) })
                    put("parts", parts)
                }
                put("systemInstruction", sysInstruction)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.2)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", genConfig)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val url = "$BASE_URL?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: ""
                val userFriendlyMsg = try {
                    val errJson = JSONObject(errBody).optJSONObject("error")
                    val rawMsg = errJson?.optString("message") ?: ""
                    when {
                        rawMsg.contains("API_KEY_INVALID", ignoreCase = true) || rawMsg.contains("API key not valid", ignoreCase = true) ->
                            "Clave de API de Gemini no válida. Por favor, revísala en los Ajustes."
                        rawMsg.contains("RESOURCE_EXHAUSTED", ignoreCase = true) || rawMsg.contains("quota", ignoreCase = true) ->
                            "Límite de cuota alcanzado temporalmente. Inténtalo de nuevo en unos momentos."
                        rawMsg.isNotBlank() -> "Error de IA: $rawMsg"
                        else -> "Error en el reconocimiento visual (${response.code})"
                    }
                } catch (_: Exception) {
                    "Error al comunicarse con Gemini (${response.code})"
                }
                return@withContext Result.failure(Exception(userFriendlyMsg))
            }

            val responseBody = response.body?.string() ?: throw IllegalStateException("Respuesta vacía de Gemini")
            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.failure(Exception("No se pudieron identificar productos en la imagen."))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.getJSONObject(0)?.optString("text") ?: "{}"

            val cleanJson = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val parsedObj = JSONObject(cleanJson)

            val productsList = mutableListOf<DetectedProduct>()
            val jsonArray = parsedObj.optJSONArray("products")

            if (jsonArray != null && jsonArray.length() > 0) {
                for (i in 0 until jsonArray.length()) {
                    val item = jsonArray.getJSONObject(i)
                    productsList.add(
                        DetectedProduct(
                            productName = item.optString("productName", "Alimento identificado").trim(),
                            category = item.optString("category", "Despensa").trim(),
                            quantity = item.optInt("quantity", 1).coerceAtLeast(1),
                            shelfLifeDays = item.optInt("shelfLifeDays", 7).coerceAtLeast(1),
                            caloriesKcal = item.optInt("caloriesKcal", 0),
                            proteinGrams = item.optDouble("proteinGrams", 0.0).toFloat(),
                            carbsGrams = item.optDouble("carbsGrams", 0.0).toFloat(),
                            fatGrams = item.optDouble("fatGrams", 0.0).toFloat(),
                            sugarGrams = item.optDouble("sugarGrams", 0.0).toFloat(),
                            saltGrams = item.optDouble("saltGrams", 0.0).toFloat()
                        )
                    )
                }
            } else if (parsedObj.has("productName")) {
                // Fallback if Gemini responded with a single product object
                productsList.add(
                    DetectedProduct(
                        productName = parsedObj.optString("productName", "Alimento identificado").trim(),
                        category = parsedObj.optString("category", "Despensa").trim(),
                        quantity = parsedObj.optInt("quantity", 1).coerceAtLeast(1),
                        shelfLifeDays = parsedObj.optInt("shelfLifeDays", 7).coerceAtLeast(1),
                        caloriesKcal = parsedObj.optInt("caloriesKcal", 0),
                        proteinGrams = parsedObj.optDouble("proteinGrams", 0.0).toFloat(),
                        carbsGrams = parsedObj.optDouble("carbsGrams", 0.0).toFloat(),
                        fatGrams = parsedObj.optDouble("fatGrams", 0.0).toFloat(),
                        sugarGrams = parsedObj.optDouble("sugarGrams", 0.0).toFloat(),
                        saltGrams = parsedObj.optDouble("saltGrams", 0.0).toFloat()
                    )
                )
            }

            if (productsList.isEmpty()) {
                return@withContext Result.failure(Exception("No se detectó ningún alimento reconocible en la foto."))
            }

            Result.success(productsList)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun identifyProductFromBitmap(bitmap: Bitmap): Result<VisualProductIdentification> {
        return detectMultipleProductsFromBitmap(bitmap).map { list ->
            val first = list.firstOrNull() ?: DetectedProduct(productName = "Alimento", category = "Despensa")
            VisualProductIdentification(
                productName = first.productName,
                category = first.category,
                typicalShelfLifeDays = first.shelfLifeDays
            )
        }
    }
}
