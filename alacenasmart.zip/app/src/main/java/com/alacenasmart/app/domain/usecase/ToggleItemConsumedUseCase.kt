package com.alacenasmart.app.domain.usecase

import com.alacenasmart.app.domain.repository.PantryRepository

class ToggleItemConsumedUseCase(private val repository: PantryRepository) {
    suspend operator fun invoke(
        pantryItemId: Long,
        isConsumed: Boolean,
        addToShoppingList: Boolean = false
    ) {
        val item = repository.getItemById(pantryItemId)
        repository.setItemConsumed(pantryItemId, isConsumed)

        if (isConsumed && addToShoppingList && item != null) {
            repository.addShoppingItem(
                name = item.name,
                category = item.category,
                originPantryItemId = item.id,
                imageUrl = item.imageUrl
            )
        }
    }
}
