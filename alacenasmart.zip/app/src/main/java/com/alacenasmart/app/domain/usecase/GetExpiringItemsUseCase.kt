package com.alacenasmart.app.domain.usecase

import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.repository.PantryRepository
import kotlinx.coroutines.flow.Flow

class GetExpiringItemsUseCase(private val repository: PantryRepository) {
    operator fun invoke(thresholdDays: Long = 4): Flow<List<PantryItem>> {
        return repository.getExpiringItems(thresholdDays)
    }
}
