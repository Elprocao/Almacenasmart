package com.alacenasmart.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alacenasmart.app.domain.model.ExpiryStatus
import com.alacenasmart.app.domain.model.TrafficLightColor
import com.alacenasmart.app.ui.theme.ExpiryGreen
import com.alacenasmart.app.ui.theme.ExpiryGreenContainer
import com.alacenasmart.app.ui.theme.ExpiryGreenOnContainer
import com.alacenasmart.app.ui.theme.ExpiryRed
import com.alacenasmart.app.ui.theme.ExpiryRedContainer
import com.alacenasmart.app.ui.theme.ExpiryRedOnContainer
import com.alacenasmart.app.ui.theme.ExpiryYellow
import com.alacenasmart.app.ui.theme.ExpiryYellowContainer
import com.alacenasmart.app.ui.theme.ExpiryYellowOnContainer

@Composable
fun ExpiryTrafficBadge(
    expiryStatus: ExpiryStatus,
    modifier: Modifier = Modifier
) {
    val (dotColor, containerColor, textColor) = when (expiryStatus.trafficLight) {
        TrafficLightColor.RED -> Triple(ExpiryRed, ExpiryRedContainer, ExpiryRedOnContainer)
        TrafficLightColor.YELLOW -> Triple(ExpiryYellow, ExpiryYellowContainer, ExpiryYellowOnContainer)
        TrafficLightColor.GREEN -> Triple(ExpiryGreen, ExpiryGreenContainer, ExpiryGreenOnContainer)
    }

    Row(
        modifier = modifier
            .testTag("expiry_badge_${expiryStatus.trafficLight.name.lowercase()}")
            .clip(RoundedCornerShape(12.dp))
            .background(containerColor)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = expiryStatus.displayMessage,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
