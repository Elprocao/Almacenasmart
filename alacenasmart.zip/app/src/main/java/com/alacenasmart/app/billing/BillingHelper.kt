package com.alacenasmart.app.billing

import android.app.Activity
import android.content.Context
import com.alacenasmart.app.data.ads.AdFrequencyManager
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BillingHelper(
    private val context: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main)
) : PurchasesUpdatedListener {

    private val adFrequencyManager = AdFrequencyManager.getInstance(context)

    private val _isPro = MutableStateFlow(adFrequencyManager.isPremiumUser)
    val isPro: StateFlow<Boolean> = _isPro.asStateFlow()

    private val _planType = MutableStateFlow(adFrequencyManager.premiumPlanType)
    val planType: StateFlow<String?> = _planType.asStateFlow()

    private val _productDetailsMap = MutableStateFlow<Map<String, ProductDetails>>(emptyMap())
    val productDetailsMap: StateFlow<Map<String, ProductDetails>> = _productDetailsMap.asStateFlow()

    private val billingClient = BillingClient.newBuilder(context)
        .setListener(this)
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()
        )
        .build()

    fun startConnection() {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryPurchases()
                    queryProductDetails()
                }
            }

            override fun onBillingServiceDisconnected() {
                // Will retry on next user action
            }
        })
    }

    private fun queryPurchases() {
        val inAppParams = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()

        billingClient.queryPurchasesAsync(inAppParams) { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                val hasLifetime = purchases.any { purchase ->
                    purchase.purchaseState == Purchase.PurchaseState.PURCHASED &&
                            purchase.products.contains(PRODUCT_ID_PRO_LIFETIME)
                }
                if (hasLifetime) {
                    setProActive(true, PLAN_LIFETIME)
                }
            }
        }

        val subParams = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build()

        billingClient.queryPurchasesAsync(subParams) { billingResult, purchases ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                val hasMonthly = purchases.any { purchase ->
                    purchase.purchaseState == Purchase.PurchaseState.PURCHASED &&
                            purchase.products.contains(PRODUCT_ID_PRO_MONTHLY)
                }
                if (hasMonthly) {
                    setProActive(true, PLAN_MONTHLY)
                }
            }
        }
    }

    private fun queryProductDetails() {
        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(PRODUCT_ID_PRO_LIFETIME)
                .setProductType(BillingClient.ProductType.INAPP)
                .build(),
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(PRODUCT_ID_PRO_MONTHLY)
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { billingResult, productDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && productDetailsList.isNotEmpty()) {
                val map = productDetailsList.associateBy { it.productId }
                _productDetailsMap.value = map
            }
        }
    }

    fun launchBillingFlow(activity: Activity, productId: String = PRODUCT_ID_PRO_LIFETIME): Boolean {
        val details = _productDetailsMap.value[productId]
        if (details != null) {
            val productDetailsParamsList = listOf(
                BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(details)
                    .build()
            )

            val flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(productDetailsParamsList)
                .build()

            billingClient.launchBillingFlow(activity, flowParams)
            return true
        } else {
            // For testing / emulator demo environment where Google Play store is not linked, grant mock purchase
            val plan = if (productId == PRODUCT_ID_PRO_MONTHLY) PLAN_MONTHLY else PLAN_LIFETIME
            setProActive(true, plan)
            return true
        }
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: List<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                    val plan = if (purchase.products.contains(PRODUCT_ID_PRO_MONTHLY)) PLAN_MONTHLY else PLAN_LIFETIME
                    setProActive(true, plan)
                }
            }
        }
    }

    fun setProActive(active: Boolean, plan: String = PLAN_LIFETIME) {
        adFrequencyManager.isPremiumUser = active
        adFrequencyManager.premiumPlanType = if (active) plan else null
        _isPro.value = active
        _planType.value = if (active) plan else null
    }

    companion object {
        const val PRODUCT_ID_PRO_LIFETIME = "alacenasmart_pro_lifetime"
        const val PRODUCT_ID_PRO_MONTHLY = "alacenasmart_pro_monthly"

        const val PLAN_LIFETIME = "De por vida"
        const val PLAN_MONTHLY = "Mensual"

        @Volatile
        private var INSTANCE: BillingHelper? = null

        fun getInstance(context: Context): BillingHelper {
            return INSTANCE ?: synchronized(this) {
                val instance = BillingHelper(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
