package com.alacenasmart.app.data.ads

import android.content.Context
import android.content.SharedPreferences

class AdFrequencyManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isPremiumUser: Boolean
        get() = prefs.getBoolean(KEY_IS_PREMIUM, false)
        set(value) {
            prefs.edit().putBoolean(KEY_IS_PREMIUM, value).apply()
        }

    var premiumPlanType: String?
        get() = prefs.getString(KEY_PREMIUM_PLAN_TYPE, null)
        set(value) {
            prefs.edit().putString(KEY_PREMIUM_PLAN_TYPE, value).apply()
        }

    private var activeSessionStart: Long = 0L

    fun onAppResume() {
        activeSessionStart = System.currentTimeMillis()
    }

    fun onAppPause() {
        if (activeSessionStart > 0) {
            val sessionElapsed = System.currentTimeMillis() - activeSessionStart
            val accumulated = prefs.getLong(KEY_ACCUMULATED_ACTIVE_TIME_MS, 0L)
            prefs.edit().putLong(KEY_ACCUMULATED_ACTIVE_TIME_MS, accumulated + sessionElapsed).apply()
            activeSessionStart = 0L
        }
    }

    fun canShowInterstitial(): Boolean {
        if (isPremiumUser) return false

        val lastShownTime = prefs.getLong(KEY_LAST_INTERSTITIAL_TIME, 0L)
        val now = System.currentTimeMillis()
        val timeSinceLastShown = now - lastShownTime

        // Minimum 30 minutes (1,800,000 ms)
        val thirtyMinutesMs = 30 * 60 * 1000L
        if (timeSinceLastShown < thirtyMinutesMs) {
            return false
        }

        // Check active foreground usage duration
        val accumulatedActiveTime = prefs.getLong(KEY_ACCUMULATED_ACTIVE_TIME_MS, 0L)
        val currentSessionTime = if (activeSessionStart > 0) now - activeSessionStart else 0L
        val totalActiveTime = accumulatedActiveTime + currentSessionTime

        // At least 2 minutes of active app usage between ads
        return totalActiveTime >= 2 * 60 * 1000L
    }

    /**
     * User rule: "cada 3 veces te salga un anuncio de 15 s"
     * Increments action counter and on every 3rd action displays the interstitial ad
     */
    fun incrementUserActionAndShowAdIfDue(activity: android.app.Activity, onProceed: () -> Unit) {
        if (isPremiumUser) {
            onProceed()
            return
        }

        val currentCount = prefs.getInt(KEY_ACTION_COUNTER, 0) + 1
        prefs.edit().putInt(KEY_ACTION_COUNTER, currentCount).apply()

        if (currentCount % 3 == 0) {
            val app = com.alacenasmart.app.AlacenaApp.instance
            app.adMobHelper.showDirectInterstitial(activity) {
                onProceed()
            }
        } else {
            onProceed()
        }
    }

    fun recordInterstitialShown() {
        prefs.edit()
            .putLong(KEY_LAST_INTERSTITIAL_TIME, System.currentTimeMillis())
            .putLong(KEY_ACCUMULATED_ACTIVE_TIME_MS, 0L)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "alacenasmart_ad_prefs"
        private const val KEY_IS_PREMIUM = "key_is_premium"
        private const val KEY_PREMIUM_PLAN_TYPE = "key_premium_plan_type"
        private const val KEY_LAST_INTERSTITIAL_TIME = "key_last_interstitial_time"
        private const val KEY_ACCUMULATED_ACTIVE_TIME_MS = "key_accumulated_active_time"
        private const val KEY_ACTION_COUNTER = "key_action_counter"

        @Volatile
        private var INSTANCE: AdFrequencyManager? = null

        fun getInstance(context: Context): AdFrequencyManager {
            return INSTANCE ?: synchronized(this) {
                val instance = AdFrequencyManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
