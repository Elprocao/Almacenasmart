package com.alacenasmart.app.data.remote

import com.alacenasmart.app.BuildConfig
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.Recipe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

object GeminiRecipeService {

    private const val MODEL = "gemini-2.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun generate5RecipesFromPantry(
        pantryItems: List<PantryItem>,
        dietaryPreference: com.alacenasmart.app.domain.model.DietaryPreference = com.alacenasmart.app.domain.model.DietaryPreference.ALL
    ): Result<List<Recipe>> = withContext(Dispatchers.IO) {
        if (pantryItems.isEmpty()) {
            return@withContext Result.success(emptyList())
        }

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("Se requiere configurar la clave de API de Gemini en Ajustes.")
            )
        }

        try {
            val ingredientsAvailableStr = pantryItems.joinToString(", ") {
                val expiringTag = if (it.expiryStatus.daysRemaining in 0..2) " [¡CADUCA EN ${it.expiryStatus.daysRemaining} DÍAS! PRIORIDAD DE APROVECHAMIENTO]" else ""
                "${it.name} (${it.quantity} ${it.unit})$expiringTag"
            }

            val preferencePrompt = if (dietaryPreference != com.alacenasmart.app.domain.model.DietaryPreference.ALL) {
                "\nPREFERENCIA DIETÉTICA / FILTRO SELECCIONADO POR EL USUARIO:\n- ${dietaryPreference.label}: ${dietaryPreference.promptInstruction}\n"
            } else ""

            val systemPrompt = """
                Eres un Chef profesional y nutricionista de alta cocina.
                Tu tarea es generar EXACTAMENTE 5 recetas completas, deliciosas y viables que el usuario PUEDA COCINAR al 100% utilizando los ingredientes que tiene en su despensa (puedes asumir básicos comunes de cocina como agua o pizca de sal, pero los ingredientes principales deben provenir de su despensa).
                $preferencePrompt
                Requisitos estrictos para CADA receta:
                1. Solo recetas que se puedan hacer con lo disponible en la despensa del usuario.
                2. Número de raciones exacto (servings: entero, ej 2 o 4).
                3. Medidas exactas en los ingredientes: indicar siempre gramos (g), mililitros (ml), litros (l), cucharadas o unidades (ej: "250 g de pechuga de pollo cortada en tiras", "150 ml de leche", "2 unidades de huevo batido").
                4. Preparación detallada paso a paso: especificar tiempos precisos de cocción, temperaturas recomendadas (ej: "Horno precalentado a 180 °C", "Fuego medio-alto a 120 °C"), y tiempos de reposo si aplica.
                5. restTimeMinutes: minutos de reposo necesarios (0 si no necesita).
                6. cookingTemp: temperatura o intensidad (ej: "180 °C (Horno)", "Fuego medio-alto (130 °C)", "Sin cocción").
                7. Información nutricional calculada por ración:
                   - caloriesKcal (entero)
                   - proteinGrams (float)
                   - carbsGrams (float)
                   - fatGrams (float)
                   - sugarGrams (float)
                   - saltGrams (float)

                Responde ÚNICAMENTE con un JSON con la clave "recipes" y una lista de 5 objetos con esta estructura exacta:
                {
                  "recipes": [
                    {
                      "title": "Nombre de la receta",
                      "description": "Breve descripción apetecible",
                      "category": "Almuerzo | Cena | Desayuno | Postre | Snack",
                      "difficulty": "Fácil | Media | Difícil",
                      "prepTimeMinutes": 25,
                      "servings": 2,
                      "restTimeMinutes": 5,
                      "cookingTemp": "Fuego medio (120 °C)",
                      "requiredIngredients": [
                        "200 g de pechuga de pollo",
                        "1 pizca de sal (2 g)"
                      ],
                      "steps": [
                        "Paso 1: Cortar...",
                        "Paso 2: Calentar la sartén a fuego medio...",
                        "Paso 3: Dejar reposar 5 minutos..."
                      ],
                      "caloriesKcal": 320,
                      "proteinGrams": 32.5,
                      "carbsGrams": 4.0,
                      "fatGrams": 12.0,
                      "sugarGrams": 1.2,
                      "saltGrams": 1.1
                    }
                  ]
                }
            """.trimIndent()

            val userMessage = "Ingredientes actualmente disponibles en mi despensa: $ingredientsAvailableStr. Por favor genera 5 recetas que pueda cocinar ahora mismo teniendo en cuenta mis preferencias."

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject().apply {
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().apply { put("text", userMessage) })
                    put("parts", partsArray)
                }
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                val sysInstruction = JSONObject().apply {
                    val parts = JSONArray()
                    parts.put(JSONObject().apply { put("text", systemPrompt) })
                    put("parts", parts)
                }
                put("systemInstruction", sysInstruction)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.4)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", genConfig)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val url = "$BASE_URL?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Error de Gemini (${response.code}) al generar recetas"))
            }

            val responseBody = response.body?.string() ?: throw IllegalStateException("Respuesta vacía de Gemini")
            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates") ?: return@withContext Result.failure(Exception("Sin candidatos de recetas"))
            val firstCandidate = candidates.getJSONObject(0)
            val parts = firstCandidate.optJSONObject("content")?.optJSONArray("parts")
            val text = parts?.getJSONObject(0)?.optString("text") ?: "{}"
            val cleanJson = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

            val parsed = JSONObject(cleanJson)
            val recipesArray = parsed.optJSONArray("recipes") ?: JSONArray()
            val list = mutableListOf<Recipe>()

            val availableNames = pantryItems.map { it.name.lowercase().trim() }

            for (i in 0 until recipesArray.length()) {
                val item = recipesArray.getJSONObject(i)
                val reqIng = mutableListOf<String>()
                val reqArray = item.optJSONArray("requiredIngredients")
                if (reqArray != null) {
                    for (j in 0 until reqArray.length()) {
                        reqIng.add(reqArray.getString(j))
                    }
                }
                val stepsList = mutableListOf<String>()
                val stepsArray = item.optJSONArray("steps")
                if (stepsArray != null) {
                    for (j in 0 until stepsArray.length()) {
                        stepsList.add(stepsArray.getString(j))
                    }
                }

                // Since Gemini was told to only use available ingredients, match them
                val matched = reqIng.filter { ing ->
                    val lower = ing.lowercase()
                    availableNames.any { lower.contains(it) || it.contains(lower) }
                }

                list.add(
                    Recipe(
                        id = "ai_${UUID.randomUUID()}",
                        title = item.optString("title", "Receta de chef").trim(),
                        description = item.optString("description", "").trim(),
                        category = item.optString("category", "Almuerzo").trim(),
                        difficulty = item.optString("difficulty", "Fácil").trim(),
                        prepTimeMinutes = item.optInt("prepTimeMinutes", 20).coerceAtLeast(5),
                        servings = item.optInt("servings", 2).coerceAtLeast(1),
                        restTimeMinutes = item.optInt("restTimeMinutes", 0),
                        cookingTemp = item.optString("cookingTemp", "Fuego medio"),
                        requiredIngredients = reqIng,
                        availableIngredients = if (matched.isNotEmpty()) matched else reqIng,
                        missingIngredients = emptyList(), // Strictly cookable
                        steps = stepsList,
                        caloriesKcal = item.optInt("caloriesKcal", 350),
                        proteinGrams = item.optDouble("proteinGrams", 15.0).toFloat(),
                        carbsGrams = item.optDouble("carbsGrams", 30.0).toFloat(),
                        fatGrams = item.optDouble("fatGrams", 10.0).toFloat(),
                        sugarGrams = item.optDouble("sugarGrams", 3.0).toFloat(),
                        saltGrams = item.optDouble("saltGrams", 1.0).toFloat()
                    )
                )
            }

            Result.success(list.take(5))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
