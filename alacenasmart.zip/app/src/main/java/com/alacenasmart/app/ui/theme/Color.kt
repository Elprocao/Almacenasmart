package com.alacenasmart.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val GreenPrimary = Color(0xFF1B5E20)
val GreenOnPrimary = Color(0xFFFFFFFF)
val GreenPrimaryContainer = Color(0xFFD4EED8)
val GreenOnPrimaryContainer = Color(0xFF072109)

val OrangeSecondary = Color(0xFFE65100)
val OrangeOnSecondary = Color(0xFFFFFFFF)
val OrangeSecondaryContainer = Color(0xFFFFDCC2)
val OrangeOnSecondaryContainer = Color(0xFF321200)

val SageTertiary = Color(0xFF386A20)
val SageOnTertiary = Color(0xFFFFFFFF)

val BackgroundLight = Color(0xFFFBFDF8)
val OnBackgroundLight = Color(0xFF191C19)
val SurfaceLight = Color(0xFFF7FAF4)
val OnSurfaceLight = Color(0xFF191C19)
val SurfaceVariantLight = Color(0xFFDEE5D9)
val OnSurfaceVariantLight = Color(0xFF424940)
val OutlineLight = Color(0xFF72796F)

// Dark Theme Palette
val GreenPrimaryDark = Color(0xFF81C784)
val GreenOnPrimaryDark = Color(0xFF00390E)
val GreenPrimaryContainerDark = Color(0xFF0D4A19)
val GreenOnPrimaryContainerDark = Color(0xFF9DEFB1)

val OrangeSecondaryDark = Color(0xFFFFB77D)
val OrangeOnSecondaryDark = Color(0xFF4D2600)
val OrangeSecondaryContainerDark = Color(0xFF6E3900)
val OrangeOnSecondaryContainerDark = Color(0xFFFFDCC2)

val BackgroundDark = Color(0xFF111411)
val OnBackgroundDark = Color(0xFFE1E3DF)
val SurfaceDark = Color(0xFF191D1A)
val OnSurfaceDark = Color(0xFFE1E3DF)
val SurfaceVariantDark = Color(0xFF424940)
val OnSurfaceVariantDark = Color(0xFFC2C9BD)
val OutlineDark = Color(0xFF8C9388)

// Traffic Light Semantic Status Colors
val ExpiryRed = Color(0xFFD32F2F)
val ExpiryRedContainer = Color(0xFFFFEBEE)
val ExpiryRedOnContainer = Color(0xFFB71C1C)

val ExpiryYellow = Color(0xFFF57F17)
val ExpiryYellowContainer = Color(0xFFFFF9C4)
val ExpiryYellowOnContainer = Color(0xFFE65100)

val ExpiryGreen = Color(0xFF2E7D32)
val ExpiryGreenContainer = Color(0xFFE8F5E9)
val ExpiryGreenOnContainer = Color(0xFF1B5E20)
