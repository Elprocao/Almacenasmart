package com.alacenasmart.app.domain.usecase

import com.alacenasmart.app.data.local.entity.ProductBarcodeEntity
import com.alacenasmart.app.domain.repository.PantryRepository

sealed class BarcodeScanResult {
    data class Found(val product: ProductBarcodeEntity) : BarcodeScanResult()
    data class Unknown(val barcode: String) : BarcodeScanResult()
}

class ScanBarcodeUseCase(private val repository: PantryRepository) {
    suspend operator fun invoke(barcode: String): BarcodeScanResult {
        val trimmed = barcode.trim()
        val found = repository.lookupBarcode(trimmed)
        return if (found != null) {
            BarcodeScanResult.Found(found)
        } else {
            BarcodeScanResult.Unknown(trimmed)
        }
    }
}
