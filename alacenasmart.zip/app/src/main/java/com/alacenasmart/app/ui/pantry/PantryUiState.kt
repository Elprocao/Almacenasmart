package com.alacenasmart.app.ui.pantry

import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.StorageLocation

data class PantryUiState(
    val items: List<PantryItem> = emptyList(),
    val totalCount: Int = 0,
    val expiringSoonCount: Int = 0,
    val expiredCount: Int = 0,
    val selectedLocation: StorageLocation? = null,
    val selectedCategory: String? = null,
    val searchQuery: String = "",
    val isLoading: Boolean = true,
    val isProUser: Boolean = false,
    val editingItem: PantryItem? = null,
    val isAddEditDialogOpen: Boolean = false,
    val itemToDiscard: PantryItem? = null,
    val userMessage: String? = null
)
