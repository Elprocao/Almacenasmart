package com.alacenasmart.app.ui.scanner

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alacenasmart.app.billing.BillingHelper
import com.alacenasmart.app.data.remote.DetectedProduct
import com.alacenasmart.app.data.remote.GeminiVisionService
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.domain.repository.PantryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

data class ScannerUiState(
    val isAnalyzing: Boolean = false,
    val detectedProducts: List<DetectedProduct> = emptyList(),
    val showMultiProductSheet: Boolean = false,
    val showManualAddDialog: Boolean = false,
    val sessionAddedCount: Int = 0,
    val isTorchEnabled: Boolean = false,
    val isProUser: Boolean = false,
    val showProLimitPrompt: Boolean = false,
    val userToast: String? = null
)

class ScannerViewModel(
    private val repository: PantryRepository,
    private val billingHelper: BillingHelper
) : ViewModel() {

    private val _uiState = MutableStateFlow(ScannerUiState())
    val uiState: StateFlow<ScannerUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            billingHelper.isPro.collect { isPro ->
                _uiState.update { it.copy(isProUser = isPro) }
            }
        }
    }

    fun captureAndAnalyze(bitmap: Bitmap) {
        if (_uiState.value.isAnalyzing) return

        _uiState.update { it.copy(isAnalyzing = true) }

        viewModelScope.launch {
            val result = GeminiVisionService.detectMultipleProductsFromBitmap(bitmap)
            result.onSuccess { products ->
                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        detectedProducts = products,
                        showMultiProductSheet = products.isNotEmpty()
                    )
                }
            }.onFailure { error ->
                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        userToast = error.message ?: "No se pudieron identificar alimentos en la imagen"
                    )
                }
            }
        }
    }

    fun updateProductQuantity(id: String, newQuantity: Int) {
        _uiState.update { state ->
            val updated = state.detectedProducts.map { product ->
                if (product.id == id) product.copy(quantity = newQuantity.coerceAtLeast(1))
                else product
            }
            state.copy(detectedProducts = updated)
        }
    }

    fun updateProductName(id: String, newName: String) {
        _uiState.update { state ->
            val updated = state.detectedProducts.map { product ->
                if (product.id == id) product.copy(productName = newName)
                else product
            }
            state.copy(detectedProducts = updated)
        }
    }

    fun updateProductCategory(id: String, newCategory: String) {
        _uiState.update { state ->
            val updated = state.detectedProducts.map { product ->
                if (product.id == id) product.copy(category = newCategory)
                else product
            }
            state.copy(detectedProducts = updated)
        }
    }

    fun removeDetectedProduct(id: String) {
        _uiState.update { state ->
            val updated = state.detectedProducts.filterNot { it.id == id }
            state.copy(
                detectedProducts = updated,
                showMultiProductSheet = updated.isNotEmpty()
            )
        }
    }

    fun confirmAllDetectedProducts() {
        val products = _uiState.value.detectedProducts
        if (products.isEmpty()) {
            dismissMultiProductSheet()
            return
        }

        viewModelScope.launch {
            val today = LocalDate.now()
            var totalItemsAdded = 0

            for (product in products) {
                val expiryEpoch = today.plusDays(product.shelfLifeDays.toLong().coerceAtLeast(1)).toEpochDay()
                val catClean = product.category.trim().lowercase()
                val location = when {
                    catClean.contains("lácteo") || catClean.contains("lacteo") ||
                    catClean.contains("carne") || catClean.contains("pescado") ||
                    catClean.contains("embutido") || catClean.contains("fruta") ||
                    catClean.contains("verdura") -> StorageLocation.NEVERA
                    catClean.contains("congelad") -> StorageLocation.CONGELADOR
                    else -> StorageLocation.DESPENSA
                }

                repository.addPantryItem(
                    name = product.productName,
                    barcode = null,
                    category = product.category,
                    storageLocation = location,
                    expiryDateEpochDay = expiryEpoch,
                    quantity = product.quantity,
                    unit = "unidades",
                    caloriesKcal = product.caloriesKcal.takeIf { it > 0 },
                    proteinGrams = product.proteinGrams.takeIf { it > 0f },
                    carbsGrams = product.carbsGrams.takeIf { it > 0f },
                    fatGrams = product.fatGrams.takeIf { it > 0f },
                    sugarGrams = product.sugarGrams.takeIf { it > 0f },
                    saltGrams = product.saltGrams.takeIf { it > 0f }
                )
                totalItemsAdded += product.quantity
            }

            val newCount = _uiState.value.sessionAddedCount + totalItemsAdded
            _uiState.update {
                it.copy(
                    detectedProducts = emptyList(),
                    showMultiProductSheet = false,
                    sessionAddedCount = newCount,
                    userToast = "¡Añadidos $totalItemsAdded productos a tu despensa!"
                )
            }
        }
    }

    fun dismissMultiProductSheet() {
        _uiState.update {
            it.copy(
                showMultiProductSheet = false,
                detectedProducts = emptyList()
            )
        }
    }

    fun openManualAddDialog() {
        _uiState.update { it.copy(showManualAddDialog = true) }
    }

    fun dismissManualAddDialog() {
        _uiState.update { it.copy(showManualAddDialog = false) }
    }

    fun confirmManualProduct(
        name: String,
        category: String,
        storageLocation: StorageLocation,
        quantity: Int,
        shelfLifeDays: Int,
        caloriesKcal: Int? = null,
        proteinGrams: Float? = null,
        carbsGrams: Float? = null,
        fatGrams: Float? = null,
        sugarGrams: Float? = null,
        saltGrams: Float? = null,
        imageUrl: String? = null
    ) {
        if (name.isBlank()) return

        viewModelScope.launch {
            val expiryEpoch = LocalDate.now().plusDays(shelfLifeDays.toLong().coerceAtLeast(1)).toEpochDay()
            repository.addPantryItem(
                name = name.trim(),
                barcode = null,
                category = category.trim(),
                storageLocation = storageLocation,
                expiryDateEpochDay = expiryEpoch,
                quantity = quantity.coerceAtLeast(1),
                unit = "unidades",
                imageUrl = imageUrl,
                caloriesKcal = caloriesKcal,
                proteinGrams = proteinGrams,
                carbsGrams = carbsGrams,
                fatGrams = fatGrams,
                sugarGrams = sugarGrams,
                saltGrams = saltGrams
            )

            val newCount = _uiState.value.sessionAddedCount + quantity
            _uiState.update {
                it.copy(
                    showManualAddDialog = false,
                    sessionAddedCount = newCount,
                    userToast = "\"$name\" añadido a la despensa"
                )
            }
        }
    }

    fun toggleTorch() {
        _uiState.update { it.copy(isTorchEnabled = !it.isTorchEnabled) }
    }

    fun showToast(message: String) {
        _uiState.update { it.copy(userToast = message) }
    }

    fun dismissProLimitPrompt() {
        _uiState.update { it.copy(showProLimitPrompt = false) }
    }

    fun grantRewardScans() {
        _uiState.update { it.copy(showProLimitPrompt = false, sessionAddedCount = 0) }
    }

    fun clearToast() {
        _uiState.update { it.copy(userToast = null) }
    }
}
