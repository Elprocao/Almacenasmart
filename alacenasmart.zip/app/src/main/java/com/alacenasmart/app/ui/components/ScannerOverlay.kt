package com.alacenasmart.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ScannerOverlay(
    isTorchOn: Boolean,
    onToggleTorch: () -> Unit,
    onClose: () -> Unit,
    itemsAddedCount: Int = 0,
    isQuickScan: Boolean = false,
    instructionText: String = "Apunta el marco al código de barras o usa el botón Lens para identificar",
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_laser")
    val laserOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_anim"
    )

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val width = constraints.maxWidth.toFloat()
        val height = constraints.maxHeight.toFloat()
        val frameSize = (width.coerceAtMost(height) * 0.72f).coerceIn(240f, 320f)

        val left = (width - frameSize) / 2f
        val top = (height - frameSize) / 2.3f
        val right = left + frameSize
        val bottom = top + frameSize

        Canvas(modifier = Modifier.fillMaxSize()) {
            val frameRect = RoundRect(
                Rect(left, top, right, bottom),
                CornerRadius(24.dp.toPx(), 24.dp.toPx())
            )
            val path = Path().apply {
                addRoundRect(frameRect)
            }

            clipPath(path, clipOp = ClipOp.Difference) {
                drawRect(color = Color(0x99000000))
            }

            // Draw corner markers
            val cornerLength = 32.dp.toPx()
            val stroke = 4.dp.toPx()
            val cornerColor = Color(0xFF66BB6A)

            // Top-Left
            drawLine(cornerColor, Offset(left, top + 20), Offset(left, top + cornerLength), stroke)
            drawLine(cornerColor, Offset(left, top), Offset(left + cornerLength, top), stroke)

            // Top-Right
            drawLine(cornerColor, Offset(right, top + 20), Offset(right, top + cornerLength), stroke)
            drawLine(cornerColor, Offset(right - cornerLength, top), Offset(right, top), stroke)

            // Bottom-Left
            drawLine(cornerColor, Offset(left, bottom - cornerLength), Offset(left, bottom - 20), stroke)
            drawLine(cornerColor, Offset(left, bottom), Offset(left + cornerLength, bottom), stroke)

            // Bottom-Right
            drawLine(cornerColor, Offset(right, bottom - cornerLength), Offset(right, bottom - 20), stroke)
            drawLine(cornerColor, Offset(right - cornerLength, bottom), Offset(right, bottom), stroke)

            // Animated Laser Line
            val laserY = top + (frameSize * laserOffset)
            drawLine(
                color = Color(0xCC00E676),
                start = Offset(left + 16, laserY),
                end = Offset(right - 16, laserY),
                strokeWidth = 3.dp.toPx()
            )
        }

        // Top Bar Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp, start = 20.dp, end = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledIconButton(
                onClick = onClose,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Color(0x66000000),
                    contentColor = Color.White
                ),
                modifier = Modifier.testTag("scanner_close_button")
            ) {
                Icon(Icons.Default.Close, contentDescription = "Cerrar escáner")
            }

            if (isQuickScan) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xCC1B5E20))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Rápido: $itemsAddedCount añadidos",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            FilledIconButton(
                onClick = onToggleTorch,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = if (isTorchOn) Color(0xFFFFD54F) else Color(0x66000000),
                    contentColor = if (isTorchOn) Color.Black else Color.White
                ),
                modifier = Modifier.testTag("scanner_torch_button")
            ) {
                Icon(
                    imageVector = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                    contentDescription = "Linterna"
                )
            }
        }

        // Bottom Instructions
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 64.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xAA000000))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text(
                    text = instructionText,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
