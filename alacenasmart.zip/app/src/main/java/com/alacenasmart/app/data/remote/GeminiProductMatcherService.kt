package com.alacenasmart.app.data.remote

import com.alacenasmart.app.BuildConfig
import com.alacenasmart.app.domain.model.StorageLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class ProductMatchOption(
    val title: String,
    val brandOrCategory: String,
    val storageLocation: StorageLocation,
    val shelfLifeDays: Int,
    val imageUrl: String
)

object GeminiProductMatcherService {

    private const val MODEL = "gemini-2.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    // High quality Curated Fallback image map with reliable Unsplash Food photos
    private val fallbackImageMap = mapOf(
        "leche" to "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&q=80",
        "queso" to "https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?w=400&q=80",
        "yogur" to "https://images.unsplash.com/photo-1571212515416-fef01fc43637?w=400&q=80",
        "huevo" to "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?w=400&q=80",
        "manzana" to "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&q=80",
        "platano" to "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400&q=80",
        "tomate" to "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=400&q=80",
        "pollo" to "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&q=80",
        "carne" to "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&q=80",
        "pescado" to "https://images.unsplash.com/photo-1534939561126-855b8675edd7?w=400&q=80",
        "arroz" to "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&q=80",
        "pasta" to "https://images.unsplash.com/photo-1621996346565-e3d5d6281691?w=400&q=80",
        "pan" to "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&q=80",
        "cafe" to "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&q=80",
        "aceite" to "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&q=80",
        "agua" to "https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=400&q=80",
        "vino" to "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=400&q=80",
        "cerveza" to "https://images.unsplash.com/photo-1608270116666-5062f6b896b0?w=400&q=80",
        "galleta" to "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400&q=80",
        "chocolate" to "https://images.unsplash.com/photo-1511381939415-e44015466834?w=400&q=80",
        "patata" to "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&q=80",
        "cebolla" to "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&q=80",
        "zanahoria" to "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=400&q=80",
        "naranja" to "https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?w=400&q=80",
        "limon" to "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=400&q=80"
    )

    fun resolvePhotoUrl(keyword: String): String {
        val clean = keyword.lowercase()
        for ((k, url) in fallbackImageMap) {
            if (clean.contains(k)) return url
        }
        val encoded = try {
            URLEncoder.encode(keyword.trim(), "UTF-8")
        } catch (_: Exception) {
            keyword.trim().replace(" ", "+")
        }
        return "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&q=80"
    }

    suspend fun analyzeAndFindOptions(userInput: String): List<ProductMatchOption> = withContext(Dispatchers.IO) {
        val cleanInput = userInput.trim()
        if (cleanInput.isBlank()) return@withContext emptyList()

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext generateLocalOptions(cleanInput)
        }

        try {
            val prompt = """
                El usuario ha escrito: "$cleanInput".
                Actúa como un motor de búsqueda de productos de supermercado tipo Google Lens / Catálogo de compra.
                Devuelve un array JSON con 3 a 5 opciones concretas y realistas de productos que coincidan con lo que el usuario quiso decir (variedades comunes, marcas habituales o tipos específicos).
                
                Para cada opción proporciona:
                - title: Nombre específico del producto (ej: "Leche Entera Pascual 1L", "Leche Desnatada Hacendado", "Leche de Avena Alpro")
                - category: Una de ["Lácteos", "Carnes", "Frutas y verduras", "Congelados", "Despensa", "Bebidas", "Varios"]
                - storageLocation: Uno de ["NEVERA", "CONGELADOR", "DESPENSA"]
                - shelfLifeDays: Días típicos de caducidad (entero, ej: 10 para leche, 4 para carne fresca, 180 para despensa)
                - imageKeyword: Palabra clave en inglés para buscar su foto en internet (ej: "milk bottle", "skim milk", "oat milk carton", "red apples", "chicken breast")
                
                Responde ÚNICAMENTE un JSON array con esta estructura:
                [
                  {
                    "title": "...",
                    "category": "...",
                    "storageLocation": "...",
                    "shelfLifeDays": 10,
                    "imageKeyword": "..."
                  }
                ]
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contents = JSONArray().apply {
                    val partObj = JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    }
                    put(partObj)
                }
                put("contents", contents)

                val config = JSONObject().apply {
                    put("temperature", 0.3)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", config)
            }

            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext generateLocalOptions(cleanInput)
            }

            val responseBody = response.body?.string() ?: return@withContext generateLocalOptions(cleanInput)
            val jsonRoot = JSONObject(responseBody)
            val candidates = jsonRoot.optJSONArray("candidates") ?: return@withContext generateLocalOptions(cleanInput)
            if (candidates.length() == 0) return@withContext generateLocalOptions(cleanInput)

            val text = candidates.getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")

            val jsonArray = JSONArray(text.trim())
            val results = mutableListOf<ProductMatchOption>()

            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val title = obj.getString("title")
                val category = obj.optString("category", "Despensa")
                val locationStr = obj.optString("storageLocation", "DESPENSA")
                val location = when (locationStr.uppercase()) {
                    "NEVERA" -> StorageLocation.NEVERA
                    "CONGELADOR" -> StorageLocation.CONGELADOR
                    else -> StorageLocation.DESPENSA
                }
                val shelfLife = obj.optInt("shelfLifeDays", 14)
                val imgKey = obj.optString("imageKeyword", title)
                val imageUrl = resolvePhotoUrl(imgKey)

                results.add(
                    ProductMatchOption(
                        title = title,
                        brandOrCategory = category,
                        storageLocation = location,
                        shelfLifeDays = shelfLife,
                        imageUrl = imageUrl
                    )
                )
            }

            if (results.isNotEmpty()) results else generateLocalOptions(cleanInput)
        } catch (_: Exception) {
            generateLocalOptions(cleanInput)
        }
    }

    private fun generateLocalOptions(input: String): List<ProductMatchOption> {
        val clean = input.trim()
        val lower = clean.lowercase()

        val (category, location, days) = when {
            lower.contains("leche") || lower.contains("queso") || lower.contains("yogur") || lower.contains("mantequilla") ->
                Triple("Lácteos", StorageLocation.NEVERA, 12)
            lower.contains("carne") || lower.contains("pollo") || lower.contains("ternera") || lower.contains("pescado") ->
                Triple("Carnes", StorageLocation.NEVERA, 4)
            lower.contains("manzana") || lower.contains("platano") || lower.contains("fruta") || lower.contains("verdura") || lower.contains("tomate") ->
                Triple("Frutas y verduras", StorageLocation.NEVERA, 8)
            lower.contains("helado") || lower.contains("congelad") || lower.contains("pizza") ->
                Triple("Congelados", StorageLocation.CONGELADOR, 180)
            lower.contains("agua") || lower.contains("cerveza") || lower.contains("vino") || lower.contains("zumo") || lower.contains("refresco") ->
                Triple("Bebidas", StorageLocation.DESPENSA, 90)
            else ->
                Triple("Despensa", StorageLocation.DESPENSA, 60)
        }

        val photoUrl = resolvePhotoUrl(clean)

        return listOf(
            ProductMatchOption(
                title = clean.replaceFirstChar { it.uppercase() },
                brandOrCategory = category,
                storageLocation = location,
                shelfLifeDays = days,
                imageUrl = photoUrl
            ),
            ProductMatchOption(
                title = "${clean.replaceFirstChar { it.uppercase() }} (Estándar / Marca Blanca)",
                brandOrCategory = category,
                storageLocation = location,
                shelfLifeDays = days,
                imageUrl = photoUrl
            ),
            ProductMatchOption(
                title = "${clean.replaceFirstChar { it.uppercase() }} Especial / Selección",
                brandOrCategory = category,
                storageLocation = location,
                shelfLifeDays = (days * 1.5).toInt(),
                imageUrl = photoUrl
            )
        )
    }
}
