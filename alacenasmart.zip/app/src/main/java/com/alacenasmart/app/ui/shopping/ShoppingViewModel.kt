package com.alacenasmart.app.ui.shopping

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alacenasmart.app.data.local.entity.ShoppingItemEntity
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.domain.repository.PantryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

data class ShoppingUiState(
    val items: List<ShoppingItemEntity> = emptyList(),
    val totalCount: Int = 0,
    val checkedCount: Int = 0,
    val isAddDialogOpen: Boolean = false,
    val isInShoppingMode: Boolean = false,
    val snackbarMessage: String? = null
)

class ShoppingViewModel(
    private val repository: PantryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ShoppingUiState())
    val uiState: StateFlow<ShoppingUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getShoppingItems().collect { items ->
                _uiState.update {
                    it.copy(
                        items = items,
                        totalCount = items.size,
                        checkedCount = items.count { item -> item.isChecked }
                    )
                }
            }
        }
    }

    fun toggleItem(item: ShoppingItemEntity) {
        viewModelScope.launch {
            repository.toggleShoppingItem(item.id, !item.isChecked)
        }
    }

    fun addItem(name: String, category: String, quantity: Int = 1, imageUrl: String? = null) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val safeQuantity = quantity.coerceAtLeast(1)
            repository.addShoppingItem(
                name = name.trim(),
                category = category.trim(),
                quantity = safeQuantity,
                imageUrl = imageUrl
            )
            _uiState.update {
                it.copy(
                    isAddDialogOpen = false,
                    snackbarMessage = "\"$name\" ($safeQuantity uds) añadido a la lista"
                )
            }
        }
    }

    fun deleteItem(item: ShoppingItemEntity) {
        viewModelScope.launch {
            repository.deleteShoppingItem(item.id)
        }
    }

    fun clearChecked() {
        viewModelScope.launch {
            repository.clearCheckedShoppingItems()
            _uiState.update { it.copy(snackbarMessage = "Productos comprados eliminados") }
        }
    }

    fun startShoppingMode() {
        _uiState.update { it.copy(isInShoppingMode = true) }
    }

    fun exitShoppingMode() {
        _uiState.update { it.copy(isInShoppingMode = false) }
    }

    fun finishShoppingAndAddToPantry() {
        viewModelScope.launch {
            val checkedItems = _uiState.value.items.filter { it.isChecked }
            if (checkedItems.isEmpty()) {
                _uiState.update {
                    it.copy(
                        isInShoppingMode = false,
                        snackbarMessage = "No marcaste ningún producto con tick"
                    )
                }
                return@launch
            }

            val today = LocalDate.now().toEpochDay()
            var totalAddedUnits = 0

            for (item in checkedItems) {
                val catClean = item.category.lowercase()
                val shelfDays = when {
                    catClean.contains("lácteo") || catClean.contains("lacteo") -> 12L
                    catClean.contains("carne") || catClean.contains("pescado") -> 4L
                    catClean.contains("fruta") || catClean.contains("verdura") -> 8L
                    catClean.contains("congelad") -> 180L
                    else -> 60L
                }
                val location = when {
                    catClean.contains("lácteo") || catClean.contains("lacteo") ||
                    catClean.contains("carne") || catClean.contains("pescado") ||
                    catClean.contains("fruta") || catClean.contains("verdura") -> StorageLocation.NEVERA
                    catClean.contains("congelad") -> StorageLocation.CONGELADOR
                    else -> StorageLocation.DESPENSA
                }

                repository.addPantryItem(
                    name = item.name,
                    barcode = null,
                    category = item.category,
                    storageLocation = location,
                    expiryDateEpochDay = today + shelfDays,
                    quantity = item.quantity.coerceAtLeast(1),
                    unit = "unidades",
                    imageUrl = item.imageUrl
                )
                totalAddedUnits += item.quantity
                repository.deleteShoppingItem(item.id)
            }

            _uiState.update {
                it.copy(
                    isInShoppingMode = false,
                    snackbarMessage = "¡Compra finalizada! Se han añadido $totalAddedUnits productos a tu despensa automáticamente."
                )
            }
        }
    }

    fun openAddDialog() {
        _uiState.update { it.copy(isAddDialogOpen = true) }
    }

    fun closeAddDialog() {
        _uiState.update { it.copy(isAddDialogOpen = false) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
