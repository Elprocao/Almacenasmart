package com.alacenasmart.app.ui.pantry

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alacenasmart.app.billing.BillingHelper
import com.alacenasmart.app.data.util.PantryTxtFormatUtil
import com.alacenasmart.app.domain.model.ExpiryState
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.domain.repository.PantryRepository
import com.alacenasmart.app.domain.usecase.ToggleItemConsumedUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

class PantryViewModel(
    private val repository: PantryRepository,
    private val billingHelper: BillingHelper,
    private val toggleItemConsumedUseCase: ToggleItemConsumedUseCase = ToggleItemConsumedUseCase(repository)
) : ViewModel() {

    private val _uiState = MutableStateFlow(PantryUiState())
    val uiState: StateFlow<PantryUiState> = _uiState.asStateFlow()

    private val _rawItems = repository.getPantryItems()

    init {
        viewModelScope.launch {
            combine(_rawItems, billingHelper.isPro) { items, isPro ->
                Pair(items, isPro)
            }.collect { (items, isPro) ->
                val expiringSoon = items.count { it.expiryStatus.daysRemaining in 0L..2L }
                val expired = items.count { it.expiryStatus.state == ExpiryState.EXPIRED }

                _uiState.update { current ->
                    current.copy(
                        items = filterItems(items, current.selectedLocation, current.selectedCategory, current.searchQuery),
                        totalCount = items.size,
                        expiringSoonCount = expiringSoon,
                        expiredCount = expired,
                        isProUser = isPro,
                        isLoading = false
                    )
                }
            }
        }
    }

    private fun filterItems(
        allItems: List<PantryItem>,
        location: StorageLocation?,
        category: String?,
        query: String
    ): List<PantryItem> {
        return allItems.filter { item ->
            val matchLocation = location == null || item.storageLocation == location
            val matchCategory = category == null || item.category.equals(category, ignoreCase = true)
            val matchQuery = query.isBlank() || item.name.contains(query, ignoreCase = true) || item.category.contains(query, ignoreCase = true)
            matchLocation && matchCategory && matchQuery
        }
    }

    fun setLocationFilter(location: StorageLocation?) {
        viewModelScope.launch {
            _uiState.update { current ->
                val newLoc = if (current.selectedLocation == location) null else location
                current.copy(
                    selectedLocation = newLoc,
                    items = filterItems(repositoryItemsCached(), newLoc, current.selectedCategory, current.searchQuery)
                )
            }
        }
    }

    fun setCategoryFilter(category: String?) {
        viewModelScope.launch {
            _uiState.update { current ->
                val newCat = if (current.selectedCategory == category) null else category
                current.copy(
                    selectedCategory = newCat,
                    items = filterItems(repositoryItemsCached(), current.selectedLocation, newCat, current.searchQuery)
                )
            }
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { current ->
            current.copy(
                searchQuery = query,
                items = filterItems(repositoryItemsCached(), current.selectedLocation, current.selectedCategory, query)
            )
        }
    }

    private fun repositoryItemsCached(): List<PantryItem> {
        return _uiState.value.items // filtered, but in re-filter fallback
    }

    fun openAddDialog() {
        _uiState.update { it.copy(isAddEditDialogOpen = true, editingItem = null) }
    }

    fun openEditDialog(item: PantryItem) {
        _uiState.update { it.copy(isAddEditDialogOpen = true, editingItem = item) }
    }

    fun closeAddEditDialog() {
        _uiState.update { it.copy(isAddEditDialogOpen = false, editingItem = null) }
    }

    fun savePantryItem(
        id: Long,
        name: String,
        barcode: String?,
        category: String,
        storageLocation: StorageLocation,
        expiryDateEpochDay: Long,
        quantity: Int,
        unit: String,
        imageUrl: String? = null
    ) {
        viewModelScope.launch {
            if (id == 0L) {
                repository.addPantryItem(
                    name = name,
                    barcode = barcode,
                    category = category,
                    storageLocation = storageLocation,
                    expiryDateEpochDay = expiryDateEpochDay,
                    quantity = quantity,
                    unit = unit,
                    imageUrl = imageUrl
                )
                _uiState.update { it.copy(userMessage = "Alimento \"$name\" añadido") }
            } else {
                val current = repository.getItemById(id)
                if (current != null) {
                    val updated = current.copy(
                        name = name,
                        barcode = barcode,
                        category = category,
                        storageLocation = storageLocation,
                        expiryDateEpochDay = expiryDateEpochDay,
                        quantity = quantity,
                        unit = unit,
                        imageUrl = imageUrl ?: current.imageUrl
                    )
                    repository.updatePantryItem(updated)
                    _uiState.update { it.copy(userMessage = "Alimento actualizado") }
                }
            }
            closeAddEditDialog()
        }
    }

    fun consumeItem(item: PantryItem, addToShopping: Boolean = true) {
        viewModelScope.launch {
            toggleItemConsumedUseCase(
                pantryItemId = item.id,
                isConsumed = true,
                addToShoppingList = addToShopping
            )
            val msg = if (addToShopping) {
                "\"${item.name}\" consumido y añadido a lista de compras"
            } else {
                "\"${item.name}\" marcado como consumido"
            }
            _uiState.update { it.copy(userMessage = msg) }
        }
    }

    fun promptDiscard(item: PantryItem) {
        _uiState.update { it.copy(itemToDiscard = item) }
    }

    fun dismissDiscardPrompt() {
        _uiState.update { it.copy(itemToDiscard = null) }
    }

    fun confirmDiscard() {
        val item = _uiState.value.itemToDiscard ?: return
        viewModelScope.launch {
            repository.deletePantryItem(item.id)
            _uiState.update { it.copy(itemToDiscard = null, userMessage = "\"${item.name}\" desechado") }
        }
    }

    fun addToShoppingList(item: PantryItem) {
        viewModelScope.launch {
            repository.addShoppingItem(
                name = item.name,
                category = item.category,
                originPantryItemId = item.id
            )
            _uiState.update { it.copy(userMessage = "\"${item.name}\" añadido a la lista de compras") }
        }
    }

    fun exportToTxt(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val allItems = _uiState.value.items
            val txt = PantryTxtFormatUtil.exportToTxt(allItems)
            onResult(txt)
        }
    }

    fun importFromTxt(content: String, onComplete: (Int) -> Unit) {
        viewModelScope.launch {
            val entities = PantryTxtFormatUtil.parseFromTxt(content)
            if (entities.isNotEmpty()) {
                val count = repository.importPantryItems(entities)
                _uiState.update { it.copy(userMessage = "Se han importado $count alimentos exitosamente") }
                onComplete(count)
            } else {
                _uiState.update { it.copy(userMessage = "No se encontraron alimentos válidos en el archivo TXT") }
                onComplete(0)
            }
        }
    }

    fun clearUserMessage() {
        _uiState.update { it.copy(userMessage = null) }
    }
}
