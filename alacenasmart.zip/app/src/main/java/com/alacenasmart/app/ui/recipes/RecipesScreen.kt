package com.alacenasmart.app.ui.recipes

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alacenasmart.app.AlacenaApp
import com.alacenasmart.app.domain.model.DietaryPreference
import com.alacenasmart.app.domain.model.Recipe
import com.alacenasmart.app.ui.components.AdBannerView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipesScreen(
    viewModel: RecipesViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    fun triggerGenerationWithAdCheck(pref: DietaryPreference) {
        val act = context as? Activity
        if (act != null) {
            AlacenaApp.instance.adFrequencyManager.incrementUserActionAndShowAdIfDue(act) {
                viewModel.generateRecipesWithPreference(pref)
            }
        } else {
            viewModel.generateRecipesWithPreference(pref)
        }
    }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Recetas Inteligentes",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "100% cocinables con tu despensa • Temporizadores y raciones adaptables",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Primary Tabs: AI Discover vs Recipe Book
            TabRow(
                selectedTabIndex = if (uiState.currentTab == RecipeTab.DISCOVER_AI) 0 else 1,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = (uiState.currentTab == RecipeTab.DISCOVER_AI),
                    onClick = { viewModel.setTab(RecipeTab.DISCOVER_AI) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Generador IA", fontWeight = FontWeight.SemiBold)
                        }
                    }
                )
                Tab(
                    selected = (uiState.currentTab == RecipeTab.RECIPE_BOOK),
                    onClick = { viewModel.setTab(RecipeTab.RECIPE_BOOK) },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.MenuBook,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Libro de Recetas (${uiState.savedRecipes.size})", fontWeight = FontWeight.SemiBold)
                        }
                    }
                )
            }

            // Active Floating Step Timer banner if running
            uiState.activeTimer?.let { timer ->
                Surface(
                    color = if (timer.isFinished) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.tertiaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                if (timer.isFinished) Icons.Default.Alarm else Icons.Default.Schedule,
                                contentDescription = null,
                                tint = if (timer.isFinished) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onTertiaryContainer
                            )
                            Column {
                                Text(
                                    text = if (timer.isFinished) "🔔 ¡TIEMPO CUMPLIDO!" else "Temporizador: ${timer.title}",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (timer.isFinished) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onTertiaryContainer
                                )
                                val mins = timer.remainingSeconds / 60
                                val secs = timer.remainingSeconds % 60
                                Text(
                                    text = String.format("%02d:%02d restantes", mins, secs),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (timer.isFinished) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                        IconButton(onClick = { viewModel.stopTimer() }) {
                            Icon(Icons.Default.Close, contentDescription = "Detener temporizador")
                        }
                    }
                }
            }

            when (uiState.currentTab) {
                RecipeTab.DISCOVER_AI -> {
                    AiRecipesTabContent(
                        uiState = uiState,
                        onOpenPreferences = { viewModel.openPreferencesMenu() },
                        onSelectExpiringMode = {
                            triggerGenerationWithAdCheck(DietaryPreference.EXPIRING_PRIORITY)
                        },
                        onRecipeSelected = { viewModel.selectRecipe(it) },
                        onToggleSave = { viewModel.toggleSaveRecipe(it) },
                        onToggleFavorite = { viewModel.toggleFavoriteRecipe(it) }
                    )
                }
                RecipeTab.RECIPE_BOOK -> {
                    RecipeBookTabContent(
                        uiState = uiState,
                        onToggleFavoritesOnly = { viewModel.toggleFavoritesOnlyFilter() },
                        onRecipeSelected = { viewModel.selectRecipe(it) },
                        onToggleSave = { viewModel.toggleSaveRecipe(it) },
                        onToggleFavorite = { viewModel.toggleFavoriteRecipe(it) }
                    )
                }
            }
        }
    }

    // Modal Preferences Sheet (Dietary filters, Expiring Rescue, etc.)
    if (uiState.isPreferencesSheetOpen) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.closePreferencesMenu() },
            sheetState = rememberModalBottomSheetState()
        ) {
            RecipePreferencesSheetContent(
                selectedPref = uiState.selectedDietaryPreference,
                expiringCount = uiState.expiringItemsCount,
                onSelectPreference = { pref ->
                    triggerGenerationWithAdCheck(pref)
                },
                onClose = { viewModel.closePreferencesMenu() }
            )
        }
    }

    // Recipe Detail Modal Bottom Sheet
    uiState.selectedRecipe?.let { recipe ->
        ModalBottomSheet(
            onDismissRequest = { viewModel.selectRecipe(null) },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            RecipeDetailSheetContent(
                recipe = recipe,
                scaledServings = uiState.scaledServings,
                onServingsChange = { viewModel.setScaledServings(it) },
                onStartTimer = { minutes, title -> viewModel.startStepTimer(minutes, title) },
                onClose = { viewModel.selectRecipe(null) },
                onToggleSave = { viewModel.toggleSaveRecipe(recipe) },
                onToggleFavorite = { viewModel.toggleFavoriteRecipe(recipe) },
                onCook = { viewModel.cookRecipe(recipe) }
            )
        }
    }
}

@Composable
fun AiRecipesTabContent(
    uiState: RecipesUiState,
    onOpenPreferences: () -> Unit,
    onSelectExpiringMode: () -> Unit,
    onRecipeSelected: (Recipe) -> Unit,
    onToggleSave: (Recipe) -> Unit,
    onToggleFavorite: (Recipe) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Priority rescue banner if products are expiring in 2 days or less
        if (uiState.expiringItemsCount > 0) {
            Surface(
                color = Color(0xFFFFF3E0),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectExpiringMode() }
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFE65100),
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = "Modo Aprovechamiento Rápido",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color(0xFFE65100)
                            )
                            Text(
                                text = "Tienes ${uiState.expiringItemsCount} productos a punto de caducar. Pulsa para generar recetas de rescate.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF5D4037)
                            )
                        }
                    }
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color(0xFFE65100)
                    )
                }
            }
        }

        // Action Sub-bar with "Generar Recetas" Menu button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Filtro: ${uiState.selectedDietaryPreference.label}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Button(
                onClick = onOpenPreferences,
                enabled = !uiState.isAiGenerating,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier.testTag("open_recipe_menu_button")
            ) {
                if (uiState.isAiGenerating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                } else {
                    Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (uiState.generatedRecipes.isEmpty()) "Generar 5 Recetas" else "Cambiar Menú / Filtros",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        if (uiState.isAiGenerating) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "Creando 5 recetas a medida con tu despensa...",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Aplicando filtro: ${uiState.selectedDietaryPreference.label}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else if (uiState.generatedRecipes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Restaurant,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Genera tus recetas personalizadas",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Pulsa el botón 'Generar 5 Recetas' para elegir tus filtros (Aprovechamiento, Fitness, Rápidas, etc.) y crear recetas 100% cocinables con tu despensa.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = onOpenPreferences,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Abrir Menú de Selección")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(uiState.generatedRecipes, key = { it.id }) { recipe ->
                    RecipeCardItem(
                        recipe = recipe,
                        onClick = { onRecipeSelected(recipe) },
                        onToggleSave = { onToggleSave(recipe) },
                        onToggleFavorite = { onToggleFavorite(recipe) }
                    )
                }
            }
        }
    }
}

@Composable
fun RecipePreferencesSheetContent(
    selectedPref: DietaryPreference,
    expiringCount: Int,
    onSelectPreference: (DietaryPreference) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp)
            .padding(bottom = 32.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Menú de Selección de Recetas",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Cerrar")
            }
        }

        Text(
            text = "Elige la preferencia para que la IA diseñe 5 recetas a medida:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(18.dp))

        DietaryPreference.values().forEach { pref ->
            val isSelected = (pref == selectedPref)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .clickable { onSelectPreference(pref) },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = pref.label,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (pref == DietaryPreference.EXPIRING_PRIORITY && expiringCount > 0) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFE65100)
                                ) {
                                    Text(
                                        text = "$expiringCount urgentes",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = pref.promptInstruction,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
fun RecipeBookTabContent(
    uiState: RecipesUiState,
    onToggleFavoritesOnly: () -> Unit,
    onRecipeSelected: (Recipe) -> Unit,
    onToggleSave: (Recipe) -> Unit,
    onToggleFavorite: (Recipe) -> Unit
) {
    val displayList = if (uiState.bookFilterFavoritesOnly) {
        uiState.savedRecipes.filter { it.isFavorite }
    } else {
        uiState.savedRecipes
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = !uiState.bookFilterFavoritesOnly,
                onClick = { if (uiState.bookFilterFavoritesOnly) onToggleFavoritesOnly() },
                label = { Text("Todas las guardadas (${uiState.savedRecipes.size})") }
            )
            FilterChip(
                selected = uiState.bookFilterFavoritesOnly,
                onClick = { if (!uiState.bookFilterFavoritesOnly) onToggleFavoritesOnly() },
                leadingIcon = {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = null,
                        tint = Color(0xFFFFB300),
                        modifier = Modifier.size(16.dp)
                    )
                },
                label = { Text("Favoritas ⭐") }
            )
        }

        if (displayList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.MenuBook,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (uiState.bookFilterFavoritesOnly) "No tienes recetas favoritas" else "Tu Libro de Recetas está vacío",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Guarda las recetas generadas por la IA pulsando el icono del marcador de páginas para consultarlas siempre que quieras.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(displayList, key = { it.id }) { recipe ->
                    RecipeCardItem(
                        recipe = recipe,
                        onClick = { onRecipeSelected(recipe) },
                        onToggleSave = { onToggleSave(recipe) },
                        onToggleFavorite = { onToggleFavorite(recipe) }
                    )
                }
            }
        }
    }
}

@Composable
fun RecipeCardItem(
    recipe: Recipe,
    onClick: () -> Unit,
    onToggleSave: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("recipe_card_${recipe.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = recipe.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = recipe.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (recipe.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorito",
                            tint = if (recipe.isFavorite) Color(0xFFE91E63) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onToggleSave) {
                        Icon(
                            if (recipe.isSaved) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Guardar",
                            tint = if (recipe.isSaved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Pills row (Time, Servings, Category, Difficulty)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RecipePill("⏱️ ${recipe.prepTimeMinutes} min")
                RecipePill("👥 ${recipe.servings} pers.")
                RecipePill("🍽️ ${recipe.category}")
                RecipePill("⚡ ${recipe.difficulty}")
                if (recipe.cookingTemp != null) {
                    RecipePill("🔥 ${recipe.cookingTemp}")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Ingredients preview
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NutritionItemCompact("Calorías", "${recipe.caloriesKcal} kcal")
                    NutritionItemCompact("Proteínas", "${recipe.proteinGrams} g")
                    NutritionItemCompact("Hidratos", "${recipe.carbsGrams} g")
                    NutritionItemCompact("Grasas", "${recipe.fatGrams} g")
                }
            }
        }
    }
}

@Composable
fun RecipePill(text: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun NutritionItemCompact(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 9.sp)
    }
}

@Composable
fun RecipeDetailSheetContent(
    recipe: Recipe,
    scaledServings: Int,
    onServingsChange: (Int) -> Unit,
    onStartTimer: (minutes: Int, stepTitle: String) -> Unit,
    onClose: () -> Unit,
    onToggleSave: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCook: () -> Unit
) {
    val scaleFactor = scaledServings.toDouble() / (if (recipe.servings > 0) recipe.servings.toDouble() else 2.0)

    fun scaleIngredientText(rawText: String): String {
        val numberRegex = Regex("""^(\d+(?:[.,]\d+)?)\s*(g|ml|l|kg|unidades|uds|cucharadas|cuchara)?""", RegexOption.IGNORE_CASE)
        val match = numberRegex.find(rawText.trim())
        if (match != null) {
            val numStr = match.groupValues[1].replace(',', '.')
            val num = numStr.toDoubleOrNull()
            if (num != null) {
                val scaledNum = num * scaleFactor
                val formatted = if (scaledNum % 1.0 == 0.0) scaledNum.toInt().toString() else String.format("%.1f", scaledNum)
                val unit = match.groupValues[2]
                val remainder = rawText.trim().substring(match.range.last + 1)
                return "$formatted $unit$remainder".trim()
            }
        }
        return rawText
    }

    fun extractTimerMinutesFromStep(stepText: String): Int? {
        val regex = Regex("""(?:durante|por|cocer|hervir|hornear|esperar|reposar)\s+(\d+)\s*(?:min|minuto|minutos)""", RegexOption.IGNORE_CASE)
        val match = regex.find(stepText)
        if (match != null) {
            return match.groupValues[1].toIntOrNull()
        }
        val generalRegex = Regex("""(\d+)\s*(?:min|minutos)""", RegexOption.IGNORE_CASE)
        val genMatch = generalRegex.find(stepText)
        return genMatch?.groupValues?.get(1)?.toIntOrNull()
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(bottom = 32.dp)
    ) {
        // Top Action Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        if (recipe.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorito",
                        tint = if (recipe.isFavorite) Color(0xFFE91E63) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onToggleSave) {
                    Icon(
                        if (recipe.isSaved) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Guardar",
                        tint = if (recipe.isSaved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Cerrar")
            }
        }

        Text(
            text = recipe.title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = recipe.description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Dynamic Servings Scaler Selector (1, 2, 4, 6)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
            )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Escalador Dinámico de Raciones",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$scaledServings personas",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1, 2, 4, 6).forEach { num ->
                        val isSelected = (scaledServings == num)
                        FilterChip(
                            selected = isSelected,
                            onClick = { onServingsChange(num) },
                            label = { Text("$num pers.") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Key Specs Matrix
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            RecipeSpecBox(title = "Raciones", value = "$scaledServings pers.")
            RecipeSpecBox(title = "Cocción", value = "${recipe.prepTimeMinutes} min")
            RecipeSpecBox(title = "Reposo", value = "${recipe.restTimeMinutes} min")
            RecipeSpecBox(title = "Temperatura", value = recipe.cookingTemp ?: "Media")
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Measured Ingredients Section
        Text(
            text = "Ingredientes Reescalados ($scaledServings pers.)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Cantidades adaptadas automáticamente:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(8.dp))

        recipe.requiredIngredients.forEach { rawIng ->
            val scaledText = scaleIngredientText(rawIng)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = scaledText,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Step by Step Preparation with Timer detection
        Text(
            text = "Preparación Detallada y Temporizadores",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(10.dp))

        recipe.steps.forEachIndexed { index, step ->
            val detectedMinutes = extractTimerMinutesFromStep(step)

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = step,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (detectedMinutes != null && detectedMinutes > 0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                onStartTimer(detectedMinutes, "Paso ${index + 1} ($detectedMinutes min)")
                            },
                            modifier = Modifier.align(Alignment.End),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Poner alarma $detectedMinutes min",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Complete Nutritional Breakdown Table at the end
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        Icons.Default.LocalFireDepartment,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Información Nutricional (por ración)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    NutritionalTableItem("Calorías", "${recipe.caloriesKcal} kcal")
                    NutritionalTableItem("Proteínas", "${recipe.proteinGrams} g")
                    NutritionalTableItem("Hidratos", "${recipe.carbsGrams} g")
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    NutritionalTableItem("Grasas", "${recipe.fatGrams} g")
                    NutritionalTableItem("Azúcares", "${recipe.sugarGrams} g")
                    NutritionalTableItem("Sal", "${recipe.saltGrams} g")
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Cook button
        Button(
            onClick = onCook,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("cook_recipe_button"),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Default.Check, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "He cocinado esta receta (Descontar de despensa)",
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun RecipeSpecBox(title: String, value: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.width(78.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 10.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun NutritionalTableItem(title: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
        Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
