package com.alacenasmart.app.domain.model

data class PantryItem(
    val id: Long = 0,
    val name: String,
    val barcode: String? = null,
    val category: String,
    val storageLocation: StorageLocation,
    val expiryDateEpochDay: Long,
    val quantity: Int = 1,
    val unit: String = "unidades",
    val isConsumed: Boolean = false,
    val addedTimestamp: Long = System.currentTimeMillis(),
    val expiryStatus: ExpiryStatus,
    val imageUrl: String? = null,
    val caloriesKcal: Int? = null,
    val proteinGrams: Float? = null,
    val carbsGrams: Float? = null,
    val fatGrams: Float? = null,
    val sugarGrams: Float? = null,
    val saltGrams: Float? = null
)
