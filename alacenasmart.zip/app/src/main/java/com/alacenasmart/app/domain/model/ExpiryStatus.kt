package com.alacenasmart.app.domain.model

enum class TrafficLightColor {
    RED,
    YELLOW,
    GREEN
}

enum class ExpiryState(val label: String) {
    EXPIRED("Caducado"),
    EXPIRES_TODAY("Caduca hoy"),
    EXPIRING_SOON("Próximo a caducar"),
    GOOD("En buen estado")
}

data class ExpiryStatus(
    val daysRemaining: Long,
    val state: ExpiryState,
    val trafficLight: TrafficLightColor,
    val displayMessage: String
) {
    companion object {
        fun calculate(expiryDateEpochDay: Long, currentEpochDay: Long): ExpiryStatus {
            val days = expiryDateEpochDay - currentEpochDay
            val state = when {
                days < 0 -> ExpiryState.EXPIRED
                days == 0L -> ExpiryState.EXPIRES_TODAY
                days in 1L..6L -> ExpiryState.EXPIRING_SOON
                else -> ExpiryState.GOOD
            }

            val traffic = when {
                days <= 2 -> TrafficLightColor.RED
                days in 3L..6L -> TrafficLightColor.YELLOW
                else -> TrafficLightColor.GREEN
            }

            val message = when {
                days < -1 -> "Caducó hace ${-days} días"
                days == -1L -> "Caducó ayer"
                days == 0L -> "Caduca hoy"
                days == 1L -> "Caduca mañana"
                else -> "$days días restantes"
            }

            return ExpiryStatus(
                daysRemaining = days,
                state = state,
                trafficLight = traffic,
                displayMessage = message
            )
        }
    }
}
