package com.alacenasmart.app.workers

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.alacenasmart.app.MainActivity
import com.alacenasmart.app.R
import com.alacenasmart.app.data.local.AppDatabase
import java.time.LocalDate
import java.util.concurrent.TimeUnit

class ExpiryNotificationWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val prefs = context.getSharedPreferences("alacenasmart_settings", Context.MODE_PRIVATE)
        val notificationsEnabled = prefs.getBoolean("key_notifications_enabled", true)
        if (!notificationsEnabled) {
            return Result.success()
        }

        val database = AppDatabase.getInstance(context)
        val today = LocalDate.now().toEpochDay()
        val in48Hours = today + 2

        val expiringItems = database.pantryDao().getExpiringItemsSync(in48Hours)
        if (expiringItems.isEmpty()) {
            return Result.success()
        }

        sendNotification(expiringItems.map { it.name })
        return Result.success()
    }

    private fun sendNotification(itemNames: List<String>) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelId = "pantry_expiry_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Avisos de Caducidad",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notificaciones diarias sobre alimentos próximos a caducar"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val count = itemNames.size
        val title = if (count == 1) {
            "Tienes 1 alimento por caducar en 48 horas"
        } else {
            "Tienes $count alimentos por caducar en las próximas 48 horas"
        }

        val itemsSummary = itemNames.take(3).joinToString(separator = "\n") { "• $it" }
        val message = "$itemsSummary\n\n¡Aprovéchalos hoy!"

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_START_DESTINATION", "recipes")
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.alacenasmart_icon_1788877685934)
            .setContentTitle(title)
            .setContentText("Abre AlacenaSmart para ver recetas zero-waste")
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                R.drawable.alacenasmart_icon_1788877685934,
                "Ver recetas",
                pendingIntent
            )
            .build()

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            notificationManager.notify(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val NOTIFICATION_ID = 2001
        private const val WORK_NAME = "ExpiryNotificationDailyWork"

        fun scheduleDaily(context: Context) {
            val workRequest = PeriodicWorkRequestBuilder<ExpiryNotificationWorker>(
                24, TimeUnit.HOURS
            ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
