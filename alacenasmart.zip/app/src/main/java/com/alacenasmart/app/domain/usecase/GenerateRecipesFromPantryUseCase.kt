package com.alacenasmart.app.domain.usecase

import com.alacenasmart.app.data.remote.GeminiRecipeService
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.Recipe
import java.util.UUID

class GenerateRecipesFromPantryUseCase {

    private val localCatalog = listOf(
        Recipe(
            id = "receta_tortilla_jugosa",
            title = "Tortilla Española Jugosa al Punto",
            description = "Clásica tortilla de patatas tiernas y cebolla caramelizada, cocinada a fuego suave con interior cremoso.",
            category = "Almuerzo / Cena",
            difficulty = "Fácil",
            prepTimeMinutes = 25,
            servings = 4,
            restTimeMinutes = 5,
            cookingTemp = "Fuego medio-bajo (140 °C)",
            requiredIngredients = listOf(
                "4 unidades de huevos camperos",
                "350 g de patatas peladas y en rodajas finas",
                "1 cebolla dulce picada en juliana (120 g)",
                "4 cucharadas (60 ml) de aceite de oliva virgen extra",
                "1 cucharadita (5 g) de sal marina"
            ),
            steps = listOf(
                "Pelar las patatas y cortarlas en láminas de 3 mm de grosor. Cortar la cebolla en juliana fina.",
                "En una sartén antiadherente con el aceite a fuego medio (140 °C), pochar lentamente patatas y cebolla durante 15 minutos hasta que estén muy tiernas pero no doradas en exceso.",
                "En un bol grande batir los 4 huevos con la sal hasta que espumen ligeramente.",
                "Escurrir bien las patatas y cebolla del aceite e incorporarlas de inmediato al huevo caliente. Mezclar y dejar reposar 3 minutos para que absorban el calor.",
                "Calentar la sartén con unas gotas de aceite a fuego medio-alto. Verter la mezcla y remover con espátula los primeros 30 segundos.",
                "Bajar a fuego medio-bajo y cocinar 2 minutos y medio. Dar la vuelta con un plato llano y cuajar el otro lado durante 2 minutos más.",
                "Dejar reposar 5 minutos sobre una fuente antes de cortar para que se asienten los jugos."
            ),
            caloriesKcal = 285,
            proteinGrams = 11.2f,
            carbsGrams = 22.4f,
            fatGrams = 16.5f,
            sugarGrams = 2.1f,
            saltGrams = 1.2f
        ),
        Recipe(
            id = "receta_pechuga_salteada",
            title = "Salteado Aromático de Pollo y Hortalizas",
            description = "Dados de pechuga dorados con verduras tiernas y crujientes, todo medido al gramo para una comida equilibrada.",
            category = "Cena Ligera",
            difficulty = "Fácil",
            prepTimeMinutes = 18,
            servings = 2,
            restTimeMinutes = 3,
            cookingTemp = "Fuego vivo (180 °C en sartén / wok)",
            requiredIngredients = listOf(
                "300 g de pechuga de pollo cortada en dados de 2 cm",
                "150 g de tomates maduros cortados en dados",
                "100 g de espinacas frescas lavadas",
                "2 cucharadas (30 ml) de aceite de oliva virgen extra",
                "1 pizca (3 g) de sal y pimienta negra molida"
            ),
            steps = listOf(
                "Secar los dados de pechuga con papel de cocina y sazonar con sal y pimienta.",
                "Calentar una sartén amplia a fuego alto (180 °C) con una cucharada de aceite.",
                "Añadir el pollo y sellar durante 4 minutos sin mover en exceso para lograr un dorado exterior.",
                "Añadir los tomates en cubos y saltear a fuego medio-alto durante 3 minutos hasta que liberen su jugo.",
                "Incorporar las hojas de espinaca y retirar la sartén del fuego; el calor residual cocinará las espinacas en 1 minuto manteniéndolas vivas.",
                "Dejar reposar 3 minutos tapado antes de emplatar para conservar toda la jugosidad."
            ),
            caloriesKcal = 290,
            proteinGrams = 35.8f,
            carbsGrams = 5.2f,
            fatGrams = 14.1f,
            sugarGrams = 3.2f,
            saltGrams = 1.3f
        ),
        Recipe(
            id = "receta_pasta_mediterranea",
            title = "Espaguetis Mediterráneos al Punto con Atún",
            description = "Pasta al dente con sofrito suave de tomate y atún en conserva, rematado con toque de queso.",
            category = "Almuerzo",
            difficulty = "Fácil",
            prepTimeMinutes = 20,
            servings = 2,
            restTimeMinutes = 2,
            cookingTemp = "100 °C ebullición / Fuego medio (130 °C sartén)",
            requiredIngredients = listOf(
                "180 g de pasta (espaguetis o macarrones)",
                "2 litros de agua para la cocción con 15 g de sal",
                "150 g de atún claro escurrido",
                "200 g de tomates troceados",
                "30 g de queso rallado o en láminas",
                "2 cucharadas (30 ml) de aceite de oliva"
            ),
            steps = listOf(
                "Poner a hervir 2 litros de agua a 100 °C. Al romper el hervor, añadir 15 g de sal y la pasta.",
                "Cocer exactamente durante 9 minutos para dejarla 'al dente'. Guardar 50 ml del agua de cocción antes de escurrir.",
                "En una sartén con aceite a fuego medio, cocinar los tomates durante 6 minutos hasta que espesen.",
                "Desmigar el atún en la sartén y saltear solo 1 minuto para que no se seque.",
                "Añadir la pasta escurrida y los 50 ml de agua reservada. Mantener a fuego fuerte 1 minuto removiendo continuamente.",
                "Retirar, espolvorear el queso y dejar reposar 2 minutos para que emulsione la salsa."
            ),
            caloriesKcal = 490,
            proteinGrams = 31.4f,
            carbsGrams = 68.0f,
            fatGrams = 11.2f,
            sugarGrams = 4.8f,
            saltGrams = 1.5f
        ),
        Recipe(
            id = "receta_arroz_salteado",
            title = "Arroz Salteado con Huevos Revueltos y Pollo",
            description = "Arroz suelto y tostado con pollo jugoso y finos hilos de huevo revuelto cremoso.",
            category = "Almuerzo",
            difficulty = "Media",
            prepTimeMinutes = 22,
            servings = 3,
            restTimeMinutes = 4,
            cookingTemp = "Fuego alto (190 °C)",
            requiredIngredients = listOf(
                "250 g de arroz cocido grano redondo o largo",
                "200 g de dados de pechuga de pollo",
                "2 unidades de huevos camperos batidos",
                "80 g de guisantes tiernos",
                "3 cucharadas (45 ml) de aceite de oliva virgen extra",
                "1 cucharadita (5 g) de sal"
            ),
            steps = listOf(
                "En una sartén grande calentar 1 cucharada de aceite a fuego vivo y saltear el pollo durante 4 minutos.",
                "Añadir los guisantes y saltear 2 minutos más. Apartar a los bordes de la sartén.",
                "En el hueco central, verter los 2 huevos batidos y cuajar rápidamente removiendo con espátula.",
                "Añadir el resto del aceite y el arroz cocido bien desgranado.",
                "Saltear todo el conjunto a fuego alto durante 4 minutos sin parar de remover para que el arroz tome notas tostadas.",
                "Apagar el fuego, rectificar de sal y dejar reposar 4 minutos tapado antes de servir."
            ),
            caloriesKcal = 415,
            proteinGrams = 24.5f,
            carbsGrams = 52.0f,
            fatGrams = 12.8f,
            sugarGrams = 1.8f,
            saltGrams = 1.4f
        ),
        Recipe(
            id = "receta_crema_suave_verduras",
            title = "Crema Aterciopelada de Hortalizas y Queso",
            description = "Crema templada reconfortante con textura suave obtenida al emulsionar verduras cocidas con queso.",
            category = "Cena Ligera",
            difficulty = "Fácil",
            prepTimeMinutes = 30,
            servings = 4,
            restTimeMinutes = 5,
            cookingTemp = "100 °C ebullición suave",
            requiredIngredients = listOf(
                "300 g de patatas peladas y troceadas",
                "200 g de espinacas tiernas lavadas",
                "1 cebolla mediana (100 g) picada",
                "600 ml de agua o caldo suave",
                "50 g de queso cremoso o curado",
                "2 cucharadas (30 ml) de aceite virgen extra",
                "1 cucharadita (5 g) de sal"
            ),
            steps = listOf(
                "Rehogar la cebolla picada con 2 cucharadas de aceite en una cacerola durante 5 minutos a fuego medio.",
                "Añadir las patatas troceadas y cubrir con los 600 ml de agua caliente con sal.",
                "Cocer a ebullición suave (100 °C) durante 15 minutos hasta que la patata esté blanda.",
                "Añadir las espinacas frescas y apagar el fuego. Tapar durante 3 minutos con el calor residual.",
                "Incorporar los 50 g de queso y triturar con batidora de brazo durante 2 minutos hasta lograr textura de terciopelo.",
                "Dejar reposar 5 minutos antes de servir en cuencos hondos con unas gotas de aceite virgen crudo."
            ),
            caloriesKcal = 210,
            proteinGrams = 7.5f,
            carbsGrams = 24.8f,
            fatGrams = 9.6f,
            sugarGrams = 3.5f,
            saltGrams = 1.1f
        ),
        Recipe(
            id = "receta_revuelto_cremoso",
            title = "Revuelto Suave de Huevos con Espinacas y Queso",
            description = "Textura cremosa de huevos revueltos a temperatura baja con espinacas y queso fundido.",
            category = "Desayuno / Cena",
            difficulty = "Fácil",
            prepTimeMinutes = 10,
            servings = 2,
            restTimeMinutes = 1,
            cookingTemp = "Fuego muy bajo (90-100 °C)",
            requiredIngredients = listOf(
                "4 unidades de huevos camperos",
                "120 g de hojas de espinaca fresca",
                "40 g de queso desmenuzado",
                "1 cucharada (15 ml) de aceite de oliva o mantequilla",
                "1 pizca (2 g) de sal y pimienta recién molida"
            ),
            steps = listOf(
                "Saltear las espinacas 1 minuto en sartén hasta que bajen su volumen. Reservar en un plato.",
                "Batir los huevos con la sal en un bol justo hasta integrar claras y yemas.",
                "En la sartén a fuego mínimo (90 °C) con el aceite, verter los huevos.",
                "Remover continuamente con espátula de silicona en círculos lentos durante 4 minutos.",
                "Cuando esté cremoso y casi cuajado, apartar del fuego e incorporar las espinacas y el queso.",
                "Dejar que el queso se funda durante 1 minuto fuera del calor y servir de inmediato."
            ),
            caloriesKcal = 265,
            proteinGrams = 17.2f,
            carbsGrams = 2.4f,
            fatGrams = 20.8f,
            sugarGrams = 1.1f,
            saltGrams = 1.0f
        )
    )

    suspend fun generate5Recipes(
        pantryItems: List<PantryItem>,
        dietaryPreference: com.alacenasmart.app.domain.model.DietaryPreference = com.alacenasmart.app.domain.model.DietaryPreference.ALL
    ): List<Recipe> {
        if (pantryItems.isEmpty()) return emptyList()

        // 1. Try AI Generation with Gemini
        try {
            val aiResult = GeminiRecipeService.generate5RecipesFromPantry(pantryItems, dietaryPreference)
            if (aiResult.isSuccess) {
                val recipes = aiResult.getOrNull()
                if (!recipes.isNullOrEmpty()) {
                    return recipes
                }
            }
        } catch (_: Exception) {
            // Fallback to local cookable recipes below
        }

        // 2. Fallback: match pantry items strictly. User requested: "Las recetas que solo muestren las que se pueden hacer"
        val availableNames = pantryItems.map { it.name.lowercase().trim() }

        val matching = localCatalog.map { recipe ->
            val available = mutableListOf<String>()
            val missing = mutableListOf<String>()

            for (ingredient in recipe.requiredIngredients) {
                val isPresent = availableNames.any { name ->
                    ingredientMatches(ingredient, name)
                } || isBasicPantryItem(ingredient)

                if (isPresent) {
                    available.add(ingredient)
                } else {
                    missing.add(ingredient)
                }
            }

            recipe.copy(
                availableIngredients = available,
                missingIngredients = missing
            )
        }

        // STRICT FILTER: Only recipes where missingIngredients is empty!
        val strictlyCookable = matching.filter { it.missingIngredients.isEmpty() }

        if (strictlyCookable.isNotEmpty()) {
            return strictlyCookable.take(5)
        }

        // If local catalog didn't have exact match, generate dynamic cookable recipe tailored to existing items
        return generateDynamicRecipesForItems(pantryItems).take(5)
    }

    private fun isBasicPantryItem(ingredient: String): Boolean {
        val lower = ingredient.lowercase()
        return lower.contains("agua") || lower.contains("sal") || lower.contains("pimienta") || lower.contains("aceite")
    }

    private fun ingredientMatches(ingredientString: String, pantryItemName: String): Boolean {
        val ing = ingredientString.lowercase()
        val item = pantryItemName.lowercase()

        if (ing.contains(item) || item.contains(ing)) return true

        val synonyms = mapOf(
            "huevo" to listOf("huevo", "huevos", "docena"),
            "pollo" to listOf("pollo", "pechuga", "carne"),
            "patata" to listOf("patata", "patatas", "papa", "papas"),
            "leche" to listOf("leche", "entera", "desnatada"),
            "yogur" to listOf("yogur", "yogurt", "griego"),
            "pasta" to listOf("pasta", "espagueti", "macarron", "tallarin", "fideo"),
            "arroz" to listOf("arroz"),
            "tomate" to listOf("tomate", "tomates"),
            "espinaca" to listOf("espinaca", "espinacas"),
            "queso" to listOf("queso"),
            "atún" to listOf("atun", "atún", "bonito"),
            "guisante" to listOf("guisante", "guisantes")
        )

        for ((key, syns) in synonyms) {
            if (syns.any { ing.contains(it) } && syns.any { item.contains(it) }) {
                return true
            }
        }
        return false
    }

    private fun generateDynamicRecipesForItems(items: List<PantryItem>): List<Recipe> {
        val recipes = mutableListOf<Recipe>()
        val itemNames = items.take(4).map { it.name }
        val mainName = itemNames.firstOrNull() ?: "Alimento"

        recipes.add(
            Recipe(
                id = "dynamic_${UUID.randomUUID()}",
                title = "Salteado Rápido de $mainName con Especias",
                description = "Preparación directa para aprovechar al máximo el sabor y nutrientes de $mainName con cocción controlada.",
                category = "Almuerzo / Cena",
                difficulty = "Fácil",
                prepTimeMinutes = 15,
                servings = 2,
                restTimeMinutes = 3,
                cookingTemp = "Fuego medio (130 °C)",
                requiredIngredients = items.map { "${it.quantity} ${it.unit} de ${it.name}" } + listOf("2 cucharadas (30 ml) de aceite de oliva", "1 pizca (3 g) de sal"),
                availableIngredients = items.map { it.name },
                missingIngredients = emptyList(),
                steps = listOf(
                    "Lavar y trocear ${items.joinToString(", ") { it.name }} en porciones de bocado.",
                    "Poner a calentar una sartén a fuego medio (130 °C) con el aceite de oliva.",
                    "Añadir los ingredientes empezando por los de mayor consistencia y saltear 8 minutos.",
                    "Sazonar con la sal y especias al gusto, removiendo para amalgamar aromas.",
                    "Retirar de la sartén y dejar reposar 3 minutos tapado antes de degustar."
                ),
                caloriesKcal = 310,
                proteinGrams = 18.0f,
                carbsGrams = 22.0f,
                fatGrams = 12.5f,
                sugarGrams = 3.0f,
                saltGrams = 1.0f
            )
        )
        return recipes
    }
}
