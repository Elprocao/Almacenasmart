package com.alacenasmart.app.ui.pantry

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.alacenasmart.app.ui.components.SmartProductAddDialog
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alacenasmart.app.R
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.ui.components.AdBannerView
import com.alacenasmart.app.ui.components.NativeAdCard
import com.alacenasmart.app.ui.components.PantryCard
import com.alacenasmart.app.ui.theme.ExpiryRed
import com.alacenasmart.app.ui.theme.ExpiryYellow
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantryScreen(
    viewModel: PantryViewModel,
    onNavigateToScanner: () -> Unit,
    onNavigateToRecipes: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.userMessage) {
        uiState.userMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearUserMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("pantry_screen_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header: Statistics & Quick Actions
            item {
                PantryHeaderSummary(
                    total = uiState.totalCount,
                    expiringSoon = uiState.expiringSoonCount,
                    expired = uiState.expiredCount,
                    onQuickScan = onNavigateToScanner,
                    onAddNew = { viewModel.openAddDialog() },
                    onExpiringClick = onNavigateToRecipes
                )
            }

            // Search and Filter Row
            item {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pantry_search_input"),
                    placeholder = { Text("Buscar alimento o categoría...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Limpiar búsqueda")
                            }
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
            }

            // Location Filters
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = uiState.selectedLocation == null,
                        onClick = { viewModel.setLocationFilter(null) },
                        label = { Text("Todos") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )

                    StorageLocation.entries.forEach { loc ->
                        FilterChip(
                            selected = uiState.selectedLocation == loc,
                            onClick = { viewModel.setLocationFilter(loc) },
                            label = { Text(loc.displayName) },
                            leadingIcon = {
                                Icon(
                                    imageVector = loc.icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
            }

            // Pantry Items List
            if (uiState.items.isEmpty() && !uiState.isLoading) {
                item {
                    EmptyPantryView(onAddClick = { viewModel.openAddDialog() })
                }
            } else {
                items(uiState.items, key = { it.id }) { item ->
                    PantryCard(
                        item = item,
                        onConsume = { viewModel.consumeItem(item, addToShopping = true) },
                        onDiscard = { viewModel.promptDiscard(item) },
                        onAddToShopping = { viewModel.addToShoppingList(item) },
                        onEdit = { viewModel.openEditDialog(item) }
                    )
                }

                // Native Ad at bottom of the list
                item {
                    NativeAdCard(
                        isProUser = uiState.isProUser,
                        onUpgradeClick = { /* Could open pro dialog */ }
                    )
                }
            }
        }

        // Add/Edit Dialogs
        if (uiState.isAddEditDialogOpen) {
            if (uiState.editingItem == null) {
                // New product addition with AI and Google Lens match flow
                SmartProductAddDialog(
                    title = "Añadir a la Despensa",
                    onDismiss = { viewModel.closeAddEditDialog() },
                    onProductSelected = { option, quantity ->
                        val expiryEpoch = java.time.LocalDate.now().plusDays(option.shelfLifeDays.toLong()).toEpochDay()
                        viewModel.savePantryItem(
                            id = 0L,
                            name = option.title,
                            barcode = null,
                            category = option.brandOrCategory,
                            storageLocation = option.storageLocation,
                            expiryDateEpochDay = expiryEpoch,
                            quantity = quantity,
                            unit = "unidades",
                            imageUrl = option.imageUrl
                        )
                        viewModel.closeAddEditDialog()
                    }
                )
            } else {
                AddEditPantryBottomSheet(
                    item = uiState.editingItem,
                    onDismiss = { viewModel.closeAddEditDialog() },
                    onSave = { name, barcode, category, location, expiryEpoch, qty, unit ->
                        viewModel.savePantryItem(
                            id = uiState.editingItem?.id ?: 0L,
                            name = name,
                            barcode = barcode,
                            category = category,
                            storageLocation = location,
                            expiryDateEpochDay = expiryEpoch,
                            quantity = qty,
                            unit = unit,
                            imageUrl = uiState.editingItem?.imageUrl
                        )
                    }
                )
            }
        }

        // Discard Confirmation Dialog
        uiState.itemToDiscard?.let { item ->
            AlertDialog(
                onDismissRequest = { viewModel.dismissDiscardPrompt() },
                title = { Text("¿Desechar alimento?") },
                text = { Text("¿Estás seguro de que deseas eliminar \"${item.name}\" de tu despensa? Esta acción no se puede deshacer.") },
                confirmButton = {
                    Button(
                        onClick = { viewModel.confirmDiscard() },
                        modifier = Modifier.testTag("confirm_discard_btn")
                    ) {
                        Text("Desechar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissDiscardPrompt() }) {
                        Text("Cancelar")
                    }
                }
            )
        }
    }
}

@Composable
fun PantryHeaderSummary(
    total: Int,
    expiringSoon: Int,
    expired: Int,
    onQuickScan: () -> Unit,
    onAddNew: () -> Unit,
    onExpiringClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("pantry_header_summary"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Mi Despensa",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "$total alimentos registrados",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onQuickScan,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .testTag("btn_quick_scan_header")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Escanear",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }

                    IconButton(
                        onClick = onAddNew,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondary)
                            .testTag("btn_add_header")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Añadir alimento",
                            tint = MaterialTheme.colorScheme.onSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Urgency Alert Banner
            if (expiringSoon > 0 || expired > 0) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (expired > 0) ExpiryRed.copy(alpha = 0.15f)
                            else ExpiryYellow.copy(alpha = 0.15f)
                        )
                        .clickable(onClick = onExpiringClick)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (expired > 0) ExpiryRed else ExpiryYellow,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        val text = when {
                            expired > 0 && expiringSoon > 0 -> "$expired caducados • $expiringSoon por caducar"
                            expired > 0 -> "$expired alimentos caducados"
                            else -> "$expiringSoon alimentos por caducar en 48h"
                        }
                        Text(
                            text = text,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Toca para ver recetas y aprovecharlos",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyPantryView(
    onAddClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp)
            .testTag("empty_pantry_view"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_empty_pantry),
                contentDescription = "Despensa vacía",
                modifier = Modifier
                    .fillMaxWidth(0.68f)
                    .aspectRatio(4f / 3f)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Tu despensa está vacía",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Añade tu primer alimento o escanea un código de barras para empezar a controlar tus caducidades.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = onAddClick,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("empty_add_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Añadir alimento")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditPantryBottomSheet(
    item: PantryItem?,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        barcode: String?,
        category: String,
        storageLocation: StorageLocation,
        expiryDateEpochDay: Long,
        quantity: Int,
        unit: String
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var name by remember { mutableStateOf(item?.name ?: "") }
    var barcode by remember { mutableStateOf(item?.barcode ?: "") }
    var selectedCategory by remember { mutableStateOf(item?.category ?: "Despensa") }
    var selectedLocation by remember { mutableStateOf(item?.storageLocation ?: StorageLocation.DESPENSA) }
    var quantity by remember { mutableIntStateOf(item?.quantity ?: 1) }
    var unit by remember { mutableStateOf(item?.unit ?: "unidades") }

    val today = remember { LocalDate.now() }
    var expiryEpochDay by remember {
        mutableLongStateOf(item?.expiryDateEpochDay ?: (today.toEpochDay() + 7))
    }
    var showDatePicker by remember { mutableStateOf(false) }

    val categories = listOf("Lácteos", "Carnes", "Frutas y verduras", "Congelados", "Despensa", "Bebidas", "Varios")
    val units = listOf("unidades", "kg", "g", "l", "ml", "paquete", "bandeja", "bolsa")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp)
                .testTag("add_edit_pantry_dialog")
        ) {
            Text(
                text = if (item == null) "Añadir alimento" else "Editar alimento",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Name
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nombre del alimento *") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_item_name"),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Storage Location
            Text(
                text = "Ubicación",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StorageLocation.entries.forEach { loc ->
                    val isSelected = selectedLocation == loc
                    OutlinedButton(
                        onClick = { selectedLocation = loc },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = if (isSelected) androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ) else androidx.compose.material3.ButtonDefaults.outlinedButtonColors()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = loc.icon,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(loc.displayName, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Category Selection
            Text(
                text = "Categoría",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Expiry Date Selection
            Text(
                text = "Fecha de caducidad",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(4.dp))

            val currentExpiryDate = LocalDate.ofEpochDay(expiryEpochDay)
            val formattedExpiry = currentExpiryDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Seleccionada: $formattedExpiry",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                TextButton(onClick = { showDatePicker = true }) {
                    Text("Cambiar fecha")
                }
            }

            // Quick date adjustment chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val chips = listOf(
                    Pair("+3 días", 3L),
                    Pair("+7 días", 7L),
                    Pair("+1 mes", 30L),
                    Pair("+6 meses", 180L)
                )
                chips.forEach { (label, days) ->
                    OutlinedButton(
                        onClick = { expiryEpochDay = today.toEpochDay() + days },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(label, fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quantity and Unit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quantity Counter
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(4.dp)
                ) {
                    IconButton(
                        onClick = { if (quantity > 1) quantity-- },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("−", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = "$quantity",
                        modifier = Modifier.padding(horizontal = 12.dp),
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(
                        onClick = { quantity++ },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Unit Selector
                OutlinedTextField(
                    value = unit,
                    onValueChange = { unit = it },
                    label = { Text("Unidad") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Buttons
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            name,
                            barcode.ifBlank { null },
                            selectedCategory,
                            selectedLocation,
                            expiryEpochDay,
                            quantity,
                            unit
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_save_pantry_item"),
                enabled = name.isNotBlank(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(if (item == null) "Guardar Alimento" else "Actualizar Alimento")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = LocalDate.ofEpochDay(expiryEpochDay)
                .atStartOfDay(ZoneId.of("UTC"))
                .toInstant()
                .toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        val selectedDate = Instant.ofEpochMilli(millis)
                            .atZone(ZoneId.of("UTC"))
                            .toLocalDate()
                        expiryEpochDay = selectedDate.toEpochDay()
                    }
                    showDatePicker = false
                }) {
                    Text("Aceptar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancelar")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}
