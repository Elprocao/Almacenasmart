package com.alacenasmart.app.ui.recipes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alacenasmart.app.domain.model.DietaryPreference
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.Recipe
import com.alacenasmart.app.domain.repository.PantryRepository
import com.alacenasmart.app.domain.usecase.GenerateRecipesFromPantryUseCase
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class RecipeTab {
    DISCOVER_AI,
    RECIPE_BOOK
}

data class ActiveTimerState(
    val title: String,
    val totalSeconds: Int,
    val remainingSeconds: Int,
    val isRunning: Boolean = true,
    val isFinished: Boolean = false
)

data class RecipesUiState(
    val currentTab: RecipeTab = RecipeTab.DISCOVER_AI,
    val generatedRecipes: List<Recipe> = emptyList(),
    val savedRecipes: List<Recipe> = emptyList(),
    val bookFilterFavoritesOnly: Boolean = false,
    val selectedRecipe: Recipe? = null,
    val scaledServings: Int = 2,
    val isLoading: Boolean = false,
    val isAiGenerating: Boolean = false,
    val isPreferencesSheetOpen: Boolean = false,
    val selectedDietaryPreference: DietaryPreference = DietaryPreference.ALL,
    val expiringItemsCount: Int = 0,
    val pantryItemsCount: Int = 0,
    val activeTimer: ActiveTimerState? = null,
    val snackbarMessage: String? = null
)

class RecipesViewModel(
    private val repository: PantryRepository,
    private val generateRecipesUseCase: GenerateRecipesFromPantryUseCase = GenerateRecipesFromPantryUseCase()
) : ViewModel() {

    private val _uiState = MutableStateFlow(RecipesUiState())
    val uiState: StateFlow<RecipesUiState> = _uiState.asStateFlow()

    private var currentPantryItems: List<PantryItem> = emptyList()
    private var timerJob: Job? = null

    init {
        // Collect Saved Recipes from Repository
        viewModelScope.launch {
            repository.getSavedRecipes().collect { savedList ->
                _uiState.update { current ->
                    // Update isSaved / isFavorite flags on generated recipes if they match
                    val updatedGenerated = current.generatedRecipes.map { gen ->
                        val savedMatch = savedList.firstOrNull { it.id == gen.id }
                        if (savedMatch != null) {
                            gen.copy(isSaved = true, isFavorite = savedMatch.isFavorite)
                        } else {
                            gen.copy(isSaved = false, isFavorite = false)
                        }
                    }
                    val updatedSelected = current.selectedRecipe?.let { sel ->
                        val savedMatch = savedList.firstOrNull { it.id == sel.id }
                        if (savedMatch != null) sel.copy(isSaved = true, isFavorite = savedMatch.isFavorite)
                        else sel.copy(isSaved = false, isFavorite = false)
                    }

                    current.copy(
                        savedRecipes = savedList,
                        generatedRecipes = updatedGenerated,
                        selectedRecipe = updatedSelected
                    )
                }
            }
        }

        // Collect Pantry Items. NO AUTO GENERATION! User explicitly requested:
        // "Que las recetas no se generen automaticamente, que haya un botón y que se abra un menú de selección"
        viewModelScope.launch {
            repository.getPantryItems().collect { items ->
                currentPantryItems = items
                val expiringCount = items.count { it.expiryStatus.daysRemaining in 0..2 }
                _uiState.update {
                    it.copy(
                        pantryItemsCount = items.size,
                        expiringItemsCount = expiringCount
                    )
                }
            }
        }
    }

    fun setTab(tab: RecipeTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun toggleFavoritesOnlyFilter() {
        _uiState.update { it.copy(bookFilterFavoritesOnly = !it.bookFilterFavoritesOnly) }
    }

    fun openPreferencesMenu() {
        _uiState.update { it.copy(isPreferencesSheetOpen = true) }
    }

    fun closePreferencesMenu() {
        _uiState.update { it.copy(isPreferencesSheetOpen = false) }
    }

    fun setDietaryPreference(pref: DietaryPreference) {
        _uiState.update { it.copy(selectedDietaryPreference = pref) }
    }

    fun generateRecipesWithPreference(pref: DietaryPreference) {
        _uiState.update {
            it.copy(
                selectedDietaryPreference = pref,
                isPreferencesSheetOpen = false,
                isAiGenerating = true,
                isLoading = true
            )
        }
        viewModelScope.launch {
            try {
                val recipes = generateRecipesUseCase.generate5Recipes(currentPantryItems, pref)
                val savedIds = _uiState.value.savedRecipes.associate { it.id to it.isFavorite }
                val updated = recipes.map { r ->
                    if (savedIds.containsKey(r.id)) {
                        r.copy(isSaved = true, isFavorite = savedIds[r.id] == true)
                    } else r
                }
                _uiState.update {
                    it.copy(
                        generatedRecipes = updated,
                        isAiGenerating = false,
                        isLoading = false,
                        snackbarMessage = "¡Se han generado 5 recetas con ${pref.label}!"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isAiGenerating = false,
                        isLoading = false,
                        snackbarMessage = "No se pudieron generar recetas: ${e.message}"
                    )
                }
            }
        }
    }

    fun selectRecipe(recipe: Recipe?) {
        _uiState.update {
            it.copy(
                selectedRecipe = recipe,
                scaledServings = recipe?.servings ?: 2
            )
        }
    }

    fun setScaledServings(servings: Int) {
        val safe = servings.coerceIn(1, 12)
        _uiState.update { it.copy(scaledServings = safe) }
    }

    // Timer controls for recipe steps
    fun startStepTimer(minutes: Int, stepLabel: String) {
        val totalSec = minutes * 60
        timerJob?.cancel()
        _uiState.update {
            it.copy(
                activeTimer = ActiveTimerState(
                    title = stepLabel,
                    totalSeconds = totalSec,
                    remainingSeconds = totalSec,
                    isRunning = true,
                    isFinished = false
                ),
                snackbarMessage = "Temporizador iniciado: $minutes minutos"
            )
        }
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val current = _uiState.value.activeTimer ?: break
                if (current.remainingSeconds > 1) {
                    _uiState.update {
                        it.copy(activeTimer = current.copy(remainingSeconds = current.remainingSeconds - 1))
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            activeTimer = current.copy(
                                remainingSeconds = 0,
                                isRunning = false,
                                isFinished = true
                            ),
                            snackbarMessage = "🔔 ¡Tiempo finalizado para: ${current.title}!"
                        )
                    }
                    break
                }
            }
        }
    }

    fun stopTimer() {
        timerJob?.cancel()
        _uiState.update { it.copy(activeTimer = null) }
    }

    fun toggleSaveRecipe(recipe: Recipe) {
        viewModelScope.launch {
            val isCurrentlySaved = _uiState.value.savedRecipes.any { it.id == recipe.id }
            if (isCurrentlySaved) {
                repository.removeSavedRecipe(recipe.id)
                _uiState.update { it.copy(snackbarMessage = "Receta eliminada de tu Libro de Recetas") }
            } else {
                repository.saveRecipe(recipe.copy(isSaved = true))
                _uiState.update { it.copy(snackbarMessage = "¡Receta guardada en tu Libro de Recetas!") }
            }
        }
    }

    fun toggleFavoriteRecipe(recipe: Recipe) {
        viewModelScope.launch {
            val isFav = recipe.isFavorite
            if (!recipe.isSaved) {
                // If not yet saved, save it directly as favorite
                repository.saveRecipe(recipe.copy(isSaved = true, isFavorite = true))
                _uiState.update { it.copy(snackbarMessage = "Guardada en favoritos") }
            } else {
                repository.toggleFavoriteRecipe(recipe.id, !isFav)
                _uiState.update {
                    it.copy(
                        snackbarMessage = if (!isFav) "Añadida a tus recetas favoritas ⭐" else "Quitada de favoritos"
                    )
                }
            }
        }
    }

    fun cookRecipe(recipe: Recipe) {
        viewModelScope.launch {
            var consumedCount = 0
            for (ingName in recipe.availableIngredients) {
                val matchingItem = currentPantryItems.firstOrNull {
                    it.name.contains(ingName, ignoreCase = true) || it.category.contains(ingName, ignoreCase = true)
                }
                if (matchingItem != null) {
                    repository.setItemConsumed(matchingItem.id, true)
                    consumedCount++
                }
            }
            _uiState.update {
                it.copy(
                    selectedRecipe = null,
                    snackbarMessage = "¡Buen provecho! Se marcaron como consumidos $consumedCount ingredientes de tu despensa."
                )
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
