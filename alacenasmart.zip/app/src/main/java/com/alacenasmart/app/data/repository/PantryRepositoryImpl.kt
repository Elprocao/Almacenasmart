package com.alacenasmart.app.data.repository

import com.alacenasmart.app.data.local.dao.BarcodeDictionaryDao
import com.alacenasmart.app.data.local.dao.PantryDao
import com.alacenasmart.app.data.local.dao.SavedRecipeDao
import com.alacenasmart.app.data.local.dao.ShoppingDao
import com.alacenasmart.app.data.local.entity.PantryItemEntity
import com.alacenasmart.app.data.local.entity.ProductBarcodeEntity
import com.alacenasmart.app.data.local.entity.SavedRecipeEntity
import com.alacenasmart.app.data.local.entity.ShoppingItemEntity
import com.alacenasmart.app.domain.model.ExpiryStatus
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.Recipe
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.domain.repository.PantryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import java.time.LocalDate

class PantryRepositoryImpl(
    private val pantryDao: PantryDao,
    private val shoppingDao: ShoppingDao,
    private val barcodeDao: BarcodeDictionaryDao,
    private val savedRecipeDao: SavedRecipeDao? = null
) : PantryRepository {

    private fun entityToDomain(entity: PantryItemEntity, currentEpochDay: Long): PantryItem {
        val expiryStatus = ExpiryStatus.calculate(entity.expiryDateEpochDay, currentEpochDay)
        return PantryItem(
            id = entity.id,
            name = entity.name,
            barcode = entity.barcode,
            category = entity.category,
            storageLocation = StorageLocation.fromString(entity.storageLocation),
            expiryDateEpochDay = entity.expiryDateEpochDay,
            quantity = entity.quantity,
            unit = entity.unit,
            isConsumed = entity.isConsumed,
            addedTimestamp = entity.addedTimestamp,
            expiryStatus = expiryStatus,
            imageUrl = entity.imageUrl,
            caloriesKcal = entity.caloriesKcal,
            proteinGrams = entity.proteinGrams,
            carbsGrams = entity.carbsGrams,
            fatGrams = entity.fatGrams,
            sugarGrams = entity.sugarGrams,
            saltGrams = entity.saltGrams
        )
    }

    private fun domainToEntity(domain: PantryItem): PantryItemEntity {
        return PantryItemEntity(
            id = domain.id,
            name = domain.name,
            barcode = domain.barcode,
            category = domain.category,
            storageLocation = domain.storageLocation.displayName,
            expiryDateEpochDay = domain.expiryDateEpochDay,
            quantity = domain.quantity,
            unit = domain.unit,
            isConsumed = domain.isConsumed,
            addedTimestamp = domain.addedTimestamp,
            imageUrl = domain.imageUrl,
            caloriesKcal = domain.caloriesKcal,
            proteinGrams = domain.proteinGrams,
            carbsGrams = domain.carbsGrams,
            fatGrams = domain.fatGrams,
            sugarGrams = domain.sugarGrams,
            saltGrams = domain.saltGrams
        )
    }

    override fun getPantryItems(): Flow<List<PantryItem>> {
        return pantryDao.getAllActiveItems().map { list ->
            val today = LocalDate.now().toEpochDay()
            list.map { entityToDomain(it, today) }
                .sortedWith(compareBy({ it.expiryStatus.daysRemaining }, { it.name }))
        }
    }

    override fun getExpiringItems(thresholdDays: Long): Flow<List<PantryItem>> {
        val today = LocalDate.now().toEpochDay()
        val maxEpoch = today + thresholdDays
        return pantryDao.getExpiringItems(maxEpoch).map { list ->
            list.map { entityToDomain(it, today) }
                .sortedBy { it.expiryStatus.daysRemaining }
        }
    }

    override suspend fun getItemById(id: Long): PantryItem? {
        val entity = pantryDao.getItemById(id) ?: return null
        return entityToDomain(entity, LocalDate.now().toEpochDay())
    }

    override suspend fun addPantryItem(
        name: String,
        barcode: String?,
        category: String,
        storageLocation: StorageLocation,
        expiryDateEpochDay: Long,
        quantity: Int,
        unit: String,
        imageUrl: String?,
        caloriesKcal: Int?,
        proteinGrams: Float?,
        carbsGrams: Float?,
        fatGrams: Float?,
        sugarGrams: Float?,
        saltGrams: Float?
    ): Long {
        val entity = PantryItemEntity(
            name = name.trim(),
            barcode = barcode?.trim(),
            category = category,
            storageLocation = storageLocation.displayName,
            expiryDateEpochDay = expiryDateEpochDay,
            quantity = quantity.coerceAtLeast(1),
            unit = unit,
            imageUrl = imageUrl?.trim()?.ifBlank { null },
            caloriesKcal = caloriesKcal,
            proteinGrams = proteinGrams,
            carbsGrams = carbsGrams,
            fatGrams = fatGrams,
            sugarGrams = sugarGrams,
            saltGrams = saltGrams
        )
        return pantryDao.insertItem(entity)
    }

    override suspend fun importPantryItems(items: List<PantryItemEntity>): Int {
        if (items.isEmpty()) return 0
        val sanitized = items.map { it.copy(id = 0) }
        val inserted = pantryDao.insertItems(sanitized)
        return inserted.size
    }

    override suspend fun updatePantryItem(item: PantryItem) {
        pantryDao.updateItem(domainToEntity(item))
    }

    override suspend fun deletePantryItem(id: Long) {
        pantryDao.deleteItemById(id)
    }

    override suspend fun setItemConsumed(id: Long, isConsumed: Boolean) {
        pantryDao.setConsumed(id, isConsumed)
    }

    override suspend fun lookupBarcode(barcode: String): ProductBarcodeEntity? {
        return barcodeDao.getByBarcode(barcode.trim())
    }

    override suspend fun saveBarcodeProduct(
        barcode: String,
        name: String,
        category: String,
        shelfLifeDays: Int
    ) {
        barcodeDao.insertOrUpdate(
            ProductBarcodeEntity(
                barcode = barcode.trim(),
                defaultName = name.trim(),
                defaultCategory = category.trim(),
                typicalShelfLifeDays = shelfLifeDays
            )
        )
    }

    override fun getShoppingItems(): Flow<List<ShoppingItemEntity>> {
        return shoppingDao.getAllItems()
    }

    override suspend fun addShoppingItem(
        name: String,
        category: String,
        quantity: Int,
        originPantryItemId: Long?,
        imageUrl: String?
    ): Long {
        val entity = ShoppingItemEntity(
            name = name.trim(),
            category = category.trim(),
            quantity = quantity.coerceAtLeast(1),
            isChecked = false,
            originPantryItemId = originPantryItemId,
            imageUrl = imageUrl?.trim()?.ifBlank { null }
        )
        return shoppingDao.insertItem(entity)
    }

    override suspend fun updateShoppingItem(item: ShoppingItemEntity) {
        shoppingDao.updateItem(item)
    }

    override suspend fun toggleShoppingItem(id: Long, isChecked: Boolean) {
        shoppingDao.setChecked(id, isChecked)
    }

    override suspend fun deleteShoppingItem(id: Long) {
        shoppingDao.deleteItemById(id)
    }

    override suspend fun clearCheckedShoppingItems() {
        shoppingDao.clearChecked()
    }

    override suspend fun clearAllShoppingItems() {
        shoppingDao.clearAll()
    }

    private fun savedEntityToRecipe(entity: SavedRecipeEntity): Recipe {
        val ingredientsList = try {
            val jsonArr = JSONArray(entity.requiredIngredientsJson)
            List(jsonArr.length()) { jsonArr.getString(it) }
        } catch (_: Exception) {
            emptyList()
        }
        val stepsList = try {
            val jsonArr = JSONArray(entity.stepsJson)
            List(jsonArr.length()) { jsonArr.getString(it) }
        } catch (_: Exception) {
            emptyList()
        }

        return Recipe(
            id = entity.id,
            title = entity.title,
            description = entity.description,
            category = entity.category,
            difficulty = entity.difficulty,
            prepTimeMinutes = entity.prepTimeMinutes,
            servings = entity.servings,
            restTimeMinutes = entity.restTimeMinutes,
            cookingTemp = entity.cookingTemp,
            requiredIngredients = ingredientsList,
            steps = stepsList,
            caloriesKcal = entity.caloriesKcal,
            proteinGrams = entity.proteinGrams,
            carbsGrams = entity.carbsGrams,
            fatGrams = entity.fatGrams,
            sugarGrams = entity.sugarGrams,
            saltGrams = entity.saltGrams,
            isSaved = true,
            isFavorite = entity.isFavorite
        )
    }

    private fun recipeToSavedEntity(recipe: Recipe, isFavorite: Boolean = recipe.isFavorite): SavedRecipeEntity {
        val ingredientsJson = JSONArray(recipe.requiredIngredients).toString()
        val stepsJson = JSONArray(recipe.steps).toString()

        return SavedRecipeEntity(
            id = recipe.id,
            title = recipe.title,
            description = recipe.description,
            category = recipe.category,
            difficulty = recipe.difficulty,
            prepTimeMinutes = recipe.prepTimeMinutes,
            servings = recipe.servings,
            restTimeMinutes = recipe.restTimeMinutes,
            cookingTemp = recipe.cookingTemp,
            requiredIngredientsJson = ingredientsJson,
            stepsJson = stepsJson,
            caloriesKcal = recipe.caloriesKcal,
            proteinGrams = recipe.proteinGrams,
            carbsGrams = recipe.carbsGrams,
            fatGrams = recipe.fatGrams,
            sugarGrams = recipe.sugarGrams,
            saltGrams = recipe.saltGrams,
            isFavorite = isFavorite
        )
    }

    override fun getSavedRecipes(): Flow<List<Recipe>> {
        return (savedRecipeDao?.getAllSavedRecipes() ?: kotlinx.coroutines.flow.flowOf(emptyList()))
            .map { list -> list.map { savedEntityToRecipe(it) } }
    }

    override fun getFavoriteRecipes(): Flow<List<Recipe>> {
        return (savedRecipeDao?.getFavoriteRecipes() ?: kotlinx.coroutines.flow.flowOf(emptyList()))
            .map { list -> list.map { savedEntityToRecipe(it) } }
    }

    override suspend fun saveRecipe(recipe: Recipe) {
        savedRecipeDao?.insertRecipe(recipeToSavedEntity(recipe))
    }

    override suspend fun removeSavedRecipe(id: String) {
        savedRecipeDao?.deleteRecipeById(id)
    }

    override suspend fun toggleFavoriteRecipe(id: String, isFavorite: Boolean) {
        savedRecipeDao?.setFavorite(id, isFavorite)
    }

    override fun isRecipeSaved(id: String): Flow<Boolean> {
        return savedRecipeDao?.isRecipeSaved(id) ?: kotlinx.coroutines.flow.flowOf(false)
    }

    override suspend fun clearAllData() {
        pantryDao.clearAll()
        shoppingDao.clearAll()
    }
}
