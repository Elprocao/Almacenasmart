package com.alacenasmart.app.ui.widget

import android.content.Context
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.alacenasmart.app.data.local.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

class PantryGlanceWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val database = AppDatabase.getInstance(context)
        val today = LocalDate.now().toEpochDay()
        val urgentItems = withContext(Dispatchers.IO) {
            database.pantryDao().getExpiringItemsSync(today + 2)
        }

        provideContent {
            GlanceTheme {
                Box(
                    modifier = GlanceModifier
                        .fillMaxSize()
                        .background(androidx.compose.ui.graphics.Color(0xFF1B3B2B))
                        .padding(14.dp)
                ) {
                    Column(
                        modifier = GlanceModifier.fillMaxSize()
                    ) {
                        Row(
                            modifier = GlanceModifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "AlacenaSmart",
                                style = TextStyle(
                                    color = ColorProvider(androidx.compose.ui.graphics.Color(0xFF81C784)),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = GlanceModifier.defaultWeight())
                            Text(
                                text = "Urgentes: ${urgentItems.size}",
                                style = TextStyle(
                                    color = ColorProvider(
                                        if (urgentItems.isNotEmpty()) androidx.compose.ui.graphics.Color(0xFFFF8A80)
                                        else androidx.compose.ui.graphics.Color(0xFFFFFFFF)
                                    ),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Spacer(modifier = GlanceModifier.height(8.dp))

                        if (urgentItems.isEmpty()) {
                            Box(
                                modifier = GlanceModifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Todo al día, sin alimentos urgentes",
                                    style = TextStyle(
                                        color = ColorProvider(androidx.compose.ui.graphics.Color(0xFFE0E0E0)),
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        } else {
                            Column(modifier = GlanceModifier.fillMaxWidth()) {
                                urgentItems.take(3).forEach { item ->
                                    val days = item.expiryDateEpochDay - today
                                    val timeLabel = when {
                                        days < 0 -> "Caducado"
                                        days == 0L -> "Hoy"
                                        days == 1L -> "Mañana"
                                        else -> "$days d"
                                    }

                                    Row(
                                        modifier = GlanceModifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.name,
                                            maxLines = 1,
                                            style = TextStyle(
                                                color = ColorProvider(androidx.compose.ui.graphics.Color.White),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            ),
                                            modifier = GlanceModifier.defaultWeight()
                                        )
                                        Spacer(modifier = GlanceModifier.width(6.dp))
                                        Text(
                                            text = timeLabel,
                                            style = TextStyle(
                                                color = ColorProvider(androidx.compose.ui.graphics.Color(0xFFFFAB91)),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    companion object {
        suspend fun updateWidget(context: Context) {
            try {
                PantryGlanceWidget().updateAll(context)
            } catch (_: Exception) {}
        }
    }
}

class ConsumeWidgetActionCallback : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val itemId = parameters[ActionParameters.Key<Long>("itemId")] ?: return
        withContext(Dispatchers.IO) {
            val db = AppDatabase.getInstance(context)
            db.pantryDao().setConsumed(itemId, true)
        }
        PantryGlanceWidget.updateWidget(context)
    }
}
