package com.alacenasmart.app.data.util

import com.alacenasmart.app.data.local.entity.PantryItemEntity
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.StorageLocation
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object PantryTxtFormatUtil {

    private val dateFormatter: DateTimeFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    /**
     * Exports a list of pantry items into a standardized, human-readable TXT format.
     * All properties including the internet profile image URL and nutrition are preserved.
     */
    fun exportToTxt(items: List<PantryItem>): String {
        val sb = StringBuilder()
        sb.appendLine("# ==========================================")
        sb.appendLine("# ALACENASMART - COPIA DE SEGURIDAD DESPENSA")
        sb.appendLine("# Formato: TXT v1.0")
        sb.appendLine("# Fecha exportación: ${LocalDate.now().format(dateFormatter)}")
        sb.appendLine("# Total de alimentos: ${items.size}")
        sb.appendLine("# ==========================================")
        sb.appendLine()

        for (item in items) {
            sb.appendLine("---")
            sb.appendLine("Nombre: ${item.name}")
            if (!item.barcode.isNullOrBlank()) {
                sb.appendLine("CodigoBarras: ${item.barcode}")
            }
            sb.appendLine("Categoria: ${item.category}")
            sb.appendLine("Ubicacion: ${item.storageLocation.name}")

            if (item.expiryDateEpochDay != null) {
                val expiryLocalDate = LocalDate.ofEpochDay(item.expiryDateEpochDay)
                sb.appendLine("CaducidadFecha: ${expiryLocalDate.format(dateFormatter)}")
                sb.appendLine("CaducidadEpochDay: ${item.expiryDateEpochDay}")
            }

            sb.appendLine("Cantidad: ${item.quantity}")
            sb.appendLine("Unidad: ${item.unit}")

            if (!item.imageUrl.isNullOrBlank()) {
                sb.appendLine("ImagenUrl: ${item.imageUrl}")
            }

            if (item.caloriesKcal != null) sb.appendLine("CaloriasKcal: ${item.caloriesKcal}")
            if (item.proteinGrams != null) sb.appendLine("ProteinasG: ${item.proteinGrams}")
            if (item.carbsGrams != null) sb.appendLine("CarbohidratosG: ${item.carbsGrams}")
            if (item.fatGrams != null) sb.appendLine("GrasasG: ${item.fatGrams}")
            if (item.sugarGrams != null) sb.appendLine("AzucaresG: ${item.sugarGrams}")
            if (item.saltGrams != null) sb.appendLine("SalG: ${item.saltGrams}")

            sb.appendLine("Consumido: ${item.isConsumed}")
            sb.appendLine("---")
            sb.appendLine()
        }

        return sb.toString()
    }

    /**
     * Parses TXT contents into a list of PantryItemEntity ready to be inserted.
     * Tolerates variations in key names (Spanish/English, upper/lower case) and comments.
     */
    fun parseFromTxt(content: String): List<PantryItemEntity> {
        val result = mutableListOf<PantryItemEntity>()
        val blocks = content.split(Regex("(^|\n)---(\n|$)"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val today = LocalDate.now()

        for (block in blocks) {
            val lines = block.lines()
            var name: String? = null
            var barcode: String? = null
            var category: String = "Despensa"
            var storageLocation: String = StorageLocation.DESPENSA.name
            var expiryEpochDay: Long? = null
            var quantity: Int = 1
            var unit: String = "unidades"
            var imageUrl: String? = null
            var caloriesKcal: Int? = null
            var proteinGrams: Float? = null
            var carbsGrams: Float? = null
            var fatGrams: Float? = null
            var sugarGrams: Float? = null
            var saltGrams: Float? = null
            var isConsumed: Boolean = false

            for (rawLine in lines) {
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) continue

                val colonIndex = line.indexOf(':')
                if (colonIndex == -1) continue

                val key = line.substring(0, colonIndex).trim().lowercase()
                val value = line.substring(colonIndex + 1).trim()
                if (value.isEmpty()) continue

                when (key) {
                    "nombre", "producto", "name", "alimento" -> {
                        name = value
                    }
                    "codigobarras", "barcode", "codigo_barras", "ean" -> {
                        barcode = value.ifBlank { null }
                    }
                    "categoria", "category" -> {
                        category = value
                    }
                    "ubicacion", "location", "almacenamiento" -> {
                        val matchedLoc = StorageLocation.entries.firstOrNull {
                            it.name.equals(value, ignoreCase = true) ||
                                    it.displayName.equals(value, ignoreCase = true)
                        }
                        storageLocation = matchedLoc?.name ?: StorageLocation.DESPENSA.name
                    }
                    "caducidadepochday", "expiryepochday" -> {
                        value.toLongOrNull()?.let { expiryEpochDay = it }
                    }
                    "caducidadfecha", "caducidad", "expiry", "fecha_caducidad" -> {
                        if (expiryEpochDay == null) {
                            try {
                                val parsed = LocalDate.parse(value, dateFormatter)
                                expiryEpochDay = parsed.toEpochDay()
                            } catch (_: Exception) {
                                // Ignore format failure and fallback later
                            }
                        }
                    }
                    "cantidad", "quantity", "qty" -> {
                        value.toIntOrNull()?.let { if (it > 0) quantity = it }
                    }
                    "unidad", "unit" -> {
                        unit = value
                    }
                    "imagenurl", "imagen", "image", "imageurl", "foto", "url_imagen" -> {
                        imageUrl = value.ifBlank { null }
                    }
                    "caloriaskcal", "calorias", "calories" -> {
                        value.toIntOrNull()?.let { caloriesKcal = it }
                    }
                    "proteinasg", "proteinas", "protein" -> {
                        value.replace(',', '.').toFloatOrNull()?.let { proteinGrams = it }
                    }
                    "carbohidratosg", "carbohidratos", "carbs" -> {
                        value.replace(',', '.').toFloatOrNull()?.let { carbsGrams = it }
                    }
                    "grasasg", "grasas", "fat" -> {
                        value.replace(',', '.').toFloatOrNull()?.let { fatGrams = it }
                    }
                    "azucaresg", "azucares", "sugar" -> {
                        value.replace(',', '.').toFloatOrNull()?.let { sugarGrams = it }
                    }
                    "salg", "sal", "salt" -> {
                        value.replace(',', '.').toFloatOrNull()?.let { saltGrams = it }
                    }
                    "consumido", "isconsumed" -> {
                        isConsumed = value.equals("true", ignoreCase = true) || value == "1" || value.equals("si", ignoreCase = true)
                    }
                }
            }

            if (!name.isNullOrBlank()) {
                val finalExpiry = expiryEpochDay
                result.add(
                    PantryItemEntity(
                        name = name.trim(),
                        barcode = barcode?.trim(),
                        category = category.trim().ifBlank { "Despensa" },
                        storageLocation = storageLocation,
                        expiryDateEpochDay = finalExpiry,
                        quantity = quantity,
                        unit = unit.trim().ifBlank { "unidades" },
                        imageUrl = imageUrl?.trim(),
                        caloriesKcal = caloriesKcal,
                        proteinGrams = proteinGrams,
                        carbsGrams = carbsGrams,
                        fatGrams = fatGrams,
                        sugarGrams = sugarGrams,
                        saltGrams = saltGrams,
                        isConsumed = isConsumed,
                        addedTimestamp = System.currentTimeMillis()
                    )
                )
            }
        }

        return result
    }
}
