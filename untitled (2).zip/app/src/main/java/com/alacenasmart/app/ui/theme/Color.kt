package com.alacenasmart.app.ui.theme

import androidx.compose.ui.graphics.Color

val Green80 = Color(0xFF81C784)
val GreenGrey80 = Color(0xFFA5D6A7)
val Amber80 = Color(0xFFFFD54F)

val Green40 = Color(0xFF2E7D32)
val GreenGrey40 = Color(0xFF388E3C)
val Amber40 = Color(0xFFFFA000)

val FreshGreenPrimary = Color(0xFF2E7D32)
val FreshGreenSecondary = Color(0xFF4CAF50)
val FreshGreenTertiary = Color(0xFFFFB300)

val SurfaceLight = Color(0xFFF9FAF8)
val BackgroundLight = Color(0xFFF1F5F2)
val CardLight = Color(0xFFFFFFFF)

val SurfaceDark = Color(0xFF1B241D)
val BackgroundDark = Color(0xFF121813)
val CardDark = Color(0xFF222D24)
