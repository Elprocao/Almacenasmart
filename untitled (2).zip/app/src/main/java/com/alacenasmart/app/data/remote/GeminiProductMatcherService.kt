package com.alacenasmart.app.data.remote

import com.alacenasmart.app.BuildConfig
import com.alacenasmart.app.domain.model.StorageLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class ProductMatchOption(
    val title: String,
    val brandOrCategory: String,
    val storageLocation: StorageLocation,
    val shelfLifeDays: Int,
    val imageUrl: String
)

object GeminiProductMatcherService {

    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    // High quality Curated Fallback image map with reliable Unsplash Food photos
    private val fallbackImageMap = mapOf(
        "leche" to "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&q=80",
        "queso" to "https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?w=400&q=80",
        "yogur" to "https://images.unsplash.com/photo-1571212515416-fef01fc43637?w=400&q=80",
        "mantequilla" to "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=400&q=80",
        "huevo" to "https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?w=400&q=80",
        "manzana" to "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=400&q=80",
        "platano" to "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400&q=80",
        "banana" to "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=400&q=80",
        "tomate" to "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=400&q=80",
        "pollo" to "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=400&q=80",
        "carne" to "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&q=80",
        "ternera" to "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&q=80",
        "cerdo" to "https://images.unsplash.com/photo-1607623814075-e51df1bdc82f?w=400&q=80",
        "pescado" to "https://images.unsplash.com/photo-1534939561126-855b8675edd7?w=400&q=80",
        "salmon" to "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&q=80",
        "atun" to "https://images.unsplash.com/photo-1501595091296-3aa970afb3ff?w=400&q=80",
        "arroz" to "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&q=80",
        "pasta" to "https://images.unsplash.com/photo-1621996346565-e3d5d6281691?w=400&q=80",
        "espagueti" to "https://images.unsplash.com/photo-1621996346565-e3d5d6281691?w=400&q=80",
        "macarron" to "https://images.unsplash.com/photo-1621996346565-e3d5d6281691?w=400&q=80",
        "legumbre" to "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?w=400&q=80",
        "lenteja" to "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?w=400&q=80",
        "garbanzo" to "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?w=400&q=80",
        "alubia" to "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?w=400&q=80",
        "frijol" to "https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?w=400&q=80",
        "pan" to "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&q=80",
        "cafe" to "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&q=80",
        "te" to "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=400&q=80",
        "aceite" to "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&q=80",
        "agua" to "https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=400&q=80",
        "vino" to "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=400&q=80",
        "cerveza" to "https://images.unsplash.com/photo-1608270116666-5062f6b896b0?w=400&q=80",
        "galleta" to "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=400&q=80",
        "chocolate" to "https://images.unsplash.com/photo-1511381939415-e44015466834?w=400&q=80",
        "patata" to "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&q=80",
        "papa" to "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=400&q=80",
        "cebolla" to "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&q=80",
        "ajo" to "https://images.unsplash.com/photo-1540148426945-6cf22a6b2383?w=400&q=80",
        "zanahoria" to "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=400&q=80",
        "naranja" to "https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?w=400&q=80",
        "limon" to "https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=400&q=80",
        "aguacate" to "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=400&q=80",
        "fresa" to "https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=400&q=80",
        "uvas" to "https://images.unsplash.com/photo-1537640538966-79f369143f8f?w=400&q=80",
        "jamon" to "https://images.unsplash.com/photo-1528607929212-2636ec44253e?w=400&q=80",
        "pavo" to "https://images.unsplash.com/photo-1528607929212-2636ec44253e?w=400&q=80",
        "pizza" to "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&q=80",
        "lechuga" to "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&q=80",
        "espinaca" to "https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=400&q=80",
        "pepino" to "https://images.unsplash.com/photo-1449339854873-750e6913301b?w=400&q=80",
        "pimiento" to "https://images.unsplash.com/photo-1563565375-f3fdfdbefa83?w=400&q=80",
        "champiñon" to "https://images.unsplash.com/photo-1504544750208-dc0358e63f7f?w=400&q=80",
        "seta" to "https://images.unsplash.com/photo-1504544750208-dc0358e63f7f?w=400&q=80",
        "harina" to "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&q=80",
        "azucar" to "https://images.unsplash.com/photo-1587132137056-bfbf0166836e?w=400&q=80",
        "sal" to "https://images.unsplash.com/photo-1518110925495-5fe2fda0442c?w=400&q=80",
        "cereal" to "https://images.unsplash.com/photo-1521483451569-e33803c0330c?w=400&q=80",
        "avena" to "https://images.unsplash.com/photo-1586444248902-2f64eddc13df?w=400&q=80",
        "nueces" to "https://images.unsplash.com/photo-1557308536-ee471ef2c390?w=400&q=80",
        "fruto seco" to "https://images.unsplash.com/photo-1557308536-ee471ef2c390?w=400&q=80",
        "helado" to "https://images.unsplash.com/photo-1501443762994-82bd5dace89a?w=400&q=80",
        "mayonesa" to "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400&q=80",
        "ketchup" to "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400&q=80",
        "mostaza" to "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400&q=80",
        "salchicha" to "https://images.unsplash.com/photo-1585325701165-351af916e581?w=400&q=80",
        "bacon" to "https://images.unsplash.com/photo-1528607929212-2636ec44253e?w=400&q=80",
        "hamburguesa" to "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80"
    )

    fun resolvePhotoUrl(keyword: String): String {
        val clean = keyword.lowercase()
        for ((k, url) in fallbackImageMap) {
            if (clean.contains(k)) return url
        }
        return "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&q=80"
    }

    suspend fun analyzeAndFindOptions(userInput: String): List<ProductMatchOption> = withContext(Dispatchers.IO) {
        val cleanInput = userInput.trim()
        if (cleanInput.isBlank()) return@withContext emptyList()

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            val internetOptions = searchOpenFoodFactsInternet(cleanInput)
            return@withContext if (internetOptions.isNotEmpty()) internetOptions else generateLocalOptions(cleanInput)
        }

        try {
            val prompt = """
                El usuario ha escrito: "$cleanInput".
                Actúa como un motor de búsqueda de productos de supermercado tipo Google Lens / Catálogo de compra.
                Devuelve un array JSON con 3 a 5 opciones concretas y realistas de productos que coincidan con lo que el usuario quiso decir (variedades comunes, marcas habituales o tipos específicos).
                
                Para cada opción proporciona:
                - title: Nombre específico del producto (ej: "Tomate rama fresco", "Tomate frito en conserva", "Tomate pera ensalada", "Tomates cherry")
                - category: Una de ["Lácteos", "Carnes", "Frutas y verduras", "Congelados", "Despensa", "Bebidas", "Varios"]
                - storageLocation: Uno de ["NEVERA", "CONGELADOR", "DESPENSA"]
                - shelfLifeDays: Días típicos de caducidad (entero, ej: 7 para tomates frescos, 180 para conservas)
                - imageKeyword: Palabra clave en inglés o español para buscar su foto (ej: "fresh tomatoes", "canned tomatoes", "cherry tomatoes")
                
                Responde ÚNICAMENTE un JSON array con esta estructura:
                [
                  {
                    "title": "...",
                    "category": "...",
                    "storageLocation": "...",
                    "shelfLifeDays": 7,
                    "imageKeyword": "..."
                  }
                ]
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contents = JSONArray().apply {
                    val partObj = JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                        })
                    }
                    put(partObj)
                }
                put("contents", contents)

                val config = JSONObject().apply {
                    put("temperature", 0.3)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", config)
            }

            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .addHeader("x-goog-api-key", apiKey)
                .post(requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val internetOptions = searchOpenFoodFactsInternet(cleanInput)
                return@withContext if (internetOptions.isNotEmpty()) internetOptions else generateLocalOptions(cleanInput)
            }

            val responseBody = response.body?.string() ?: return@withContext generateLocalOptions(cleanInput)
            val jsonRoot = JSONObject(responseBody)
            val candidates = jsonRoot.optJSONArray("candidates") ?: return@withContext generateLocalOptions(cleanInput)
            if (candidates.length() == 0) return@withContext generateLocalOptions(cleanInput)

            val text = candidates.getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")

            val cleanText = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val jsonArray = JSONArray(cleanText)
            val results = mutableListOf<ProductMatchOption>()

            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val title = obj.getString("title")
                val category = obj.optString("category", "Despensa")
                val locationStr = obj.optString("storageLocation", "DESPENSA")
                val location = when (locationStr.uppercase()) {
                    "NEVERA" -> StorageLocation.NEVERA
                    "CONGELADOR" -> StorageLocation.CONGELADOR
                    else -> StorageLocation.DESPENSA
                }
                val shelfLife = obj.optInt("shelfLifeDays", 14)
                val imgKey = obj.optString("imageKeyword", title)
                val imageUrl = resolvePhotoUrl("$title $imgKey $cleanInput")

                results.add(
                    ProductMatchOption(
                        title = title,
                        brandOrCategory = category,
                        storageLocation = location,
                        shelfLifeDays = shelfLife,
                        imageUrl = imageUrl
                    )
                )
            }

            if (results.isNotEmpty()) results else generateLocalOptions(cleanInput)
        } catch (_: Exception) {
            val internetOptions = searchOpenFoodFactsInternet(cleanInput)
            if (internetOptions.isNotEmpty()) internetOptions else generateLocalOptions(cleanInput)
        }
    }

    private fun searchOpenFoodFactsInternet(query: String): List<ProductMatchOption> {
        return try {
            val queryClean = query.trim()
            val queryWords = queryClean.lowercase().split("\\s+".toRegex()).filter { it.length >= 3 }
            val encoded = URLEncoder.encode(queryClean, "UTF-8")
            val url = "https://world.openfoodfacts.org/api/v2/search?search_terms=$encoded&fields=product_name,brands,categories,image_front_url,image_url&page_size=6"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "AlacenaSmart-Android/1.0 (info@alacenasmart.app)")
                .build()
            val res = client.newCall(req).execute()
            if (!res.isSuccessful) return emptyList()
            val body = res.body?.string() ?: return emptyList()
            val root = JSONObject(body)
            val products = root.optJSONArray("products") ?: return emptyList()

            val list = mutableListOf<ProductMatchOption>()
            for (i in 0 until products.length()) {
                val p = products.getJSONObject(i)
                val name = p.optString("product_name", "").trim()
                if (name.isBlank()) continue

                // STRICT FILTER: Only accept products whose name actually matches the user's query
                val nameLower = name.lowercase()
                val matchesQuery = queryWords.isEmpty() || queryWords.any { nameLower.contains(it) }
                if (!matchesQuery) continue

                val brands = p.optString("brands", "").trim()
                val fullTitle = if (brands.isNotBlank() && !name.contains(brands, ignoreCase = true)) {
                    "$name ($brands)"
                } else name

                val imageUrl = p.optString("image_front_url").ifBlank {
                    p.optString("image_url").ifBlank {
                        resolvePhotoUrl(name)
                    }
                }

                val categories = p.optString("categories", "").lowercase()
                val (category, location, days) = when {
                    categories.contains("dairy") || categories.contains("lait") || categories.contains("lact") || categories.contains("cheese") || categories.contains("queso") || categories.contains("yog") ->
                        Triple("Lácteos", StorageLocation.NEVERA, 12)
                    categories.contains("meat") || categories.contains("viande") || categories.contains("carne") || categories.contains("poulet") || categories.contains("pollo") || categories.contains("fish") || categories.contains("poisson") || categories.contains("pescado") ->
                        Triple("Carnes", StorageLocation.NEVERA, 4)
                    categories.contains("fruit") || categories.contains("vegetable") || categories.contains("legume") || categories.contains("verdura") ->
                        Triple("Frutas y verduras", StorageLocation.NEVERA, 8)
                    categories.contains("frozen") || categories.contains("surgel") || categories.contains("congelad") ->
                        Triple("Congelados", StorageLocation.CONGELADOR, 180)
                    categories.contains("beverage") || categories.contains("boisson") || categories.contains("drink") || categories.contains("bebida") ->
                        Triple("Bebidas", StorageLocation.DESPENSA, 90)
                    else ->
                        Triple("Despensa", StorageLocation.DESPENSA, 60)
                }

                list.add(
                    ProductMatchOption(
                        title = fullTitle,
                        brandOrCategory = if (brands.isNotBlank()) brands else category,
                        storageLocation = location,
                        shelfLifeDays = days,
                        imageUrl = imageUrl
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun generateLocalOptions(input: String): List<ProductMatchOption> {
        val clean = input.trim()
        val lower = clean.lowercase()

        val (category, location, days) = when {
            lower.contains("leche") || lower.contains("queso") || lower.contains("yogur") || lower.contains("mantequilla") ->
                Triple("Lácteos", StorageLocation.NEVERA, 12)
            lower.contains("carne") || lower.contains("pollo") || lower.contains("ternera") || lower.contains("pescado") ->
                Triple("Carnes", StorageLocation.NEVERA, 4)
            lower.contains("manzana") || lower.contains("platano") || lower.contains("fruta") || lower.contains("verdura") || lower.contains("tomate") ->
                Triple("Frutas y verduras", StorageLocation.NEVERA, 8)
            lower.contains("helado") || lower.contains("congelad") || lower.contains("pizza") ->
                Triple("Congelados", StorageLocation.CONGELADOR, 180)
            lower.contains("agua") || lower.contains("cerveza") || lower.contains("vino") || lower.contains("zumo") || lower.contains("refresco") ->
                Triple("Bebidas", StorageLocation.DESPENSA, 90)
            else ->
                Triple("Despensa", StorageLocation.DESPENSA, 60)
        }

        val photoUrl = resolvePhotoUrl(clean)

        return listOf(
            ProductMatchOption(
                title = clean.replaceFirstChar { it.uppercase() },
                brandOrCategory = category,
                storageLocation = location,
                shelfLifeDays = days,
                imageUrl = photoUrl
            ),
            ProductMatchOption(
                title = "${clean.replaceFirstChar { it.uppercase() }} (Estándar / Marca Blanca)",
                brandOrCategory = category,
                storageLocation = location,
                shelfLifeDays = days,
                imageUrl = photoUrl
            ),
            ProductMatchOption(
                title = "${clean.replaceFirstChar { it.uppercase() }} Especial / Selección",
                brandOrCategory = category,
                storageLocation = location,
                shelfLifeDays = (days * 1.5).toInt(),
                imageUrl = photoUrl
            )
        )
    }

    suspend fun matchProductOptions(userInput: String): List<ProductMatchOption> = analyzeAndFindOptions(userInput)
}
