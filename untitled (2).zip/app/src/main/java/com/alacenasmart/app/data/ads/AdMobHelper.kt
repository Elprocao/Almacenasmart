package com.alacenasmart.app.data.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform

class AdMobHelper(private val context: Context) {

    private val adFrequencyManager = AdFrequencyManager.getInstance(context)
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var isMobileAdsInitialized = false

    // AdMob Unit IDs from user & Google official test fallbacks
    val bannerAdUnitId = "ca-app-pub-8632805534978950/8915864736"
    val bannerTestAdUnitId = "ca-app-pub-3940256099942544/6300978111"
    val interstitialAdUnitId = "ca-app-pub-8632805534978950/7163799368"
    val interstitialTestAdUnitId = "ca-app-pub-3940256099942544/1033173712"
    private val rewardedAdUnitId = "ca-app-pub-3940256099942544/5224354917"

    fun initializeWithConsent(activity: Activity, onComplete: () -> Unit = {}) {
        if (adFrequencyManager.isPremiumUser) {
            onComplete()
            return
        }

        val params = ConsentRequestParameters.Builder()
            .setTagForUnderAgeOfConsent(false)
            .build()

        val consentInformation = UserMessagingPlatform.getConsentInformation(activity)
        consentInformation.requestConsentInfoUpdate(
            activity,
            params,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) { formError ->
                    if (formError != null) {
                        Log.w("AdMobHelper", "Consent error: ${formError.message}")
                    }
                    if (consentInformation.canRequestAds()) {
                        initializeMobileAds()
                    }
                    onComplete()
                }
            },
            { requestError ->
                Log.w("AdMobHelper", "Consent info update failed: ${requestError.message}")
                if (consentInformation.canRequestAds()) {
                    initializeMobileAds()
                }
                onComplete()
            }
        )
    }

    private fun initializeMobileAds() {
        if (isMobileAdsInitialized || adFrequencyManager.isPremiumUser) return
        MobileAds.initialize(context) {
            isMobileAdsInitialized = true
            loadInterstitial()
            loadRewardedAd()
        }
    }

    fun loadInterstitial() {
        if (adFrequencyManager.isPremiumUser || com.alacenasmart.app.AlacenaApp.instance.billingHelper.isPro.value) return
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            interstitialAdUnitId,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    // Try official Google AdMob test interstitial
                    InterstitialAd.load(
                        context,
                        interstitialTestAdUnitId,
                        AdRequest.Builder().build(),
                        object : InterstitialAdLoadCallback() {
                            override fun onAdLoaded(testAd: InterstitialAd) {
                                interstitialAd = testAd
                            }
                            override fun onAdFailedToLoad(testError: LoadAdError) {
                                interstitialAd = null
                            }
                        }
                    )
                }
            }
        )
    }

    fun showDirectInterstitial(
        activity: Activity,
        onDismissed: () -> Unit = {},
        onFallback: (() -> Unit)? = null
    ) {
        if (adFrequencyManager.isPremiumUser || com.alacenasmart.app.AlacenaApp.instance.billingHelper.isPro.value) {
            onDismissed()
            return
        }

        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    adFrequencyManager.recordInterstitialShown()
                    loadInterstitial()
                    onDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    loadInterstitial()
                    onFallback?.invoke() ?: onDismissed()
                }
            }
            ad.show(activity)
        } else {
            loadInterstitial()
            onFallback?.invoke() ?: onDismissed()
        }
    }

    fun showInterstitialIfAllowed(
        activity: Activity,
        onDismissed: () -> Unit = {},
        onFallback: (() -> Unit)? = null
    ) {
        if (adFrequencyManager.isPremiumUser || com.alacenasmart.app.AlacenaApp.instance.billingHelper.isPro.value || !adFrequencyManager.canShowInterstitial()) {
            onDismissed()
            return
        }

        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    adFrequencyManager.recordInterstitialShown()
                    loadInterstitial()
                    onDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    onFallback?.invoke() ?: onDismissed()
                }
            }
            ad.show(activity)
        } else {
            loadInterstitial()
            onFallback?.invoke() ?: onDismissed()
        }
    }

    fun loadRewardedAd() {
        if (adFrequencyManager.isPremiumUser) return
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            rewardedAdUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            }
        )
    }

    fun showRewardedAd(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onDismissed: () -> Unit
    ) {
        if (adFrequencyManager.isPremiumUser) {
            onRewardEarned()
            onDismissed()
            return
        }

        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewardedAd()
                    onDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    onDismissed()
                }
            }
            ad.show(activity) {
                onRewardEarned()
            }
        } else {
            loadRewardedAd()
            // If ad not loaded, grant grace reward for smooth UX
            onRewardEarned()
            onDismissed()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: AdMobHelper? = null

        fun getInstance(context: Context): AdMobHelper {
            return INSTANCE ?: synchronized(this) {
                val instance = AdMobHelper(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
