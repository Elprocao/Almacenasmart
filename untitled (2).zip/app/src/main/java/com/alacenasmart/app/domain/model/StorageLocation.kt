package com.alacenasmart.app.domain.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.ui.graphics.vector.ImageVector

enum class StorageLocation(val displayName: String) {
    NEVERA("Nevera"),
    DESPENSA("Despensa"),
    CONGELADOR("Congelador");

    val icon: ImageVector
        get() = when (this) {
            NEVERA -> Icons.Default.Kitchen
            DESPENSA -> Icons.Default.Inventory2
            CONGELADOR -> Icons.Default.AcUnit
        }

    companion object {
        fun fromString(value: String): StorageLocation {
            return entries.firstOrNull { it.displayName.equals(value, ignoreCase = true) || it.name.equals(value, ignoreCase = true) }
                ?: DESPENSA
        }
    }
}

