package com.alacenasmart.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "barcode_dictionary")
data class ProductBarcodeEntity(
    @PrimaryKey
    val barcode: String,

    val defaultName: String,

    val defaultCategory: String,

    val typicalShelfLifeDays: Int
)
