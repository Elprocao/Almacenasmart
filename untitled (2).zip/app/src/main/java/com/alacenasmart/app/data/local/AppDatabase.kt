package com.alacenasmart.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.alacenasmart.app.data.local.dao.BarcodeDictionaryDao
import com.alacenasmart.app.data.local.dao.PantryDao
import com.alacenasmart.app.data.local.dao.SavedRecipeDao
import com.alacenasmart.app.data.local.dao.ShoppingDao
import com.alacenasmart.app.data.local.entity.PantryItemEntity
import com.alacenasmart.app.data.local.entity.ProductBarcodeEntity
import com.alacenasmart.app.data.local.entity.SavedRecipeEntity
import com.alacenasmart.app.data.local.entity.ShoppingItemEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate

@Database(
    entities = [
        PantryItemEntity::class,
        ShoppingItemEntity::class,
        ProductBarcodeEntity::class,
        SavedRecipeEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun pantryDao(): PantryDao
    abstract fun shoppingDao(): ShoppingDao
    abstract fun barcodeDictionaryDao(): BarcodeDictionaryDao
    abstract fun savedRecipeDao(): SavedRecipeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "alacenasmart_database"
                )
                    .addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        private suspend fun populateInitialData(database: AppDatabase) {
            val barcodeDao = database.barcodeDictionaryDao()

            // Pre-populate common barcode dictionary for instant scanning
            val initialBarcodes = listOf(
                ProductBarcodeEntity("841000000001", "Leche Entera 1L", "Lácteos", 10),
                ProductBarcodeEntity("841000000002", "Huevos Camperos Docena", "Lácteos", 21),
                ProductBarcodeEntity("841000000003", "Yogur Griego Natural", "Lácteos", 14),
                ProductBarcodeEntity("841000000004", "Pechuga de Pollo 500g", "Carnes", 4),
                ProductBarcodeEntity("841000000005", "Carne Picada Vacuno", "Carnes", 3),
                ProductBarcodeEntity("841000000006", "Manzanas Golden 1kg", "Frutas y verduras", 12),
                ProductBarcodeEntity("841000000007", "Tomates Ensalada 1kg", "Frutas y verduras", 7),
                ProductBarcodeEntity("841000000008", "Espinacas Frescas 300g", "Frutas y verduras", 5),
                ProductBarcodeEntity("841000000009", "Arroz Redondo 1kg", "Despensa", 365),
                ProductBarcodeEntity("841000000010", "Pasta Espaguetis 500g", "Despensa", 365),
                ProductBarcodeEntity("841000000011", "Aceite de Oliva Virgen Extra", "Despensa", 365),
                ProductBarcodeEntity("841000000012", "Atún Claro en Aceite (Pack 3)", "Despensa", 720),
                ProductBarcodeEntity("841000000013", "Guisantes Congelados 400g", "Congelados", 180),
                ProductBarcodeEntity("841000000014", "Zumo de Naranja 1L", "Bebidas", 30),
                ProductBarcodeEntity("841000000015", "Queso Curado 250g", "Lácteos", 45)
            )
            barcodeDao.insertAll(initialBarcodes)
            // Pantry starts completely empty so the user can register their own items fresh
        }
    }
}
