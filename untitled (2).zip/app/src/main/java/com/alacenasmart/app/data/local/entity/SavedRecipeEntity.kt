package com.alacenasmart.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_recipes")
data class SavedRecipeEntity(
    @PrimaryKey
    val id: String,

    val title: String,

    val description: String,

    val category: String,

    val difficulty: String,

    val prepTimeMinutes: Int,

    val servings: Int = 2,

    val restTimeMinutes: Int = 0,

    val cookingTemp: String? = null,

    val requiredIngredientsJson: String,

    val stepsJson: String,

    val caloriesKcal: Int = 0,

    val proteinGrams: Float = 0f,

    val carbsGrams: Float = 0f,

    val fatGrams: Float = 0f,

    val sugarGrams: Float = 0f,

    val saltGrams: Float = 0f,

    val isFavorite: Boolean = false,

    val savedTimestamp: Long = System.currentTimeMillis()
)
