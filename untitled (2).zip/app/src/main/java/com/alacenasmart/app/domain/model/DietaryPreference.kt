package com.alacenasmart.app.domain.model

enum class DietaryPreference(val label: String, val promptInstruction: String) {
    ALL("Todas", "Cualquier estilo culinario"),
    EXPIRING_PRIORITY("Salvar por caducar", "PRIORIDAD MÁXIMA: Da prioridad absoluta y exclusiva a utilizar los ingredientes que caducan en las próximas 24 a 48 horas para evitar que se echen a perder."),
    LOW_CALORIE("Fitness / Bajas calorías", "Enfócate en recetas bajas en calorías, ricas en proteína y ligeras."),
    QUICK("Rápidas (< 15 min)", "Recetas exprés que se preparen y cocinen en menos de 15 minutos en total."),
    VEGETARIAN("Vegetariana", "Sin carnes ni pescados; solo huevos, lácteos, legumbres y vegetales."),
    GLUTEN_FREE("Sin Gluten", "Sin harinas con trigo, cebada, centeno ni pastas con gluten."),
    DAIRY_FREE("Sin Lactosa", "Sin leche, queso, mantequilla ni derivados lácteos.")
}
