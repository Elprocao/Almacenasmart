package com.alacenasmart.app.ui.settings

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alacenasmart.app.billing.BillingHelper
import com.alacenasmart.app.data.util.PantryTxtFormatUtil
import com.alacenasmart.app.domain.repository.PantryRepository
import com.alacenasmart.app.workers.ExpiryNotificationWorker
import com.google.android.ump.UserMessagingPlatform
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.BufferedReader

@Composable
fun SettingsScreen(
    billingHelper: BillingHelper,
    repository: PantryRepository,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isPro by billingHelper.isPro.collectAsStateWithLifecycle()
    val proPlanType by billingHelper.planType.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    val prefs = remember { context.getSharedPreferences("alacenasmart_settings", Context.MODE_PRIVATE) }
    var notificationsEnabled by remember {
        mutableStateOf(prefs.getBoolean("key_notifications_enabled", true))
    }

    var showClearDataDialog by remember { mutableStateOf(false) }
    var showPasteImportDialog by remember { mutableStateOf(false) }
    var pasteImportText by remember { mutableStateOf("") }

    // TXT File Picker for Importing
    val txtFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val content = inputStream?.bufferedReader()?.use(BufferedReader::readText) ?: ""
                    if (content.isBlank()) {
                        snackbarHostState.showSnackbar("El archivo TXT seleccionado está vacío")
                        return@launch
                    }
                    val items = PantryTxtFormatUtil.parseFromTxt(content)
                    if (items.isEmpty()) {
                        snackbarHostState.showSnackbar("No se han podido reconocer alimentos en el archivo TXT")
                    } else {
                        val count = repository.importPantryItems(items)
                        snackbarHostState.showSnackbar("¡Éxito! Se han importado $count alimentos con sus fotos y datos")
                    }
                } catch (e: Exception) {
                    snackbarHostState.showSnackbar("Error al leer el archivo TXT: ${e.localizedMessage}")
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("settings_screen_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Screen Title
            item {
                Text(
                    text = "Ajustes",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Pro Membership Card (Lifetime & Monthly)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPro) Color(0xFF1B5E20) else Color(0xFF2E3A2F)
                    )
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(if (isPro) Color(0xFFFFD54F) else Color(0xFF4CAF50)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isPro) Icons.Default.Verified else Icons.Default.WorkspacePremium,
                                    contentDescription = null,
                                    tint = if (isPro) Color.Black else Color.White
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isPro) "AlacenaSmart Pro Activo" else "AlacenaSmart Pro",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = if (isPro) {
                                        val isLifetime = proPlanType?.contains("Vida", ignoreCase = true) == true || proPlanType == BillingHelper.PLAN_LIFETIME
                                        if (isLifetime) {
                                            "Plan: De por vida • Acceso permanente sin anuncios"
                                        } else {
                                            val expiry = com.alacenasmart.app.AlacenaApp.instance.adFrequencyManager.premiumExpirationTime
                                            val daysLeft = if (expiry != Long.MAX_VALUE) {
                                                val diff = expiry - System.currentTimeMillis()
                                                maxOf(0L, diff / (1000L * 60 * 60 * 24)).toInt()
                                            } else 30
                                            "Plan Mensual: $daysLeft días restantes sin anuncios"
                                        }
                                    } else {
                                        "Sin banner inferior, sin anuncios de 15 segundos y cámara IA ilimitada"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFE0E0E0)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (!isPro) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                // Opción 1: Compra de por vida
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color(0xFF3B4A3C),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(end = 12.dp)
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = Color(0xFFFFD54F),
                                                modifier = Modifier.padding(bottom = 6.dp)
                                            ) {
                                                Text(
                                                    text = "★ MÁS POPULAR",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Black,
                                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                                )
                                            }
                                            Text(
                                                text = "Pago Único De Por Vida",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "9,99 € un solo pago para siempre",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFFE0E0E0)
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                val activity = context as? Activity
                                                if (activity != null) {
                                                    billingHelper.launchBillingFlow(activity, BillingHelper.PRODUCT_ID_PRO_LIFETIME)
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = Color(0xFFFFD54F),
                                                contentColor = Color.Black
                                            ),
                                            shape = RoundedCornerShape(12.dp),
                                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                                            modifier = Modifier.testTag("btn_upgrade_lifetime")
                                        ) {
                                            Text("Comprar", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                // Opción 2: Suscripción Mensual
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color(0xFF3B4A3C).copy(alpha = 0.8f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(end = 12.dp)
                                        ) {
                                            Text(
                                                text = "Suscripción Mensual",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "1,99 € / mes • Cancela cuando quieras",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color(0xFFE0E0E0)
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                val activity = context as? Activity
                                                if (activity != null) {
                                                    billingHelper.launchBillingFlow(activity, BillingHelper.PRODUCT_ID_PRO_MONTHLY)
                                                }
                                            },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                                            shape = RoundedCornerShape(12.dp),
                                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                                            modifier = Modifier.testTag("btn_upgrade_monthly")
                                        ) {
                                            Text("Suscribirme")
                                        }
                                    }
                                }
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    billingHelper.setProActive(false)
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Modo gratuito activado para pruebas")
                                    }
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Restablecer a versión estándar (Pruebas)")
                            }
                        }
                    }
                }
            }

            // Notifications Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Notificaciones",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 12.dp)
                            ) {
                                Text(
                                    text = "Avisos de caducidad diaria",
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Recibe alertas por la mañana sobre alimentos a punto de caducar",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Switch(
                                checked = notificationsEnabled,
                                onCheckedChange = { enabled ->
                                    notificationsEnabled = enabled
                                    prefs.edit().putBoolean("key_notifications_enabled", enabled).apply()
                                    if (enabled) {
                                        ExpiryNotificationWorker.scheduleDaily(context)
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Notificaciones de caducidad activadas")
                                        }
                                    } else {
                                        ExpiryNotificationWorker.cancel(context)
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Notificaciones desactivadas")
                                        }
                                    }
                                },
                                colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
                            )
                        }
                    }
                }
            }

            // Data & Pantry TXT Backup Section (Import / Export)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Copia de Seguridad y Datos (Formato TXT)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Exporta e importa todos los alimentos de tu despensa, incluyendo categorías, caducidades, cantidades y enlaces de imagen de internet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Export TXT
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val items = repository.getPantryItems().first()
                                    if (items.isEmpty()) {
                                        snackbarHostState.showSnackbar("La despensa está vacía. Añade alimentos antes de exportar.")
                                        return@launch
                                    }
                                    val txtData = PantryTxtFormatUtil.exportToTxt(items)

                                    // Copy to clipboard
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                    clipboard?.setPrimaryClip(ClipData.newPlainText("Despensa AlacenaSmart TXT", txtData))

                                    // Share intent
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, txtData)
                                        putExtra(Intent.EXTRA_TITLE, "Copia de Seguridad Despensa AlacenaSmart.txt")
                                        type = "text/plain"
                                    }
                                    val shareIntent = Intent.createChooser(sendIntent, "Exportar despensa en TXT")
                                    context.startActivity(shareIntent)

                                    snackbarHostState.showSnackbar("Copia TXT generada (${items.size} alimentos con fotos y datos)")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_export_txt"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Exportar despensa en formato TXT")
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Import TXT file
                            OutlinedButton(
                                onClick = { txtFilePicker.launch("text/*") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_import_file_txt"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.FileUpload, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Importar archivo")
                            }

                            // Import TXT paste
                            OutlinedButton(
                                onClick = { showPasteImportDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_import_paste_txt"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pegar texto")
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Privacy Form (UMP / GDPR)
                        OutlinedButton(
                            onClick = {
                                val activity = context as? Activity
                                if (activity != null) {
                                    UserMessagingPlatform.showPrivacyOptionsForm(activity) { error ->
                                        if (error != null) {
                                            coroutineScope.launch {
                                                snackbarHostState.showSnackbar("Opciones de privacidad no disponibles en este momento")
                                            }
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PrivacyTip, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Privacidad y Consentimiento de Anuncios")
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Delete all data
                        OutlinedButton(
                            onClick = { showClearDataDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Borrar todos los datos de la despensa")
                        }
                    }
                }
            }

            // About Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Acerca de AlacenaSmart",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Versión 1.0.0 • Zero-Waste Kitchen",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Diseñada para ayudarte a ahorrar dinero y reducir el desperdicio de comida mediante el control inteligente de caducidades, búsqueda de productos con fotos de internet y recetas de aprovechamiento.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Paste TXT Import Dialog
        if (showPasteImportDialog) {
            AlertDialog(
                onDismissRequest = { showPasteImportDialog = false },
                title = { Text("Importar Despensa desde Texto TXT") },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Pega a continuación el contenido en formato TXT exportado previamente (incluye nombres, categorías, fotos y caducidades):",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = pasteImportText,
                            onValueChange = { pasteImportText = it },
                            placeholder = { Text("Nombre: Leche Pascual\nCategoria: Lácteos\nImagenUrl: https://...\n---") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            maxLines = 15
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (pasteImportText.isNotBlank()) {
                                coroutineScope.launch {
                                    val items = PantryTxtFormatUtil.parseFromTxt(pasteImportText)
                                    if (items.isEmpty()) {
                                        snackbarHostState.showSnackbar("No se han reconocido alimentos válidos en el texto.")
                                    } else {
                                        val count = repository.importPantryItems(items)
                                        showPasteImportDialog = false
                                        pasteImportText = ""
                                        snackbarHostState.showSnackbar("¡Éxito! Se han importado $count alimentos a tu despensa.")
                                    }
                                }
                            }
                        },
                        enabled = pasteImportText.isNotBlank()
                    ) {
                        Text("Importar")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showPasteImportDialog = false }) {
                        Text("Cancelar")
                    }
                }
            )
        }

        // Clear Data Dialog
        if (showClearDataDialog) {
            AlertDialog(
                onDismissRequest = { showClearDataDialog = false },
                title = { Text("¿Eliminar todos los datos?") },
                text = { Text("Esta acción eliminará todos los alimentos de tu despensa y la lista de compras de forma permanente.") },
                confirmButton = {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                repository.clearAllData()
                                showClearDataDialog = false
                                snackbarHostState.showSnackbar("Todos los datos han sido borrados")
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Eliminar todo")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearDataDialog = false }) {
                        Text("Cancelar")
                    }
                }
            )
        }
    }
}
