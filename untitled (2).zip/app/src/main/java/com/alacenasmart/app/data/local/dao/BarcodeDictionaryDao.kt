package com.alacenasmart.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.alacenasmart.app.data.local.entity.ProductBarcodeEntity

@Dao
interface BarcodeDictionaryDao {

    @Query("SELECT * FROM barcode_dictionary WHERE barcode = :barcode LIMIT 1")
    suspend fun getByBarcode(barcode: String): ProductBarcodeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(entity: ProductBarcodeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(list: List<ProductBarcodeEntity>)

    @Query("SELECT * FROM barcode_dictionary ORDER BY defaultName ASC")
    suspend fun getAll(): List<ProductBarcodeEntity>
}
