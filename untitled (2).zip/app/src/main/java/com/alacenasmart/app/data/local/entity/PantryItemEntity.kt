package com.alacenasmart.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pantry_items")
data class PantryItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val name: String,

    val barcode: String? = null,

    val category: String,

    val storageLocation: String,

    val expiryDateEpochDay: Long? = null,

    val quantity: Int = 1,

    val unit: String = "unidades",

    val isConsumed: Boolean = false,

    val addedTimestamp: Long = System.currentTimeMillis(),

    val imageUrl: String? = null,

    val caloriesKcal: Int? = null,

    val proteinGrams: Float? = null,

    val carbsGrams: Float? = null,

    val fatGrams: Float? = null,

    val sugarGrams: Float? = null,

    val saltGrams: Float? = null
)
