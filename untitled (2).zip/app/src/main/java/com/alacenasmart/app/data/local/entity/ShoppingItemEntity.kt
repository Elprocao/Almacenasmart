package com.alacenasmart.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shopping_list")
data class ShoppingItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val name: String,

    val category: String,

    val quantity: Int = 1,

    val isChecked: Boolean = false,

    val originPantryItemId: Long? = null,

    val imageUrl: String? = null
)
