package com.alacenasmart.app.data.ads

import android.content.Context
import android.content.SharedPreferences

class AdFrequencyManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var isPremiumUser: Boolean
        get() {
            val isPro = prefs.getBoolean(KEY_IS_PREMIUM, false)
            if (!isPro) return false

            val expiry = prefs.getLong(KEY_PREMIUM_EXPIRATION_TIME, Long.MAX_VALUE)
            val now = System.currentTimeMillis()
            if (expiry != Long.MAX_VALUE && now > expiry) {
                // Subscription has expired
                prefs.edit().putBoolean(KEY_IS_PREMIUM, false).apply()
                return false
            }
            return true
        }
        set(value) {
            prefs.edit().putBoolean(KEY_IS_PREMIUM, value).apply()
        }

    var premiumPlanType: String?
        get() = prefs.getString(KEY_PREMIUM_PLAN_TYPE, null)
        set(value) {
            prefs.edit().putString(KEY_PREMIUM_PLAN_TYPE, value).apply()
        }

    var premiumExpirationTime: Long
        get() = prefs.getLong(KEY_PREMIUM_EXPIRATION_TIME, Long.MAX_VALUE)
        set(value) {
            prefs.edit().putLong(KEY_PREMIUM_EXPIRATION_TIME, value).apply()
        }

    fun setPremiumPlan(active: Boolean, planType: String) {
        isPremiumUser = active
        premiumPlanType = if (active) planType else null
        premiumExpirationTime = if (active) {
            if (planType.contains("Vida", ignoreCase = true) || planType.contains("Lifetime", ignoreCase = true)) {
                Long.MAX_VALUE
            } else {
                // 30 days monthly plan duration
                System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000L)
            }
        } else {
            0L
        }
    }

    private var activeSessionStart: Long = 0L

    fun onAppResume() {
        activeSessionStart = System.currentTimeMillis()
    }

    fun onAppPause() {
        if (activeSessionStart > 0) {
            val sessionElapsed = System.currentTimeMillis() - activeSessionStart
            val accumulated = prefs.getLong(KEY_ACCUMULATED_ACTIVE_TIME_MS, 0L)
            prefs.edit().putLong(KEY_ACCUMULATED_ACTIVE_TIME_MS, accumulated + sessionElapsed).apply()
            activeSessionStart = 0L
        }
    }

    fun getActiveUsageTimeMs(): Long {
        val accumulated = prefs.getLong(KEY_ACCUMULATED_ACTIVE_TIME_MS, 0L)
        val currentSessionTime = if (activeSessionStart > 0) {
            System.currentTimeMillis() - activeSessionStart
        } else 0L
        return accumulated + currentSessionTime
    }

    /**
     * User rule: "un anuncio de 15s cada 8 minutos con la app abierta"
     * 8 minutes = 8 * 60 * 1000 ms = 480,000 ms
     */
    fun shouldShowPeriodicAd(): Boolean {
        if (isPremiumUser) return false
        return getActiveUsageTimeMs() >= EIGHT_MINUTES_MS
    }

    fun canShowInterstitial(): Boolean {
        if (isPremiumUser) return false
        return shouldShowPeriodicAd()
    }

    fun recordInterstitialShown() {
        prefs.edit()
            .putLong(KEY_LAST_INTERSTITIAL_TIME, System.currentTimeMillis())
            .putLong(KEY_ACCUMULATED_ACTIVE_TIME_MS, 0L)
            .apply()
        activeSessionStart = System.currentTimeMillis()
    }

    companion object {
        private const val PREFS_NAME = "alacenasmart_ad_prefs"
        private const val KEY_IS_PREMIUM = "key_is_premium"
        private const val KEY_PREMIUM_PLAN_TYPE = "key_premium_plan_type"
        private const val KEY_PREMIUM_EXPIRATION_TIME = "key_premium_expiration_time"
        private const val KEY_LAST_INTERSTITIAL_TIME = "key_last_interstitial_time"
        private const val KEY_ACCUMULATED_ACTIVE_TIME_MS = "key_accumulated_active_time"

        // 8 minutes of foreground open app usage
        const val EIGHT_MINUTES_MS = 8 * 60 * 1000L

        @Volatile
        private var INSTANCE: AdFrequencyManager? = null

        fun getInstance(context: Context): AdFrequencyManager {
            return INSTANCE ?: synchronized(this) {
                val instance = AdFrequencyManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
