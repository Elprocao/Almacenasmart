package com.alacenasmart.app.data.remote

import android.graphics.Bitmap
import android.util.Base64
import com.alacenasmart.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.TimeUnit

data class DetectedProduct(
    val id: String = UUID.randomUUID().toString(),
    val productName: String,
    val category: String,
    val storageLocation: com.alacenasmart.app.domain.model.StorageLocation = com.alacenasmart.app.domain.model.StorageLocation.DESPENSA,
    val quantity: Int = 1,
    val shelfLifeDays: Int? = null,
    val expiryDateEpochDay: Long? = null,
    val caloriesKcal: Int? = null,
    val proteinGrams: Float? = null,
    val carbsGrams: Float? = null,
    val fatGrams: Float? = null,
    val sugarGrams: Float? = null,
    val saltGrams: Float? = null
)

// Legacy alias for compatibility
data class VisualProductIdentification(
    val productName: String,
    val category: String,
    val typicalShelfLifeDays: Int = 7
)

data class EstimatedNutrition(
    val caloriesKcal: Int? = null,
    val proteinGrams: Float? = null,
    val carbsGrams: Float? = null,
    val fatGrams: Float? = null,
    val sugarGrams: Float? = null,
    val saltGrams: Float? = null
)

data class VisionAnalysisResult(
    val detectedName: String,
    val category: String,
    val typicalShelfLifeDays: Int,
    val expiryDateEpochDay: Long? = null,
    val confidence: Float = 0.95f,
    val estimatedNutrition: EstimatedNutrition? = null
)

object GeminiVisionService {

    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        val safeSoftwareBitmap = try {
            if (config == Bitmap.Config.HARDWARE) {
                copy(Bitmap.Config.ARGB_8888, false) ?: this
            } else {
                this
            }
        } catch (_: Throwable) {
            this
        }

        val maxDim = 800
        val scaled = if (safeSoftwareBitmap.width > maxDim || safeSoftwareBitmap.height > maxDim) {
            val ratio = safeSoftwareBitmap.width.toFloat() / safeSoftwareBitmap.height.toFloat()
            val newWidth = if (ratio >= 1f) maxDim else (maxDim * ratio).toInt().coerceAtLeast(1)
            val newHeight = if (ratio >= 1f) (maxDim / ratio).toInt().coerceAtLeast(1) else maxDim
            try {
                Bitmap.createScaledBitmap(safeSoftwareBitmap, newWidth, newHeight, true)
            } catch (_: Throwable) {
                safeSoftwareBitmap
            }
        } else {
            safeSoftwareBitmap
        }

        scaled.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
        if (scaled != this && scaled != safeSoftwareBitmap) {
            try { scaled.recycle() } catch (_: Throwable) {}
        }
        if (safeSoftwareBitmap != this) {
            try { safeSoftwareBitmap.recycle() } catch (_: Throwable) {}
        }
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun detectMultipleProductsFromBitmap(bitmap: Bitmap): Result<List<DetectedProduct>> {
        return detectProductsFromBitmaps(listOf(bitmap))
    }

    suspend fun detectProductsFromBitmaps(bitmaps: List<Bitmap>): Result<List<DetectedProduct>> = withContext(Dispatchers.IO) {
        if (bitmaps.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("No se proporcionó ninguna imagen."))
        }

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("Se requiere configurar la clave de API de Gemini en Ajustes.")
            )
        }

        try {
            val systemPrompt = """
                Eres el sistema de reconocimiento visual de alimentos y nutrición de AlacenaSmart.
                Examina minuciosamente TODAS las imágenes de alimentos suministradas (puede haber 1 o varias fotos).
                Detecta TODOS los alimentos o productos alimenticios visibles en todas las imágenes.
                
                REGLA FUNDAMENTAL DE SUMA DE UNIDADES:
                Si un producto aparece en varias fotos o repetido en la misma foto (por ejemplo, 1 paquete de leche en la foto 1 y 2 paquetes de leche en la foto 2), DEBES SUMAR las cantidades y reportar un único producto 'Leche' con quantity: 3. Nunca dupliques el mismo producto en la lista.
                
                ORGANIZACIÓN POR SECCIÓN (storageLocation):
                Asigna a cada producto una de estas opciones exactas según dónde debe conservarse:
                - "Nevera" (lácteos, embutidos, carnes frescas, alimentos refrigerados)
                - "Despensa" (conservas, pastas, arroces, legumbres, aceites, especias)
                - "Congelador" (alimentos congelados, hielo, verduras ultracongeladas)
                
                CATEGORÍA (category):
                Una de: "Frutas y verduras", "Lácteos", "Carnes", "Pescados", "Despensa", "Congelados", "Bebidas", "Varios".
                
                FECHA DE CADUCIDAD APROXIMADA (shelfLifeDays):
                Indica los días aproximados de vida útil desde hoy para el producto.
                IMPORTANTE: Si la fecha de caducidad NO es deducible de forma lógica (por ejemplo, alimentos no perecederos indefinidos o no se puede deducir), pon 'shelfLifeDays': null.
                
                INFORMACIÓN NUTRICIONAL ESTIMADA (por 100g o ración típica):
                caloriesKcal (entero), proteinGrams (float), carbsGrams (float), fatGrams (float), sugarGrams (float), saltGrams (float).
                
                Responde ÚNICAMENTE con un objeto JSON con este formato exacto:
                {
                  "products": [
                    {
                      "productName": "Leche entera",
                      "category": "Lácteos",
                      "storageLocation": "Nevera",
                      "quantity": 3,
                      "shelfLifeDays": 7,
                      "caloriesKcal": 64,
                      "proteinGrams": 3.2,
                      "carbsGrams": 4.8,
                      "fatGrams": 3.6,
                      "sugarGrams": 4.8,
                      "saltGrams": 0.1
                    }
                  ]
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject().apply {
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().apply {
                        put("text", "Detecta todos los alimentos visibles en las fotos, suma las unidades si se repiten entre imágenes, asígnales sección (Nevera/Despensa/Congelador) e información nutricional y caducidad aproximada.")
                    })
                    for (bitmap in bitmaps) {
                        val base64 = bitmap.toBase64()
                        partsArray.put(JSONObject().apply {
                            val inlineDataObj = JSONObject().apply {
                                put("mimeType", "image/jpeg")
                                put("data", base64)
                            }
                            put("inlineData", inlineDataObj)
                        })
                    }
                    put("parts", partsArray)
                }
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                val sysInstruction = JSONObject().apply {
                    val parts = JSONArray()
                    parts.put(JSONObject().apply { put("text", systemPrompt) })
                    put("parts", parts)
                }
                put("systemInstruction", sysInstruction)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.2)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", genConfig)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val url = "$BASE_URL?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: ""
                val userFriendlyMsg = try {
                    val errJson = JSONObject(errBody).optJSONObject("error")
                    val rawMsg = errJson?.optString("message") ?: ""
                    when {
                        rawMsg.contains("API_KEY_INVALID", ignoreCase = true) || rawMsg.contains("API key not valid", ignoreCase = true) ->
                            "Clave de API de Gemini no válida. Por favor, revísala en los Ajustes."
                        rawMsg.contains("RESOURCE_EXHAUSTED", ignoreCase = true) || rawMsg.contains("quota", ignoreCase = true) ->
                            "Límite de cuota alcanzado temporalmente. Inténtalo de nuevo en unos momentos."
                        rawMsg.isNotBlank() -> "Error de IA: $rawMsg"
                        else -> "Error en el reconocimiento visual (${response.code})"
                    }
                } catch (_: Exception) {
                    "Error al comunicarse con Gemini (${response.code})"
                }
                return@withContext Result.failure(Exception(userFriendlyMsg))
            }

            val responseBody = response.body?.string() ?: throw IllegalStateException("Respuesta vacía de Gemini")
            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.failure(Exception("No se pudieron identificar productos en las fotos."))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.getJSONObject(0)?.optString("text") ?: "{}"

            val cleanJson = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val parsedObj = JSONObject(cleanJson)

            val rawProducts = mutableListOf<DetectedProduct>()
            val jsonArray = parsedObj.optJSONArray("products")

            fun parseItem(item: JSONObject): DetectedProduct {
                val name = item.optString("productName", "Alimento identificado").trim()
                val category = item.optString("category", "Despensa").trim()
                val locStr = item.optString("storageLocation", "Despensa").trim()
                val storageLoc = com.alacenasmart.app.domain.model.StorageLocation.fromString(locStr)
                val quantity = item.optInt("quantity", 1).coerceAtLeast(1)

                val shelfLifeDays: Int? = if (!item.isNull("shelfLifeDays") && item.has("shelfLifeDays")) {
                    val days = item.optInt("shelfLifeDays", -1)
                    if (days > 0) days else null
                } else null

                val expiryEpochDay: Long? = shelfLifeDays?.let {
                    java.time.LocalDate.now().plusDays(it.toLong()).toEpochDay()
                }

                val calories = if (!item.isNull("caloriesKcal") && item.has("caloriesKcal")) item.optInt("caloriesKcal", 0) else null
                val protein = if (!item.isNull("proteinGrams") && item.has("proteinGrams")) item.optDouble("proteinGrams", 0.0).toFloat() else null
                val carbs = if (!item.isNull("carbsGrams") && item.has("carbsGrams")) item.optDouble("carbsGrams", 0.0).toFloat() else null
                val fat = if (!item.isNull("fatGrams") && item.has("fatGrams")) item.optDouble("fatGrams", 0.0).toFloat() else null
                val sugar = if (!item.isNull("sugarGrams") && item.has("sugarGrams")) item.optDouble("sugarGrams", 0.0).toFloat() else null
                val salt = if (!item.isNull("saltGrams") && item.has("saltGrams")) item.optDouble("saltGrams", 0.0).toFloat() else null

                return DetectedProduct(
                    productName = name,
                    category = category,
                    storageLocation = storageLoc,
                    quantity = quantity,
                    shelfLifeDays = shelfLifeDays,
                    expiryDateEpochDay = expiryEpochDay,
                    caloriesKcal = calories,
                    proteinGrams = protein,
                    carbsGrams = carbs,
                    fatGrams = fat,
                    sugarGrams = sugar,
                    saltGrams = salt
                )
            }

            if (jsonArray != null && jsonArray.length() > 0) {
                for (i in 0 until jsonArray.length()) {
                    rawProducts.add(parseItem(jsonArray.getJSONObject(i)))
                }
            } else if (parsedObj.has("productName")) {
                rawProducts.add(parseItem(parsedObj))
            }

            if (rawProducts.isEmpty()) {
                return@withContext Result.failure(Exception("No se detectó ningún alimento reconocible en las fotos."))
            }

            // Client-side aggregation ensuring multiple occurrences sum their quantities!
            val aggregatedMap = linkedMapOf<String, DetectedProduct>()
            for (p in rawProducts) {
                val key = p.productName.lowercase().trim()
                val existing = aggregatedMap[key]
                if (existing == null) {
                    aggregatedMap[key] = p
                } else {
                    aggregatedMap[key] = existing.copy(
                        quantity = existing.quantity + p.quantity,
                        expiryDateEpochDay = when {
                            existing.expiryDateEpochDay == null -> p.expiryDateEpochDay
                            p.expiryDateEpochDay == null -> existing.expiryDateEpochDay
                            else -> minOf(existing.expiryDateEpochDay, p.expiryDateEpochDay)
                        },
                        caloriesKcal = existing.caloriesKcal ?: p.caloriesKcal,
                        proteinGrams = existing.proteinGrams ?: p.proteinGrams,
                        carbsGrams = existing.carbsGrams ?: p.carbsGrams,
                        fatGrams = existing.fatGrams ?: p.fatGrams,
                        sugarGrams = existing.sugarGrams ?: p.sugarGrams,
                        saltGrams = existing.saltGrams ?: p.saltGrams
                    )
                }
            }

            Result.success(aggregatedMap.values.toList())
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    suspend fun identifyProductFromBitmap(bitmap: Bitmap): Result<VisualProductIdentification> {
        return detectMultipleProductsFromBitmap(bitmap).map { list ->
            val first = list.firstOrNull() ?: DetectedProduct(productName = "Alimento", category = "Despensa")
            VisualProductIdentification(
                productName = first.productName,
                category = first.category,
                typicalShelfLifeDays = first.shelfLifeDays ?: 7
            )
        }
    }

    suspend fun analyzeFoodImage(bitmap: Bitmap): VisionAnalysisResult {
        val list = detectProductsFromBitmaps(listOf(bitmap)).getOrThrow()
        val first = list.firstOrNull() ?: throw IllegalStateException("No se pudo detectar ningún alimento")
        return VisionAnalysisResult(
            detectedName = first.productName,
            category = first.category,
            typicalShelfLifeDays = first.shelfLifeDays ?: 7,
            expiryDateEpochDay = first.expiryDateEpochDay,
            confidence = 0.94f,
            estimatedNutrition = EstimatedNutrition(
                caloriesKcal = first.caloriesKcal,
                proteinGrams = first.proteinGrams,
                carbsGrams = first.carbsGrams,
                fatGrams = first.fatGrams,
                sugarGrams = first.sugarGrams,
                saltGrams = first.saltGrams
            )
        )
    }
}
