package com.alacenasmart.app.domain.repository

import com.alacenasmart.app.data.local.entity.PantryItemEntity
import com.alacenasmart.app.data.local.entity.ProductBarcodeEntity
import com.alacenasmart.app.data.local.entity.ShoppingItemEntity
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.Recipe
import com.alacenasmart.app.domain.model.StorageLocation
import kotlinx.coroutines.flow.Flow

interface PantryRepository {
    fun getPantryItems(): Flow<List<PantryItem>>
    fun getExpiringItems(thresholdDays: Long): Flow<List<PantryItem>>
    suspend fun getItemById(id: Long): PantryItem?
    suspend fun addPantryItem(
        name: String,
        barcode: String?,
        category: String,
        storageLocation: StorageLocation,
        expiryDateEpochDay: Long?,
        quantity: Int,
        unit: String,
        imageUrl: String?,
        caloriesKcal: Int?,
        proteinGrams: Float?,
        carbsGrams: Float?,
        fatGrams: Float?,
        sugarGrams: Float?,
        saltGrams: Float?
    ): Long
    suspend fun importPantryItems(items: List<PantryItemEntity>): Int
    suspend fun updatePantryItem(item: PantryItem)
    suspend fun deletePantryItem(id: Long)
    suspend fun setItemConsumed(id: Long, isConsumed: Boolean)

    suspend fun lookupBarcode(barcode: String): ProductBarcodeEntity?
    suspend fun saveBarcodeProduct(
        barcode: String,
        name: String,
        category: String,
        shelfLifeDays: Int
    )

    fun getShoppingItems(): Flow<List<ShoppingItemEntity>>
    suspend fun addShoppingItem(
        name: String,
        category: String,
        quantity: Int,
        originPantryItemId: Long? = null,
        imageUrl: String? = null
    ): Long
    suspend fun updateShoppingItem(item: ShoppingItemEntity)
    suspend fun toggleShoppingItem(id: Long, isChecked: Boolean)
    suspend fun deleteShoppingItem(id: Long)
    suspend fun clearCheckedShoppingItems()
    suspend fun clearAllShoppingItems()

    fun getSavedRecipes(): Flow<List<Recipe>>
    fun getFavoriteRecipes(): Flow<List<Recipe>>
    suspend fun saveRecipe(recipe: Recipe)
    suspend fun removeSavedRecipe(id: String)
    suspend fun toggleFavoriteRecipe(id: String, isFavorite: Boolean)
    fun isRecipeSaved(id: String): Flow<Boolean>

    suspend fun clearAllData()
}
