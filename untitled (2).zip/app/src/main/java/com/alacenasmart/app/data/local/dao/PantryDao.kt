package com.alacenasmart.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.alacenasmart.app.data.local.entity.PantryItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PantryDao {

    @Query("SELECT * FROM pantry_items WHERE isConsumed = 0 ORDER BY expiryDateEpochDay ASC, name ASC")
    fun getAllActiveItems(): Flow<List<PantryItemEntity>>

    @Query("SELECT * FROM pantry_items WHERE isConsumed = 0 AND expiryDateEpochDay <= :maxEpochDay ORDER BY expiryDateEpochDay ASC")
    fun getExpiringItemsSync(maxEpochDay: Long): List<PantryItemEntity>

    @Query("SELECT * FROM pantry_items WHERE isConsumed = 0 AND expiryDateEpochDay <= :maxEpochDay ORDER BY expiryDateEpochDay ASC")
    fun getExpiringItems(maxEpochDay: Long): Flow<List<PantryItemEntity>>

    @Query("SELECT * FROM pantry_items WHERE id = :id LIMIT 1")
    suspend fun getItemById(id: Long): PantryItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: PantryItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(items: List<PantryItemEntity>): List<Long>

    @Update
    suspend fun updateItem(item: PantryItemEntity)

    @Delete
    suspend fun deleteItem(item: PantryItemEntity)

    @Query("DELETE FROM pantry_items WHERE id = :id")
    suspend fun deleteItemById(id: Long)

    @Query("UPDATE pantry_items SET isConsumed = :isConsumed WHERE id = :id")
    suspend fun setConsumed(id: Long, isConsumed: Boolean)

    @Query("SELECT COUNT(*) FROM pantry_items WHERE isConsumed = 0")
    fun getActiveCount(): Flow<Int>

    @Query("DELETE FROM pantry_items")
    suspend fun clearAll()
}
