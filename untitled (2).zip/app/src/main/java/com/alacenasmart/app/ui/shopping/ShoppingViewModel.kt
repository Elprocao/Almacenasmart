package com.alacenasmart.app.ui.shopping

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alacenasmart.app.data.local.entity.ShoppingItemEntity
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.domain.repository.PantryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

data class ShoppingUiState(
    val items: List<ShoppingItemEntity> = emptyList(),
    val totalCount: Int = 0,
    val checkedCount: Int = 0,
    val isAddDialogOpen: Boolean = false,
    val isInShoppingMode: Boolean = false,
    val snackbarMessage: String? = null
)

class ShoppingViewModel(
    private val repository: PantryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ShoppingUiState())
    val uiState: StateFlow<ShoppingUiState> = _uiState.asStateFlow()

    init {
        loadItems()
    }

    private fun loadItems() {
        viewModelScope.launch {
            repository.getShoppingItems().collect { list ->
                val checked = list.count { it.isChecked }
                _uiState.update {
                    it.copy(
                        items = list,
                        totalCount = list.size,
                        checkedCount = checked
                    )
                }
            }
        }
    }

    fun openAddDialog() {
        _uiState.update { it.copy(isAddDialogOpen = true) }
    }

    fun closeAddDialog() {
        _uiState.update { it.copy(isAddDialogOpen = false) }
    }

    fun addItem(name: String, category: String, quantity: Int, imageUrl: String? = null) {
        viewModelScope.launch {
            repository.addShoppingItem(
                name = name,
                category = category,
                quantity = quantity,
                imageUrl = imageUrl
            )
            closeAddDialog()
            _uiState.update { it.copy(snackbarMessage = "Añadido: $name") }
        }
    }

    fun toggleItem(item: ShoppingItemEntity) {
        viewModelScope.launch {
            repository.toggleShoppingItem(item.id, !item.isChecked)
        }
    }

    fun deleteItem(item: ShoppingItemEntity) {
        viewModelScope.launch {
            repository.deleteShoppingItem(item.id)
            _uiState.update { it.copy(snackbarMessage = "Eliminado: ${item.name}") }
        }
    }

    fun clearChecked() {
        viewModelScope.launch {
            repository.clearCheckedShoppingItems()
            _uiState.update { it.copy(snackbarMessage = "Comprados eliminados de la lista") }
        }
    }

    fun startShoppingMode() {
        _uiState.update { it.copy(isInShoppingMode = true) }
    }

    fun exitShoppingMode() {
        _uiState.update { it.copy(isInShoppingMode = false) }
    }

    fun finishShoppingAndAddToPantry() {
        viewModelScope.launch {
            val boughtItems = _uiState.value.items.filter { it.isChecked }
            if (boughtItems.isNotEmpty()) {
                val todayEpoch = LocalDate.now().toEpochDay()
                val defaultExpiryEpoch = todayEpoch + 7 // 1 week default

                boughtItems.forEach { bought ->
                    repository.addPantryItem(
                        name = bought.name,
                        barcode = null,
                        category = bought.category,
                        storageLocation = StorageLocation.DESPENSA,
                        expiryDateEpochDay = defaultExpiryEpoch,
                        quantity = bought.quantity,
                        unit = "uds",
                        imageUrl = bought.imageUrl,
                        caloriesKcal = null,
                        proteinGrams = null,
                        carbsGrams = null,
                        fatGrams = null,
                        sugarGrams = null,
                        saltGrams = null
                    )
                }
                repository.clearCheckedShoppingItems()
                _uiState.update {
                    it.copy(
                        isInShoppingMode = false,
                        snackbarMessage = "¡${boughtItems.size} alimentos añadidos a tu despensa!"
                    )
                }
            } else {
                _uiState.update { it.copy(isInShoppingMode = false) }
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
