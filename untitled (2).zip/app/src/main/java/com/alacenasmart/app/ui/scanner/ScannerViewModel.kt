package com.alacenasmart.app.ui.scanner

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alacenasmart.app.billing.BillingHelper
import com.alacenasmart.app.data.remote.DetectedProduct
import com.alacenasmart.app.data.remote.GeminiVisionService
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.domain.repository.PantryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID

data class StagedPhoto(
    val id: String = UUID.randomUUID().toString(),
    val bitmap: Bitmap,
    val name: String,
    val timestamp: String
)

data class ScannedProductDraft(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String,
    val storageLocation: StorageLocation,
    val quantity: Int = 1,
    val unit: String = "uds",
    val expiryDateEpochDay: Long? = null,
    val imageUrl: String? = null,
    val caloriesKcal: Int? = null,
    val proteinGrams: Float? = null,
    val carbsGrams: Float? = null,
    val fatGrams: Float? = null,
    val sugarGrams: Float? = null,
    val saltGrams: Float? = null
)

data class ScannerUiState(
    val isAnalyzing: Boolean = false,
    val analysisStatusText: String? = null,
    val stagedPhotos: List<StagedPhoto> = emptyList(),
    val previewingPhoto: StagedPhoto? = null,
    val scannedDrafts: List<ScannedProductDraft> = emptyList(),
    val editingDraft: ScannedProductDraft? = null,
    val selectedLocationFilter: StorageLocation? = null,
    val errorMessage: String? = null,
    val successMessage: String? = null,
    val isPro: Boolean = false
)

class ScannerViewModel(
    private val repository: PantryRepository,
    private val billingHelper: BillingHelper
) : ViewModel() {

    private val _uiState = MutableStateFlow(ScannerUiState())
    val uiState: StateFlow<ScannerUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            billingHelper.isPro.collect { pro ->
                _uiState.update { it.copy(isPro = pro) }
            }
        }
    }

    fun setLocationFilter(location: StorageLocation?) {
        _uiState.update { it.copy(selectedLocationFilter = location) }
    }

    fun addStagedPhoto(bitmap: Bitmap) {
        val current = _uiState.value.stagedPhotos
        val index = current.size + 1
        val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
        val dateStamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH.mm.ss"))
        val staged = StagedPhoto(
            bitmap = bitmap,
            name = "$dateStamp.png",
            timestamp = java.time.LocalTime.now().format(timeFormatter)
        )
        _uiState.update {
            it.copy(
                stagedPhotos = it.stagedPhotos + staged,
                errorMessage = null
            )
        }
    }

    fun addStagedPhotos(bitmaps: List<Bitmap>) {
        if (bitmaps.isEmpty()) return
        val current = _uiState.value.stagedPhotos
        val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
        val newStaged = bitmaps.mapIndexed { i, bmp ->
            val dateStamp = LocalDateTime.now().plusSeconds(i.toLong()).format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH.mm.ss"))
            StagedPhoto(
                bitmap = bmp,
                name = "$dateStamp.png",
                timestamp = java.time.LocalTime.now().format(timeFormatter)
            )
        }
        _uiState.update {
            it.copy(
                stagedPhotos = it.stagedPhotos + newStaged,
                errorMessage = null
            )
        }
    }

    fun removeStagedPhoto(id: String) {
        _uiState.update { state ->
            val updated = state.stagedPhotos.filterNot { it.id == id }
            state.copy(
                stagedPhotos = updated,
                previewingPhoto = if (state.previewingPhoto?.id == id) null else state.previewingPhoto
            )
        }
    }

    fun setPreviewingPhoto(photo: StagedPhoto?) {
        _uiState.update { it.copy(previewingPhoto = photo) }
    }

    fun clearStagedPhotos() {
        _uiState.update { it.copy(stagedPhotos = emptyList(), previewingPhoto = null) }
    }

    fun analyzeStagedPhotos() {
        val staged = _uiState.value.stagedPhotos
        if (staged.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Saca al menos una foto para analizar.") }
            return
        }
        val bitmaps = staged.map { it.bitmap }
        onAnalyzeBitmaps(bitmaps)
    }

    fun onAnalyzeBitmaps(bitmaps: List<Bitmap>) {
        if (bitmaps.isEmpty()) return

        val countText = if (bitmaps.size == 1) "1 foto" else "${bitmaps.size} fotos"
        _uiState.update {
            it.copy(
                isAnalyzing = true,
                analysisStatusText = "Analizando $countText con IA Gemini 3.6 Flash...",
                errorMessage = null,
                successMessage = null
            )
        }

        viewModelScope.launch {
            try {
                val result = GeminiVisionService.detectProductsFromBitmaps(bitmaps)
                result.fold(
                    onSuccess = { detectedList ->
                        val currentDrafts = _uiState.value.scannedDrafts.toMutableList()

                        // Convert detected to drafts and merge by normalized name (summing quantities)
                        for (detected in detectedList) {
                            val normName = detected.productName.trim().lowercase()
                            val existingIndex = currentDrafts.indexOfFirst {
                                it.name.trim().lowercase() == normName
                            }

                            if (existingIndex >= 0) {
                                val existing = currentDrafts[existingIndex]
                                val summedQty = existing.quantity + detected.quantity
                                val earliestExpiry = when {
                                    existing.expiryDateEpochDay == null -> detected.expiryDateEpochDay
                                    detected.expiryDateEpochDay == null -> existing.expiryDateEpochDay
                                    else -> minOf(existing.expiryDateEpochDay, detected.expiryDateEpochDay)
                                }

                                currentDrafts[existingIndex] = existing.copy(
                                    quantity = summedQty,
                                    expiryDateEpochDay = earliestExpiry,
                                    caloriesKcal = existing.caloriesKcal ?: detected.caloriesKcal,
                                    proteinGrams = existing.proteinGrams ?: detected.proteinGrams,
                                    carbsGrams = existing.carbsGrams ?: detected.carbsGrams,
                                    fatGrams = existing.fatGrams ?: detected.fatGrams,
                                    sugarGrams = existing.sugarGrams ?: detected.sugarGrams,
                                    saltGrams = existing.saltGrams ?: detected.saltGrams
                                )
                            } else {
                                val photoUrl = com.alacenasmart.app.data.remote.GeminiProductMatcherService.resolvePhotoUrl(detected.productName)
                                currentDrafts.add(
                                    ScannedProductDraft(
                                        name = detected.productName,
                                        category = detected.category,
                                        storageLocation = detected.storageLocation,
                                        quantity = detected.quantity,
                                        unit = "uds",
                                        expiryDateEpochDay = detected.expiryDateEpochDay,
                                        imageUrl = photoUrl,
                                        caloriesKcal = detected.caloriesKcal,
                                        proteinGrams = detected.proteinGrams,
                                        carbsGrams = detected.carbsGrams,
                                        fatGrams = detected.fatGrams,
                                        sugarGrams = detected.sugarGrams,
                                        saltGrams = detected.saltGrams
                                    )
                                )
                            }
                        }

                        _uiState.update {
                            it.copy(
                                isAnalyzing = false,
                                analysisStatusText = null,
                                stagedPhotos = emptyList(),
                                previewingPhoto = null,
                                scannedDrafts = currentDrafts,
                                successMessage = if (bitmaps.size > 1) {
                                    "Se analizaron ${bitmaps.size} fotos y se agruparon las cantidades detectadas."
                                } else {
                                    "Alimentos reconocidos con éxito por la cámara IA."
                                }
                            )
                        }
                    },
                    onFailure = { error ->
                        _uiState.update {
                            it.copy(
                                isAnalyzing = false,
                                analysisStatusText = null,
                                errorMessage = error.localizedMessage ?: "No se pudieron reconocer los alimentos."
                            )
                        }
                    }
                )
            } catch (e: Throwable) {
                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        analysisStatusText = null,
                        errorMessage = "Error inesperado al procesar fotos: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun startEditingDraft(draft: ScannedProductDraft) {
        _uiState.update { it.copy(editingDraft = draft) }
    }

    fun dismissEditingDraft() {
        _uiState.update { it.copy(editingDraft = null) }
    }

    fun saveEditedDraft(updated: ScannedProductDraft) {
        _uiState.update { state ->
            val updatedList = state.scannedDrafts.map {
                if (it.id == updated.id) updated else it
            }
            state.copy(scannedDrafts = updatedList, editingDraft = null)
        }
    }

    fun updateQuantity(draftId: String, delta: Int) {
        _uiState.update { state ->
            val updated = state.scannedDrafts.mapNotNull { item ->
                if (item.id == draftId) {
                    val newQty = item.quantity + delta
                    if (newQty <= 0) null else item.copy(quantity = newQty)
                } else {
                    item
                }
            }
            state.copy(scannedDrafts = updated)
        }
    }

    fun removeDraft(draftId: String) {
        _uiState.update { state ->
            state.copy(scannedDrafts = state.scannedDrafts.filterNot { it.id == draftId })
        }
    }

    fun confirmAddSingleDraft(draft: ScannedProductDraft) {
        viewModelScope.launch {
            val photoUrl = draft.imageUrl ?: com.alacenasmart.app.data.remote.GeminiProductMatcherService.resolvePhotoUrl(draft.name)
            repository.addPantryItem(
                name = draft.name,
                barcode = null,
                category = draft.category,
                storageLocation = draft.storageLocation,
                expiryDateEpochDay = draft.expiryDateEpochDay,
                quantity = draft.quantity,
                unit = draft.unit,
                imageUrl = photoUrl,
                caloriesKcal = draft.caloriesKcal,
                proteinGrams = draft.proteinGrams,
                carbsGrams = draft.carbsGrams,
                fatGrams = draft.fatGrams,
                sugarGrams = draft.sugarGrams,
                saltGrams = draft.saltGrams
            )
            _uiState.update { state ->
                state.copy(
                    scannedDrafts = state.scannedDrafts.filterNot { it.id == draft.id },
                    successMessage = "¡Guardado '${draft.name}' en ${draft.storageLocation.displayName}!"
                )
            }
        }
    }

    fun confirmAddAllToPantry() {
        val drafts = _uiState.value.scannedDrafts
        if (drafts.isEmpty()) return

        viewModelScope.launch {
            for (draft in drafts) {
                val photoUrl = draft.imageUrl ?: com.alacenasmart.app.data.remote.GeminiProductMatcherService.resolvePhotoUrl(draft.name)
                repository.addPantryItem(
                    name = draft.name,
                    barcode = null,
                    category = draft.category,
                    storageLocation = draft.storageLocation,
                    expiryDateEpochDay = draft.expiryDateEpochDay,
                    quantity = draft.quantity,
                    unit = draft.unit,
                    imageUrl = photoUrl,
                    caloriesKcal = draft.caloriesKcal,
                    proteinGrams = draft.proteinGrams,
                    carbsGrams = draft.carbsGrams,
                    fatGrams = draft.fatGrams,
                    sugarGrams = draft.sugarGrams,
                    saltGrams = draft.saltGrams
                )
            }

            _uiState.update {
                it.copy(
                    scannedDrafts = emptyList(),
                    successMessage = "¡Se han guardado ${drafts.size} productos en su despensa por sección!"
                )
            }
        }
    }

    fun clearAllDrafts() {
        _uiState.update {
            it.copy(
                scannedDrafts = emptyList(),
                editingDraft = null,
                errorMessage = null
            )
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(errorMessage = null, successMessage = null) }
    }
}
