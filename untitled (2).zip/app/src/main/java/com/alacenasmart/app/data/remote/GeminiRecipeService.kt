package com.alacenasmart.app.data.remote

import com.alacenasmart.app.BuildConfig
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.Recipe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

object GeminiRecipeService {

    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun generate5RecipesFromPantry(
        pantryItems: List<PantryItem>,
        dietaryPreference: com.alacenasmart.app.domain.model.DietaryPreference = com.alacenasmart.app.domain.model.DietaryPreference.ALL,
        customPrompt: String = "",
        maxTimeMinutes: Int? = null
    ): Result<List<Recipe>> = withContext(Dispatchers.IO) {
        if (pantryItems.isEmpty()) {
            return@withContext Result.success(emptyList())
        }

        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                IllegalStateException("Se requiere configurar la clave de API de Gemini en Ajustes.")
            )
        }

        try {
            val ingredientsAvailableStr = pantryItems.joinToString(", ") {
                val expiringTag = if (it.expiryStatus.daysRemaining in 0..2) " [¡CADUCA EN ${it.expiryStatus.daysRemaining} DÍAS! PRIORIDAD DE APROVECHAMIENTO]" else ""
                "${it.name} (${it.quantity} ${it.unit})$expiringTag"
            }

            val preferencePrompt = if (dietaryPreference != com.alacenasmart.app.domain.model.DietaryPreference.ALL) {
                "\nPREFERENCIA DIETÉTICA / FILTRO SELECCIONADO POR EL USUARIO:\n- ${dietaryPreference.label}: ${dietaryPreference.promptInstruction}\n"
            } else ""

            val customPromptSection = if (customPrompt.isNotBlank()) {
                "\nESPECIFICACIONES / INSTRUCCIONES ESPECÍFICAS INDICADAS POR EL USUARIO PARA REGENERAR:\n\"$customPrompt\"\nDebes priorizar y cumplir estas especificaciones estrictamente manteniendo el uso de los ingredientes de la despensa.\n"
            } else ""

            val maxTimeSection = if (maxTimeMinutes != null && maxTimeMinutes > 0) {
                "\nTIEMPO MÁXIMO TOTAL DE PREPARACIÓN PERMITIDO: $maxTimeMinutes minutos.\n"
            } else ""

            val systemPrompt = """
                Eres un Chef profesional y nutricionista de alta cocina.
                Tu tarea es generar EXACTAMENTE 5 recetas completas, deliciosas y viables que el usuario PUEDA COCINAR al 100% utilizando los ingredientes que tiene en su despensa (puedes asumir básicos comunes de cocina como agua o pizca de sal, pero los ingredientes principales deben provenir de su despensa).
                $preferencePrompt
                $customPromptSection
                $maxTimeSection
                Requisitos estrictos para CADA receta:
                1. Solo recetas que se puedan hacer con lo disponible en la despensa del usuario.
                2. Número de raciones exacto (servings: entero, ej 2 o 4).
                3. Medidas exactas en los ingredientes: indicar siempre gramos (g), mililitros (ml), litros (l), cucharadas o unidades (ej: "250 g de pechuga de pollo cortada en tiras", "150 ml de leche", "2 unidades de huevo batido").
                4. Preparación detallada paso a paso: especificar tiempos precisos de cocción, temperaturas recomendadas (ej: "Horno precalentado a 180 °C", "Fuego medio-alto a 120 °C"), y tiempos de reposo si aplica.
                5. restTimeMinutes: minutos de reposo necesarios (0 si no necesita).
                6. cookingTemp: temperatura o intensidad (ej: "180 °C (Horno)", "Fuego medio-alto (130 °C)", "Sin cocción").
                7. Información nutricional calculada por ración:
                   - caloriesKcal (entero)
                   - proteinGrams (float)
                   - carbsGrams (float)
                   - fatGrams (float)
                   - sugarGrams (float)
                   - saltGrams (float)

                Responde ÚNICAMENTE con un JSON con la clave "recipes" y una lista de 5 objetos con esta estructura exacta:
                {
                  "recipes": [
                    {
                      "title": "Nombre de la receta",
                      "description": "Breve descripción apetecible",
                      "category": "Almuerzo | Cena | Desayuno | Postre | Snack",
                      "difficulty": "Fácil | Media | Difícil",
                      "prepTimeMinutes": 25,
                      "servings": 2,
                      "restTimeMinutes": 5,
                      "cookingTemp": "Fuego medio (120 °C)",
                      "requiredIngredients": [
                        "200 g de pechuga de pollo",
                        "1 pizca de sal (2 g)"
                      ],
                      "steps": [
                        "Paso 1: Cortar...",
                        "Paso 2: Calentar la sartén a fuego medio...",
                        "Paso 3: Dejar reposar 5 minutos..."
                      ],
                      "caloriesKcal": 320,
                      "proteinGrams": 32.5,
                      "carbsGrams": 4.0,
                      "fatGrams": 12.0,
                      "sugarGrams": 1.2,
                      "saltGrams": 1.1
                    }
                  ]
                }
            """.trimIndent()

            val userMessage = buildString {
                append("Ingredientes actualmente disponibles en mi despensa: $ingredientsAvailableStr.")
                if (customPrompt.isNotBlank()) {
                    append(" Especificaciones para regenerar: $customPrompt.")
                }
                append(" Por favor genera 5 recetas que pueda cocinar ahora mismo teniendo en cuenta mis preferencias.")
            }

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray()
                val contentObj = JSONObject().apply {
                    val partsArray = JSONArray()
                    partsArray.put(JSONObject().apply { put("text", userMessage) })
                    put("parts", partsArray)
                }
                contentsArray.put(contentObj)
                put("contents", contentsArray)

                val sysInstruction = JSONObject().apply {
                    val parts = JSONArray()
                    parts.put(JSONObject().apply { put("text", systemPrompt) })
                    put("parts", parts)
                }
                put("systemInstruction", sysInstruction)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.4)
                    put("responseMimeType", "application/json")
                }
                put("generationConfig", genConfig)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val url = "$BASE_URL?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKey)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("Error de Gemini (${response.code}) al generar recetas"))
            }

            val responseBody = response.body?.string() ?: throw IllegalStateException("Respuesta vacía de Gemini")
            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates") ?: return@withContext Result.failure(Exception("Sin candidatos de recetas"))
            val firstCandidate = candidates.getJSONObject(0)
            val parts = firstCandidate.optJSONObject("content")?.optJSONArray("parts")
            val text = parts?.getJSONObject(0)?.optString("text") ?: "{}"
            val cleanJson = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()

            val parsed = JSONObject(cleanJson)
            val recipesArray = parsed.optJSONArray("recipes") ?: JSONArray()
            val list = mutableListOf<Recipe>()

            val availableNames = pantryItems.map { it.name.lowercase().trim() }

            for (i in 0 until recipesArray.length()) {
                val item = recipesArray.getJSONObject(i)
                val reqIng = mutableListOf<String>()
                val reqArray = item.optJSONArray("requiredIngredients")
                if (reqArray != null) {
                    for (j in 0 until reqArray.length()) {
                        reqIng.add(reqArray.getString(j))
                    }
                }
                val stepsList = mutableListOf<String>()
                val stepsArray = item.optJSONArray("steps")
                if (stepsArray != null) {
                    for (j in 0 until stepsArray.length()) {
                        stepsList.add(stepsArray.getString(j))
                    }
                }

                // Since Gemini was told to only use available ingredients, match them
                val matched = reqIng.filter { ing ->
                    val lower = ing.lowercase()
                    availableNames.any { lower.contains(it) || it.contains(lower) }
                }

                list.add(
                    Recipe(
                        id = "ai_${UUID.randomUUID()}",
                        title = item.optString("title", "Receta de chef").trim(),
                        description = item.optString("description", "").trim(),
                        category = item.optString("category", "Almuerzo").trim(),
                        difficulty = item.optString("difficulty", "Fácil").trim(),
                        prepTimeMinutes = item.optInt("prepTimeMinutes", 20).coerceAtLeast(5),
                        servings = item.optInt("servings", 2).coerceAtLeast(1),
                        restTimeMinutes = item.optInt("restTimeMinutes", 0),
                        cookingTemp = item.optString("cookingTemp", "Fuego medio"),
                        requiredIngredients = reqIng,
                        availableIngredients = if (matched.isNotEmpty()) matched else reqIng,
                        missingIngredients = emptyList(), // Strictly cookable
                        steps = stepsList,
                        caloriesKcal = item.optInt("caloriesKcal", 350),
                        proteinGrams = item.optDouble("proteinGrams", 15.0).toFloat(),
                        carbsGrams = item.optDouble("carbsGrams", 30.0).toFloat(),
                        fatGrams = item.optDouble("fatGrams", 10.0).toFloat(),
                        sugarGrams = item.optDouble("sugarGrams", 3.0).toFloat(),
                        saltGrams = item.optDouble("saltGrams", 1.0).toFloat()
                    )
                )
            }

            Result.success(list.take(5))
        } catch (e: Exception) {
            val fallback = generateIntelligentFallbackRecipes(pantryItems, dietaryPreference, customPrompt)
            if (fallback.isNotEmpty()) {
                Result.success(fallback)
            } else {
                Result.failure(e)
            }
        }
    }

    suspend fun generateRecipes(
        pantryItems: List<PantryItem>,
        dietaryPreferences: List<com.alacenasmart.app.domain.model.DietaryPreference> = emptyList(),
        maxTimeMinutes: Int? = null,
        customPrompt: String = ""
    ): List<Recipe> {
        val pref = dietaryPreferences.firstOrNull() ?: com.alacenasmart.app.domain.model.DietaryPreference.ALL
        val result = generate5RecipesFromPantry(
            pantryItems = pantryItems,
            dietaryPreference = pref,
            customPrompt = customPrompt,
            maxTimeMinutes = maxTimeMinutes
        ).getOrNull()
        return if (!result.isNullOrEmpty()) result else generateIntelligentFallbackRecipes(pantryItems, pref, customPrompt)
    }

    private fun generateIntelligentFallbackRecipes(
        pantryItems: List<PantryItem>,
        pref: com.alacenasmart.app.domain.model.DietaryPreference,
        prompt: String
    ): List<Recipe> {
        if (pantryItems.isEmpty()) return emptyList()

        val names = pantryItems.map { it.name }
        val primary = names.getOrNull(0) ?: "Ingrediente"
        val secondary = names.getOrNull(1) ?: "básicos de cocina"
        val third = names.getOrNull(2) ?: "aceite de oliva"

        return listOf(
            Recipe(
                id = "local_1",
                title = "Salteado rápido de $primary con $secondary",
                description = "Una combinación sabrosa y saludable lista en pocos minutos, optimizada para aprovechar lo que tienes a mano.",
                category = "Almuerzo",
                difficulty = "Fácil",
                prepTimeMinutes = 15,
                servings = 2,
                restTimeMinutes = 2,
                cookingTemp = "Fuego medio-alto (130 °C)",
                requiredIngredients = listOf(
                    "200 g de $primary",
                    "150 g de $secondary",
                    "1 cucharada de aceite de oliva (15 ml)",
                    "Una pizca de sal y pimienta al gusto"
                ),
                availableIngredients = listOf(primary, secondary),
                missingIngredients = emptyList(),
                steps = listOf(
                    "Lavar y cortar $primary y $secondary en trozos homogéneos de bocado.",
                    "Calentar una sartén a fuego medio-alto con la cucharada de aceite de oliva.",
                    "Añadir $primary y dorar durante 4 minutos removiendo suavemente.",
                    "Incorporar $secondary, sazonar con la sal y pimienta, y saltear 5 minutos más hasta que todo esté tierno.",
                    "Retirar del fuego, dejar reposar 2 minutos y servir caliente."
                ),
                caloriesKcal = 310,
                proteinGrams = 18f,
                carbsGrams = 12f,
                fatGrams = 14f,
                sugarGrams = 2f,
                saltGrams = 1f
            ),
            Recipe(
                id = "local_2",
                title = "Revuelto casero de $primary",
                description = "Cremoso revuelto reconfortante preparado a fuego lento para mantener la máxima jugosidad.",
                category = "Cena",
                difficulty = "Fácil",
                prepTimeMinutes = 12,
                servings = 2,
                restTimeMinutes = 1,
                cookingTemp = "Fuego bajo (100 °C)",
                requiredIngredients = listOf(
                    "150 g de $primary picado",
                    "2 huevos o equivalente",
                    "50 g de $secondary",
                    "1 cucharadita de aceite de oliva (5 ml)"
                ),
                availableIngredients = listOf(primary, secondary),
                missingIngredients = emptyList(),
                steps = listOf(
                    "Picar finamente $primary.",
                    "En un bol pequeño, batir ligeramente los huevos con una pizca de sal.",
                    "Saltear $primary durante 3 minutos en una sartén antiadherente.",
                    "Bajar el fuego al mínimo, verter los huevos batidos y remover despacio con espátula durante 3-4 minutos hasta que cuajen cremosos.",
                    "Espolvorear con $secondary picado y retirar inmediatamente para que no se seque."
                ),
                caloriesKcal = 280,
                proteinGrams = 20f,
                carbsGrams = 5f,
                fatGrams = 16f,
                sugarGrams = 1f,
                saltGrams = 1f
            ),
            Recipe(
                id = "local_3",
                title = "Ensalada templada de $primary y $third",
                description = "Plato fresco y saciante que combina texturas crujientes con ingredientes de tu despensa.",
                category = "Almuerzo",
                difficulty = "Fácil",
                prepTimeMinutes = 10,
                servings = 2,
                restTimeMinutes = 0,
                cookingTemp = "Sin cocción o marcado rápido",
                requiredIngredients = listOf(
                    "180 g de $primary cortado fino",
                    "80 g de $third",
                    "Vinagre o limón (10 ml)",
                    "Aceite de oliva virgen extra (15 ml)"
                ),
                availableIngredients = listOf(primary, third),
                missingIngredients = emptyList(),
                steps = listOf(
                    "Cortar $primary en rodajas o dados según su textura.",
                    "Disponer en una fuente amplia junto con $third.",
                    "Emulsionar en un vasito el aceite con el limón o vinagre y una pizca de sal.",
                    "Verter el aliño por encima justo antes de servir y mezclar con suavidad."
                ),
                caloriesKcal = 240,
                proteinGrams = 8f,
                carbsGrams = 16f,
                fatGrams = 12f,
                sugarGrams = 3f,
                saltGrams = 0.8f
            ),
            Recipe(
                id = "local_4",
                title = "Guiso exprés de $primary a la cazuela",
                description = "Un fondo aromático lleno de sabor para disfrutar de una comida completa y reconfortante.",
                category = "Almuerzo",
                difficulty = "Media",
                prepTimeMinutes = 25,
                servings = 3,
                restTimeMinutes = 5,
                cookingTemp = "Fuego medio (110 °C)",
                requiredIngredients = listOf(
                    "250 g de $primary",
                    "120 g de $secondary",
                    "100 g de $third",
                    "200 ml de agua o caldo"
                ),
                availableIngredients = listOf(primary, secondary, third),
                missingIngredients = emptyList(),
                steps = listOf(
                    "Dorar $primary en una cazuela con unas gotas de aceite durante 5 minutos.",
                    "Añadir $secondary y $third troceados, salteando 3 minutos más.",
                    "Verter el agua o caldo, tapar la cazuela y cocinar a fuego suave 15 minutos.",
                    "Ajustar de sal, apagar el fuego y dejar asentar tapado 5 minutos antes de degustar."
                ),
                caloriesKcal = 350,
                proteinGrams = 22f,
                carbsGrams = 28f,
                fatGrams = 10f,
                sugarGrams = 4f,
                saltGrams = 1.2f
            ),
            Recipe(
                id = "local_5",
                title = "Tostas crujientes de $primary con toque de $secondary",
                description = "Ideal para una cena ligera o desayuno potente con lo mejor de tu despensa.",
                category = "Cena",
                difficulty = "Fácil",
                prepTimeMinutes = 10,
                servings = 2,
                restTimeMinutes = 0,
                cookingTemp = "Tostado medio (160 °C)",
                requiredIngredients = listOf(
                    "120 g de $primary preparado",
                    "50 g de $secondary",
                    "2 rebanadas de pan o base tostada",
                    "Un chorrito de aceite de oliva"
                ),
                availableIngredients = listOf(primary, secondary),
                missingIngredients = emptyList(),
                steps = listOf(
                    "Tostar el pan en sartén o tostadora hasta que quede dorado y crujiente.",
                    "Rociar un hilo fino de aceite de oliva virgen sobre el pan caliente.",
                    "Colocar por encima $primary previamente laminado o templado.",
                    "Coronar con $secondary y un toque de orégano o pimienta.",
                    "Servir inmediatamente para disfrutar del contraste crujiente."
                ),
                caloriesKcal = 290,
                proteinGrams = 14f,
                carbsGrams = 32f,
                fatGrams = 9f,
                sugarGrams = 2f,
                saltGrams = 0.9f
            )
        )
    }
}
