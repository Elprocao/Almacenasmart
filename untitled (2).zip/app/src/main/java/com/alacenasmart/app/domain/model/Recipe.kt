package com.alacenasmart.app.domain.model

data class Recipe(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val difficulty: String,
    val prepTimeMinutes: Int,
    val servings: Int = 2,
    val restTimeMinutes: Int = 0,
    val cookingTemp: String? = null,
    val requiredIngredients: List<String>,
    val availableIngredients: List<String> = emptyList(),
    val missingIngredients: List<String> = emptyList(),
    val expiringIngredients: List<String> = emptyList(),
    val steps: List<String> = emptyList(),
    val caloriesKcal: Int = 0,
    val proteinGrams: Float = 0f,
    val carbsGrams: Float = 0f,
    val fatGrams: Float = 0f,
    val sugarGrams: Float = 0f,
    val saltGrams: Float = 0f,
    val isSaved: Boolean = false,
    val isFavorite: Boolean = false
) {
    val matchPercentage: Int
        get() = if (requiredIngredients.isEmpty()) 0
        else ((availableIngredients.size.toDouble() / requiredIngredients.size.toDouble()) * 100).toInt()
}
