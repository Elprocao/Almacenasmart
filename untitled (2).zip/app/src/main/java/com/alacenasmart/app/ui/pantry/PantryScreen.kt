package com.alacenasmart.app.ui.pantry

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.launch
import com.alacenasmart.app.domain.model.ExpiryStatus
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.ui.components.SmartProductAddDialog
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantryScreen(
    viewModel: PantryViewModel,
    onNavigateToScanner: () -> Unit,
    onNavigateToRecipes: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showExportOptionsDialog by remember { mutableStateOf(false) }

    // TXT File Saver for Export
    val exportFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val txtData = viewModel.exportPantryTxt()
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(txtData.toByteArray(Charsets.UTF_8))
                    }
                    snackbarHostState.showSnackbar("¡Despensa exportada con éxito en el archivo TXT!")
                } catch (e: Exception) {
                    snackbarHostState.showSnackbar("Error al guardar archivo: ${e.localizedMessage}")
                }
            }
        }
    }

    // TXT File Picker for Import
    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val content = inputStream?.bufferedReader()?.use { it.readText() } ?: ""
                    viewModel.importPantryTxt(content) { success, msg ->
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(msg)
                        }
                    }
                } catch (e: Exception) {
                    snackbarHostState.showSnackbar("Error al leer archivo: ${e.localizedMessage}")
                }
            }
        }
    }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Scanner FAB
                FloatingActionButton(
                    onClick = onNavigateToScanner,
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.testTag("fab_scan_barcode")
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = "Escanear alimento")
                }

                // Add Item FAB
                FloatingActionButton(
                    onClick = { viewModel.openAddDialog() },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("fab_add_pantry_item")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Añadir alimento")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Header: Title & Export/Import Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Mi Despensa",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Export TXT Button
                    OutlinedButton(
                        onClick = {
                            if (uiState.items.isEmpty()) {
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Tu despensa está vacía. Añade alimentos para exportar.")
                                }
                            } else {
                                showExportOptionsDialog = true
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_pantry_export_txt")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Exportar TXT", style = MaterialTheme.typography.labelMedium)
                    }

                    // Import TXT Button
                    FilledTonalButton(
                        onClick = {
                            importFileLauncher.launch("text/*")
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_pantry_import_txt")
                    ) {
                        Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Importar TXT", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }

            // Header Search & Filter Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.onSearchQueryChanged(it) },
                    placeholder = { Text("Buscar en mi despensa...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Limpiar")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_pantry_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Storage location filters
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = uiState.selectedLocation == null,
                            onClick = { viewModel.onLocationSelected(null) },
                            label = { Text("Todos (${uiState.items.size})") },
                            modifier = Modifier.testTag("chip_filter_all")
                        )
                    }
                    items(StorageLocation.entries.toTypedArray()) { loc ->
                        val count = uiState.items.count { it.storageLocation == loc }
                        FilterChip(
                            selected = uiState.selectedLocation == loc,
                            onClick = { viewModel.onLocationSelected(loc) },
                            label = { Text("${loc.displayName} ($count)") },
                            modifier = Modifier.testTag("chip_filter_${loc.name.lowercase()}")
                        )
                    }
                }
            }

            // Expiry Alert Banner
            if (uiState.expiringSoonCount > 0 || uiState.expiredCount > 0) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (uiState.expiredCount > 0) Color(0xFFFFEBEE) else Color(0xFFFFF8E1)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (uiState.expiredCount > 0) Icons.Default.Warning else Icons.Default.NotificationsActive,
                                contentDescription = null,
                                tint = if (uiState.expiredCount > 0) Color(0xFFC62828) else Color(0xFFF57F17),
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                val text = buildString {
                                    if (uiState.expiredCount > 0) append("${uiState.expiredCount} caducados ")
                                    if (uiState.expiringSoonCount > 0) append("${uiState.expiringSoonCount} por caducar")
                                }
                                Text(
                                    text = text,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF212121)
                                )
                                Text(
                                    text = "¡Aprovéchalos antes de que se echen a perder!",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF616161)
                                )
                            }
                        }

                        Button(
                            onClick = onNavigateToRecipes,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.RestaurantMenu, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cocinar", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }

            // Items List
            if (uiState.filteredItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Kitchen,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outlineVariant,
                            modifier = Modifier.size(80.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (uiState.searchQuery.isNotBlank()) "No se encontraron alimentos" else "Tu despensa está vacía",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (uiState.searchQuery.isNotBlank()) "Prueba con otra palabra" else "Toca el botón + o el escáner para añadir tus primeros productos con fotos e IA.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(uiState.filteredItems, key = { it.id }) { item ->
                        PantryItemCard(
                            item = item,
                            onClick = { viewModel.selectItem(item) },
                            onConsume = { viewModel.consumeItem(item) },
                            onAddToShopping = { viewModel.addToShoppingList(item) }
                        )
                    }
                }
            }
        }
    }

    // Add Item Dialog
    if (uiState.isAddDialogOpen) {
        SmartProductAddDialog(
            title = "Añadir a la Despensa",
            onDismiss = { viewModel.closeAddDialog() },
            onProductSelected = { option, quantity ->
                viewModel.addFromSmartMatch(option, quantity)
            }
        )
    }

    // Export Options Dialog
    if (showExportOptionsDialog) {
        AlertDialog(
            onDismissRequest = { showExportOptionsDialog = false },
            title = {
                Text("Exportar Despensa en TXT", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Se exportarán ${uiState.items.size} alimentos con todos sus datos: nutrición, enlaces a fotos de perfil, nombres, fechas de caducidad, cantidades y categorías.\n\n¿Cómo deseas exportarlo?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExportOptionsDialog = false
                        exportFileLauncher.launch("despensa_alacenasmart_${LocalDate.now()}.txt")
                    }
                ) {
                    Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Guardar archivo TXT")
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(
                        onClick = {
                            showExportOptionsDialog = false
                            val txt = viewModel.exportPantryTxt()
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, txt)
                                putExtra(Intent.EXTRA_TITLE, "despensa_alacenasmart.txt")
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Exportar despensa TXT"))
                        }
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Compartir")
                    }

                    TextButton(
                        onClick = {
                            showExportOptionsDialog = false
                            val txt = viewModel.exportPantryTxt()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            clipboard?.setPrimaryClip(ClipData.newPlainText("Despensa TXT", txt))
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Copia TXT copiada al portapapeles")
                            }
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copiar")
                    }
                }
            }
        )
    }

    // Item Detail / Edit BottomSheet
    uiState.selectedItemForDetail?.let { item ->
        ItemDetailSheet(
            item = item,
            onDismiss = { viewModel.selectItem(null) },
            onUpdate = { updated -> viewModel.updateItem(updated) },
            onDelete = { viewModel.deleteItem(item) },
            onConsume = { viewModel.consumeItem(item) },
            onAddToShopping = { viewModel.addToShoppingList(item) }
        )
    }
}

@Composable
fun PantryItemCard(
    item: PantryItem,
    onClick: () -> Unit,
    onConsume: () -> Unit,
    onAddToShopping: () -> Unit,
    modifier: Modifier = Modifier
) {
    val status = item.expiryStatus
    val badgeColor = when (status.trafficLight) {
        com.alacenasmart.app.domain.model.TrafficLightColor.RED -> Color(0xFFD32F2F)
        com.alacenasmart.app.domain.model.TrafficLightColor.YELLOW -> Color(0xFFF57C00)
        com.alacenasmart.app.domain.model.TrafficLightColor.GREEN -> Color(0xFF388E3C)
        com.alacenasmart.app.domain.model.TrafficLightColor.NEUTRAL -> Color(0xFF757575)
    }
    val badgeText = status.displayMessage

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("pantry_item_${item.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail food profile image
            val photoUrl = item.imageUrl?.takeIf { it.isNotBlank() }
                ?: com.alacenasmart.app.data.remote.GeminiProductMatcherService.resolvePhotoUrl(item.name)
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(photoUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = item.name,
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(14.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${item.category} • ${item.storageLocation.displayName} • ${item.quantity} ${item.unit}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Expiry Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = badgeText,
                        color = badgeColor,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Quick Consume Action
            IconButton(
                onClick = onConsume,
                modifier = Modifier.testTag("btn_consume_${item.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Consumir alimento",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemDetailSheet(
    item: PantryItem,
    onDismiss: () -> Unit,
    onUpdate: (PantryItem) -> Unit,
    onDelete: () -> Unit,
    onConsume: () -> Unit,
    onAddToShopping: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var quantity by remember { mutableIntStateOf(item.quantity) }
    var location by remember { mutableStateOf(item.storageLocation) }

    // Expiry date state
    var hasExpiry by remember { mutableStateOf(item.expiryDateEpochDay != null) }
    var daysFromNow by remember {
        mutableStateOf(
            if (item.expiryDateEpochDay != null) {
                maxOf(0L, item.expiryDateEpochDay - LocalDate.now().toEpochDay()).toString()
            } else "7"
        )
    }

    // Nutrition states
    var calories by remember { mutableStateOf(item.caloriesKcal?.toString() ?: "") }
    var protein by remember { mutableStateOf(item.proteinGrams?.toString() ?: "") }
    var carbs by remember { mutableStateOf(item.carbsGrams?.toString() ?: "") }
    var fat by remember { mutableStateOf(item.fatGrams?.toString() ?: "") }
    var sugar by remember { mutableStateOf(item.sugarGrams?.toString() ?: "") }
    var salt by remember { mutableStateOf(item.saltGrams?.toString() ?: "") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val detailPhotoUrl = item.imageUrl?.takeIf { it.isNotBlank() }
                        ?: com.alacenasmart.app.data.remote.GeminiProductMatcherService.resolvePhotoUrl(item.name)
                    AsyncImage(
                        model = detailPhotoUrl,
                        contentDescription = item.name,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = item.category,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val expiryDesc = if (item.expiryDateEpochDay != null) {
                            val dateStr = LocalDate.ofEpochDay(item.expiryDateEpochDay).format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
                            "Caducidad aprox: $dateStr"
                        } else {
                            "Caducidad aproximada: Sin fecha deducible"
                        }
                        Text(
                            text = expiryDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Prominent disclaimer
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E5)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFB74D))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFE65100),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Aviso: Las fechas y datos nutricionales pueden ser inexactos. Modifíquelos libremente según la etiqueta real de su producto.",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF5D4037))
                        )
                    }
                }
            }

            // Location Selector
            item {
                Text("Sección de almacenamiento:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    StorageLocation.entries.forEach { loc ->
                        FilterChip(
                            selected = location == loc,
                            onClick = { location = loc },
                            label = { Text(loc.displayName) },
                            leadingIcon = {
                                Icon(imageVector = loc.icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Quantity Control
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Cantidad:", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (quantity > 1) quantity-- }, enabled = quantity > 1) {
                            Text("-", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("$quantity ${item.unit}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { quantity++ }) {
                            Text("+", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Expiry Date Editing
            item {
                Text("Fecha de caducidad aproximada:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = hasExpiry,
                        onClick = { hasExpiry = true },
                        label = { Text("Con fecha estimada") }
                    )
                    FilterChip(
                        selected = !hasExpiry,
                        onClick = { hasExpiry = false },
                        label = { Text("Sin fecha deducible") }
                    )
                }

                if (hasExpiry) {
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = daysFromNow,
                        onValueChange = { daysFromNow = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Días hasta caducar desde hoy") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        supportingText = {
                            val d = daysFromNow.toLongOrNull() ?: 0L
                            val computed = LocalDate.now().plusDays(d)
                            Text("Fecha resultante: ${computed.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}")
                        }
                    )
                }
            }

            // Nutrition Facts Editing
            item {
                Text("Información Nutricional (por 100g / ración):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = calories,
                        onValueChange = { calories = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Calorías (kcal)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = protein,
                        onValueChange = { protein = it },
                        label = { Text("Proteínas (g)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = carbs,
                        onValueChange = { carbs = it },
                        label = { Text("Carbohidratos (g)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = fat,
                        onValueChange = { fat = it },
                        label = { Text("Grasas (g)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sugar,
                        onValueChange = { sugar = it },
                        label = { Text("Azúcares (g)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = salt,
                        onValueChange = { salt = it },
                        label = { Text("Sal (g)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }

            // Action Buttons
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        val computedEpoch = if (hasExpiry) {
                            val d = daysFromNow.toLongOrNull() ?: 7L
                            LocalDate.now().plusDays(d).toEpochDay()
                        } else null

                        val updated = item.copy(
                            quantity = quantity,
                            storageLocation = location,
                            expiryDateEpochDay = computedEpoch,
                            caloriesKcal = calories.toIntOrNull(),
                            proteinGrams = protein.replace(",", ".").toFloatOrNull(),
                            carbsGrams = carbs.replace(",", ".").toFloatOrNull(),
                            fatGrams = fat.replace(",", ".").toFloatOrNull(),
                            sugarGrams = sugar.replace(",", ".").toFloatOrNull(),
                            saltGrams = salt.replace(",", ".").toFloatOrNull()
                        )
                        onUpdate(updated)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Guardar cambios")
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onConsume,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Consumido")
                    }

                    OutlinedButton(
                        onClick = onAddToShopping,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("A la compra")
                    }
                }
            }

            item {
                OutlinedButton(
                    onClick = onDelete,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Eliminar de la despensa")
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
