package com.alacenasmart.app.ui.pantry

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alacenasmart.app.billing.BillingHelper
import com.alacenasmart.app.data.remote.ProductMatchOption
import com.alacenasmart.app.data.util.PantryTxtFormatUtil
import com.alacenasmart.app.domain.model.ExpiryStatus
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.StorageLocation
import com.alacenasmart.app.domain.repository.PantryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

data class PantryUiState(
    val items: List<PantryItem> = emptyList(),
    val filteredItems: List<PantryItem> = emptyList(),
    val expiringSoonCount: Int = 0,
    val expiredCount: Int = 0,
    val selectedLocation: StorageLocation? = null,
    val searchQuery: String = "",
    val isAddDialogOpen: Boolean = false,
    val selectedItemForDetail: PantryItem? = null,
    val snackbarMessage: String? = null,
    val isPro: Boolean = false
)

class PantryViewModel(
    private val repository: PantryRepository,
    private val billingHelper: BillingHelper
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    private val _selectedLocation = MutableStateFlow<StorageLocation?>(null)
    private val _isAddDialogOpen = MutableStateFlow(false)
    private val _selectedItemForDetail = MutableStateFlow<PantryItem?>(null)
    private val _snackbarMessage = MutableStateFlow<String?>(null)

    private data class DialogDetailState(
        val isAddOpen: Boolean,
        val detailItem: PantryItem?,
        val snackbar: String?
    )

    private val dialogDetailFlow = combine(
        _isAddDialogOpen,
        _selectedItemForDetail,
        _snackbarMessage
    ) { isAddOpen, detailItem, snackbar ->
        DialogDetailState(isAddOpen, detailItem, snackbar)
    }

    val uiState: StateFlow<PantryUiState> = combine(
        repository.getPantryItems(),
        _searchQuery,
        _selectedLocation,
        dialogDetailFlow,
        billingHelper.isPro
    ) { items, query, location, dialogDetail, isPro ->
        val filtered = items.filter { item ->
            val matchesQuery = query.isBlank() ||
                    item.name.contains(query, ignoreCase = true) ||
                    item.category.contains(query, ignoreCase = true)
            val matchesLocation = location == null || item.storageLocation == location
            matchesQuery && matchesLocation
        }

        val expiring = items.count {
            it.expiryStatus.state == com.alacenasmart.app.domain.model.ExpiryState.EXPIRING_SOON ||
            it.expiryStatus.state == com.alacenasmart.app.domain.model.ExpiryState.EXPIRES_TODAY
        }
        val expired = items.count {
            it.expiryStatus.state == com.alacenasmart.app.domain.model.ExpiryState.EXPIRED
        }

        PantryUiState(
            items = items,
            filteredItems = filtered,
            expiringSoonCount = expiring,
            expiredCount = expired,
            selectedLocation = location,
            searchQuery = query,
            isAddDialogOpen = dialogDetail.isAddOpen,
            selectedItemForDetail = dialogDetail.detailItem,
            snackbarMessage = dialogDetail.snackbar,
            isPro = isPro
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PantryUiState()
    )

    fun onSearchQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onLocationSelected(location: StorageLocation?) {
        _selectedLocation.value = if (_selectedLocation.value == location) null else location
    }

    fun openAddDialog() {
        _isAddDialogOpen.value = true
    }

    fun closeAddDialog() {
        _isAddDialogOpen.value = false
    }

    fun selectItem(item: PantryItem?) {
        _selectedItemForDetail.value = item
    }

    fun addFromSmartMatch(option: ProductMatchOption, quantity: Int) {
        viewModelScope.launch {
            val expiryDays = if (option.shelfLifeDays > 0) option.shelfLifeDays.toLong() else 7L
            val targetEpoch = LocalDate.now().plusDays(expiryDays).toEpochDay()

            repository.addPantryItem(
                name = option.title,
                barcode = null,
                category = option.brandOrCategory,
                storageLocation = option.storageLocation,
                expiryDateEpochDay = targetEpoch,
                quantity = quantity,
                unit = "uds",
                imageUrl = option.imageUrl,
                caloriesKcal = null,
                proteinGrams = null,
                carbsGrams = null,
                fatGrams = null,
                sugarGrams = null,
                saltGrams = null
            )
            closeAddDialog()
            _snackbarMessage.value = "Añadido: ${option.title}"
        }
    }

    fun updateItem(item: PantryItem) {
        viewModelScope.launch {
            repository.updatePantryItem(item)
            _selectedItemForDetail.value = null
            _snackbarMessage.value = "Alimento actualizado"
        }
    }

    fun deleteItem(item: PantryItem) {
        viewModelScope.launch {
            repository.deletePantryItem(item.id)
            _selectedItemForDetail.value = null
            _snackbarMessage.value = "Eliminado: ${item.name}"
        }
    }

    fun consumeItem(item: PantryItem) {
        viewModelScope.launch {
            repository.deletePantryItem(item.id)
            _selectedItemForDetail.value = null
            _snackbarMessage.value = "¡Buen provecho! Consumido: ${item.name}"
        }
    }

    fun addToShoppingList(item: PantryItem) {
        viewModelScope.launch {
            repository.addShoppingItem(
                name = item.name,
                category = item.category,
                quantity = item.quantity,
                originPantryItemId = item.id,
                imageUrl = item.imageUrl
            )
            _snackbarMessage.value = "Añadido a lista de compra: ${item.name}"
        }
    }

    fun exportPantryTxt(): String {
        val currentItems = uiState.value.items
        return PantryTxtFormatUtil.exportToTxt(currentItems)
    }

    fun importPantryTxt(content: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                if (content.isBlank()) {
                    onResult(false, "El archivo TXT está vacío.")
                    return@launch
                }
                val entities = PantryTxtFormatUtil.parseFromTxt(content)
                if (entities.isEmpty()) {
                    onResult(false, "No se encontraron alimentos en el formato TXT.")
                    return@launch
                }
                val count = repository.importPantryItems(entities)
                val msg = "¡Éxito! Se han importado $count alimentos con sus fotos y propiedades nutricionales."
                _snackbarMessage.value = msg
                onResult(true, msg)
            } catch (e: Exception) {
                val errorMsg = "Error al importar: ${e.localizedMessage}"
                _snackbarMessage.value = errorMsg
                onResult(false, errorMsg)
            }
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }
}
