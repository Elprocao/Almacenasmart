package com.alacenasmart.app.ui.recipes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.alacenasmart.app.billing.BillingHelper
import com.alacenasmart.app.data.remote.GeminiRecipeService
import com.alacenasmart.app.domain.model.DietaryPreference
import com.alacenasmart.app.domain.model.PantryItem
import com.alacenasmart.app.domain.model.Recipe
import com.alacenasmart.app.domain.repository.PantryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class RecipeTab {
    RECOMMENDED,
    SAVED
}

data class RecipesUiState(
    val selectedTab: RecipeTab = RecipeTab.RECOMMENDED,
    val recommendedRecipes: List<Recipe> = emptyList(),
    val savedRecipes: List<Recipe> = emptyList(),
    val favoriteRecipes: List<Recipe> = emptyList(),
    val selectedDietaryPreference: DietaryPreference = DietaryPreference.ALL,
    val maxTimeMinutes: Int? = null,
    val customPrompt: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val selectedRecipeForDetail: Recipe? = null,
    val isPro: Boolean = false,
    val snackbarMessage: String? = null
)

class RecipesViewModel(
    private val repository: PantryRepository,
    private val billingHelper: BillingHelper? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(RecipesUiState())
    val uiState: StateFlow<RecipesUiState> = _uiState.asStateFlow()

    init {
        loadSavedRecipes()
        observePro()
    }

    private fun observePro() {
        viewModelScope.launch {
            billingHelper?.isPro?.collect { isPro ->
                _uiState.update { it.copy(isPro = isPro) }
            }
        }
    }

    private fun loadSavedRecipes() {
        viewModelScope.launch {
            repository.getSavedRecipes().collect { saved ->
                _uiState.update { it.copy(savedRecipes = saved) }
            }
        }
    }

    fun setTab(tab: RecipeTab) {
        _uiState.update { it.copy(selectedTab = tab) }
        if (tab == RecipeTab.RECOMMENDED && _uiState.value.recommendedRecipes.isEmpty()) {
            generateRecommendations()
        }
    }

    fun setDietaryPreference(pref: DietaryPreference) {
        _uiState.update { it.copy(selectedDietaryPreference = pref) }
        generateRecommendations()
    }

    fun setMaxTime(minutes: Int?) {
        _uiState.update { it.copy(maxTimeMinutes = minutes) }
        generateRecommendations()
    }

    fun setCustomPrompt(prompt: String) {
        _uiState.update { it.copy(customPrompt = prompt) }
    }

    fun regenerateWithPrompt() {
        generateRecommendations()
    }

    fun generateRecommendations() {
        _uiState.update { it.copy(isLoading = true, errorMessage = null) }

        viewModelScope.launch {
            try {
                val pantryItems = repository.getPantryItems().first()
                if (pantryItems.isEmpty()) {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            recommendedRecipes = emptyList(),
                            errorMessage = "Tu despensa está vacía. Añade alimentos para generar recetas personalizadas."
                        )
                    }
                    return@launch
                }

                val dietaryList = if (_uiState.value.selectedDietaryPreference != DietaryPreference.ALL) {
                    listOf(_uiState.value.selectedDietaryPreference)
                } else {
                    emptyList()
                }

                val recipes = GeminiRecipeService.generateRecipes(
                    pantryItems = pantryItems,
                    dietaryPreferences = dietaryList,
                    maxTimeMinutes = _uiState.value.maxTimeMinutes,
                    customPrompt = _uiState.value.customPrompt
                )

                _uiState.update {
                    it.copy(
                        isLoading = false,
                        recommendedRecipes = recipes,
                        errorMessage = if (recipes.isEmpty()) "No se pudieron generar recetas con los filtros y especificaciones seleccionados." else null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "Error al generar recetas con IA: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun selectRecipe(recipe: Recipe?) {
        _uiState.update { it.copy(selectedRecipeForDetail = recipe) }
    }

    fun toggleSaveRecipe(recipe: Recipe) {
        viewModelScope.launch {
            val isCurrentlySaved = _uiState.value.savedRecipes.any { it.id == recipe.id }
            if (isCurrentlySaved) {
                repository.removeSavedRecipe(recipe.id)
                _uiState.update { it.copy(snackbarMessage = "Receta eliminada de guardadas") }
            } else {
                repository.saveRecipe(recipe.copy(isSaved = true))
                _uiState.update { it.copy(snackbarMessage = "¡Receta guardada con éxito!") }
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
