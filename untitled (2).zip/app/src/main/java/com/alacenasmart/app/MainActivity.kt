package com.alacenasmart.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Kitchen
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alacenasmart.app.ui.components.AdBannerView
import com.alacenasmart.app.ui.components.TestInterstitial15sDialog
import com.alacenasmart.app.ui.onboarding.OnboardingScreen
import com.alacenasmart.app.ui.pantry.PantryScreen
import com.alacenasmart.app.ui.pantry.PantryViewModel
import com.alacenasmart.app.ui.recipes.RecipesScreen
import com.alacenasmart.app.ui.recipes.RecipesViewModel
import com.alacenasmart.app.ui.scanner.ScannerScreen
import com.alacenasmart.app.ui.scanner.ScannerViewModel
import com.alacenasmart.app.ui.settings.SettingsScreen
import com.alacenasmart.app.ui.shopping.ShoppingListScreen
import com.alacenasmart.app.ui.shopping.ShoppingViewModel
import com.alacenasmart.app.ui.theme.AlacenaSmartTheme

sealed class AppDestination(val route: String, val title: String, val icon: ImageVector) {
    data object Pantry : AppDestination("pantry", "Despensa", Icons.Default.Kitchen)
    data object Scanner : AppDestination("scanner", "Cámara IA", Icons.Default.CameraAlt)
    data object Recipes : AppDestination("recipes", "Recetas", Icons.Default.Restaurant)
    data object Shopping : AppDestination("shopping", "Compras", Icons.Default.ShoppingCart)
    data object Settings : AppDestination("settings", "Ajustes", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    private lateinit var app: AlacenaApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        app = application as AlacenaApp

        // Initialize Google UMP Consent & Ads
        app.adMobHelper.initializeWithConsent(this)

        val initialDestination = intent?.getStringExtra("EXTRA_START_DESTINATION") ?: "pantry"

        setContent {
            AlacenaSmartTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var show15sTestAd by remember { mutableStateOf(false) }
                    var pendingAdDismiss by remember { mutableStateOf<(() -> Unit)?>(null) }

                    val triggerAd: (onDismissed: () -> Unit) -> Unit = { onDismissed ->
                        if (app.adFrequencyManager.isPremiumUser || app.billingHelper.isPro.value) {
                            onDismissed()
                        } else {
                            app.adMobHelper.showDirectInterstitial(
                                activity = this@MainActivity,
                                onDismissed = {
                                    app.adFrequencyManager.recordInterstitialShown()
                                    onDismissed()
                                },
                                onFallback = {
                                    pendingAdDismiss = onDismissed
                                    show15sTestAd = true
                                }
                            )
                        }
                    }

                    if (show15sTestAd) {
                        TestInterstitial15sDialog(
                            onDismiss = {
                                show15sTestAd = false
                                app.adFrequencyManager.recordInterstitialShown()
                                pendingAdDismiss?.invoke()
                                pendingAdDismiss = null
                            }
                        )
                    }

                    AlacenaMainApp(
                        app = app,
                        initialRoute = initialDestination,
                        onShowInterstitial = triggerAd,
                        onWatchRewarded = { onReward ->
                            app.adMobHelper.showRewardedAd(
                                activity = this,
                                onRewardEarned = onReward,
                                onDismissed = {}
                            )
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        app.adFrequencyManager.onAppResume()
    }

    override fun onPause() {
        super.onPause()
        app.adFrequencyManager.onAppPause()
    }
}

@Composable
fun AlacenaMainApp(
    app: AlacenaApp,
    initialRoute: String,
    onShowInterstitial: (onDismissed: () -> Unit) -> Unit,
    onWatchRewarded: (onReward: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("alacenasmart_prefs", Context.MODE_PRIVATE) }
    var isOnboardingCompleted by remember {
        mutableStateOf(prefs.getBoolean("key_onboarding_completed", false))
    }

    if (!isOnboardingCompleted) {
        OnboardingScreen(
            onFinish = {
                prefs.edit().putBoolean("key_onboarding_completed", true).apply()
                isOnboardingCompleted = true
            }
        )
        return
    }

    var currentRoute by remember { mutableStateOf(initialRoute) }

    val pantryViewModel: PantryViewModel = viewModel {
        PantryViewModel(app.repository, app.billingHelper)
    }
    val scannerViewModel: ScannerViewModel = viewModel {
        ScannerViewModel(app.repository, app.billingHelper)
    }
    val recipesViewModel: RecipesViewModel = viewModel {
        RecipesViewModel(app.repository)
    }
    val shoppingViewModel: ShoppingViewModel = viewModel {
        ShoppingViewModel(app.repository)
    }

    val pantryState by pantryViewModel.uiState.collectAsStateWithLifecycle()
    val shoppingState by shoppingViewModel.uiState.collectAsStateWithLifecycle()

    val destinations = listOf(
        AppDestination.Pantry,
        AppDestination.Scanner,
        AppDestination.Recipes,
        AppDestination.Shopping,
        AppDestination.Settings
    )

    val isPro by app.billingHelper.isPro.collectAsStateWithLifecycle()

    // Enforce 15s ad every 8 minutes of app usage
    LaunchedEffect(isPro) {
        while (true) {
            kotlinx.coroutines.delay(10_000L)
            if (!isPro && !app.adFrequencyManager.isPremiumUser) {
                if (app.adFrequencyManager.shouldShowPeriodicAd()) {
                    onShowInterstitial {
                        app.adFrequencyManager.recordInterstitialShown()
                    }
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Hide bottom bar on Scanner screen so camera controls and viewfinder are unobstructed
            if (currentRoute != AppDestination.Scanner.route) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                    ) {
                        // Position ad banner above NavigationBar so buttons are not obstructed
                        if (!isPro && !app.adFrequencyManager.isPremiumUser) {
                            AdBannerView()
                        }

                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 0.dp
                        ) {
                            destinations.forEach { dest ->
                                val isSelected = currentRoute == dest.route
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = {
                                        if (currentRoute != dest.route) {
                                            // If leaving scanner or switching views, check interstitial frequency
                                            if (currentRoute == AppDestination.Scanner.route) {
                                                onShowInterstitial {
                                                    currentRoute = dest.route
                                                }
                                            } else {
                                                currentRoute = dest.route
                                            }
                                        }
                                    },
                                    icon = {
                                        when (dest) {
                                            AppDestination.Pantry -> {
                                                if (pantryState.expiringSoonCount > 0) {
                                                    BadgedBox(
                                                        badge = {
                                                            Badge { Text("${pantryState.expiringSoonCount}") }
                                                        }
                                                    ) {
                                                        Icon(dest.icon, contentDescription = dest.title)
                                                    }
                                                } else {
                                                    Icon(dest.icon, contentDescription = dest.title)
                                                }
                                            }
                                            AppDestination.Shopping -> {
                                                val uncompleted = shoppingState.totalCount - shoppingState.checkedCount
                                                if (uncompleted > 0) {
                                                    BadgedBox(
                                                        badge = {
                                                            Badge { Text("$uncompleted") }
                                                        }
                                                    ) {
                                                        Icon(dest.icon, contentDescription = dest.title)
                                                    }
                                                } else {
                                                    Icon(dest.icon, contentDescription = dest.title)
                                                }
                                            }
                                            else -> {
                                                Icon(dest.icon, contentDescription = dest.title)
                                            }
                                        }
                                    },
                                    label = { Text(dest.title, style = MaterialTheme.typography.labelSmall) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                    ),
                                    modifier = Modifier.testTag("nav_${dest.route}")
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentRoute) {
                AppDestination.Pantry.route -> {
                    PantryScreen(
                        viewModel = pantryViewModel,
                        onNavigateToScanner = { currentRoute = AppDestination.Scanner.route },
                        onNavigateToRecipes = { currentRoute = AppDestination.Recipes.route }
                    )
                }
                AppDestination.Scanner.route -> {
                    ScannerScreen(
                        viewModel = scannerViewModel,
                        onNavigateBack = {
                            onShowInterstitial {
                                currentRoute = AppDestination.Pantry.route
                            }
                        }
                    )
                }
                AppDestination.Recipes.route -> {
                    RecipesScreen(
                        viewModel = recipesViewModel
                    )
                }
                AppDestination.Shopping.route -> {
                    ShoppingListScreen(
                        viewModel = shoppingViewModel
                    )
                }
                AppDestination.Settings.route -> {
                    SettingsScreen(
                        billingHelper = app.billingHelper,
                        repository = app.repository
                    )
                }
            }
        }
    }
}
