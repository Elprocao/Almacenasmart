package com.alacenasmart.app

import android.app.Application
import com.alacenasmart.app.billing.BillingHelper
import com.alacenasmart.app.data.ads.AdFrequencyManager
import com.alacenasmart.app.data.ads.AdMobHelper
import com.alacenasmart.app.data.local.AppDatabase
import com.alacenasmart.app.data.repository.PantryRepositoryImpl
import com.alacenasmart.app.domain.repository.PantryRepository
import com.alacenasmart.app.workers.ExpiryNotificationWorker

class AlacenaApp : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: PantryRepository
        private set

    lateinit var billingHelper: BillingHelper
        private set

    lateinit var adMobHelper: AdMobHelper
        private set

    lateinit var adFrequencyManager: AdFrequencyManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getInstance(this)
        repository = PantryRepositoryImpl(
            pantryDao = database.pantryDao(),
            shoppingDao = database.shoppingDao(),
            barcodeDao = database.barcodeDictionaryDao(),
            savedRecipeDao = database.savedRecipeDao()
        )

        billingHelper = BillingHelper.getInstance(this)
        billingHelper.startConnection()

        adMobHelper = AdMobHelper.getInstance(this)
        adFrequencyManager = AdFrequencyManager.getInstance(this)

        // Schedule daily background worker for expiry notifications
        ExpiryNotificationWorker.scheduleDaily(this)
    }

    companion object {
        lateinit var instance: AlacenaApp
            private set
    }
}
